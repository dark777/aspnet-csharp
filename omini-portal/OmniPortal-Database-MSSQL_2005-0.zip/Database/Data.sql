USE [OmniPortal]
GO

/*
 * Communities
 */

insert into Communities (Title) values ('My First Site')

/*
 * Sites
 */

insert into Sites (Domain, SubDomain, Community_ID) values ('*', '*', 1)

/*
 * Sections
 */

insert into Sections ([Name], Title, PrimaryParentID, ParentID, [Order], Visible, Syndicated, Theme, Style, Module, Owner)
	values ('Home', null, 1, 0, 0, 1, 1, 'Inherited', 'Inherited', '{8B61FD65-C060-46f2-AC29-5A4669D010AC}', 'Administrator')

insert into Sections ([Name], Title, PrimaryParentID, ParentID, [Order], Visible, Syndicated, Theme, Style, Module, Owner)
	values ('Blog', 'My Blog', 1, 1, 0, 1, 1, 'Inherited', 'Inherited', '{A7181415-44BC-48aa-9519-2AFC69DCB92A}', 'Administrator')

/*
 * SectionRoles
 */

insert into SectionRoles (Section_ID, Role, Tasks) values (1, 'Administrator', 'Editor')
insert into SectionRoles (Section_ID, Role, Tasks) values (1, 'Everybody', 'ViewPage')
insert into SectionRoles (Section_ID, Role, Tasks) values (2, 'Administrator', 'Poster')
insert into SectionRoles (Section_ID, Role, Tasks) values (2, 'Everybody', 'ViewPage;Commentor')

/*
 * SectionProperties
 */

insert into SectionProperties (Section_ID, [Group], [Name], Value)
	values (1, 'Module', 'Content', '<h1>Welcome to OmniPortal</h1><p>This is your first instance of OmniPortal.  For more information please visit <a href="http://www.omniportal.net">OmniPortal.net</a> or <a href="http://sourceforge.net/projects/omniportal">OmniPortal@SourceForge</a>.')

/*
 * SiteSectionLink
 */

insert into SiteSectionLink (Site_ID, Section_ID) values (1, 1)

/*
 * Containers
 */

insert into Containers (Title) values ('MainPage')

/*
 * SectionContainerLink
 */

insert into SectionContainerLink (Section_ID, Container_ID, [Order], [Position]) values (1, 1, 0, 2)
insert into SectionContainerLink (Section_ID, Container_ID, [Order], [Position]) values (2, 1, 0, 2)

/*
 * Portlets
 */

insert into Portlets (Title, Module) values ('Login', '{F0E74CFD-C96C-4C1E-A9E0-CAF7BFC0CDB3}')
insert into Portlets (Title, Module) values ('OmniPortal Summery', '{8F369A68-564E-438B-B915-B4605EC12FE2}')

/*
 * PortletRoles
 */

insert into PortletRoles (Portlet_ID, Role, Permissions) values (1, 'Everybody', 'Read')
insert into PortletRoles (Portlet_ID, Role, Permissions) values (2, 'Everybody', 'Read')

/*
 * PortletProperties
 */

insert into PortletProperties (Portlet_ID, [Group], [Name], Value)
	values (2, 'Module', 'RssFeedUrl', 'http://sourceforge.net/export/rss2_projsummary.php?group_id=54624')

/*
 * ContainerPortletLink
 */

insert into ContainerPortletLink (Container_ID, Portlet_ID, [Order]) values (1, 1, 0)
insert into ContainerPortletLink (Container_ID, Portlet_ID, [Order]) values (1, 2, 1)
