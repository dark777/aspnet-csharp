CREATE DATABASE [OmniPortal]
GO

exec sp_dboption N'OmniPortal', N'autoclose', N'false'
GO

exec sp_dboption N'OmniPortal', N'bulkcopy', N'false'
GO

exec sp_dboption N'OmniPortal', N'trunc. log', N'false'
GO

exec sp_dboption N'OmniPortal', N'torn page detection', N'true'
GO

exec sp_dboption N'OmniPortal', N'read only', N'false'
GO

exec sp_dboption N'OmniPortal', N'dbo use', N'false'
GO

exec sp_dboption N'OmniPortal', N'single', N'false'
GO

exec sp_dboption N'OmniPortal', N'autoshrink', N'false'
GO

exec sp_dboption N'OmniPortal', N'ANSI null default', N'false'
GO

exec sp_dboption N'OmniPortal', N'recursive triggers', N'false'
GO

exec sp_dboption N'OmniPortal', N'ANSI nulls', N'false'
GO

exec sp_dboption N'OmniPortal', N'concat null yields null', N'false'
GO

exec sp_dboption N'OmniPortal', N'cursor close on commit', N'false'
GO

exec sp_dboption N'OmniPortal', N'default to local cursor', N'false'
GO

exec sp_dboption N'OmniPortal', N'quoted identifier', N'false'
GO

exec sp_dboption N'OmniPortal', N'ANSI warnings', N'false'
GO

exec sp_dboption N'OmniPortal', N'auto create statistics', N'true'
GO

exec sp_dboption N'OmniPortal', N'auto update statistics', N'true'
GO

if( ( (@@microsoftversion / power(2, 24) = 8) and (@@microsoftversion & 0xffff >= 724) ) or ( (@@microsoftversion / power(2, 24) = 7) and (@@microsoftversion & 0xffff >= 1082) ) )
	exec sp_dboption N'OmniPortal', N'db chaining', N'false'
GO

