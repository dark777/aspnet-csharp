-- ================================================================================================================
-- For the Low Level Business Logic Layer for the database 'ManagedFusion'
-- ================================================================================================================
SET NOCOUNT ON
GO
USE [OmniPortal]
GO

-- //// Select Stored procedure, based on field [Section_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionContainerLink_SelectAllWSection_IDLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[SectionContainerLink_SelectAllWSection_IDLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'SectionContainerLink'
-- based on a foreign key field.
-- Gets: @Section_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[SectionContainerLink_SelectAllWSection_IDLogic]
	@Section_ID int,
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Section_ID],
	[Container_ID],
	[Order],
	[Position]
FROM [dbo].[SectionContainerLink]
WHERE
	[Section_ID] = @Section_ID
ORDER BY
	[Order] ASC
	
-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select Stored procedure, based on field [Container_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContainerPortletLink_SelectAllWContainer_IDLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[ContainerPortletLink_SelectAllWContainer_IDLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'ContainerPortletLink'
-- based on a foreign key field.
-- Gets: @Container_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ContainerPortletLink_SelectAllWContainer_IDLogic]
	@Container_ID int,
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Container_ID],
	[Portlet_ID],
	[Order]
FROM [dbo].[ContainerPortletLink]
WHERE
	[Container_ID] = @Container_ID
ORDER BY
	[Order] ASC

-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select Stored procedure, based on field [Section_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionProperties_SelectAllWSection_IDAndGroupLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[SectionProperties_SelectAllWSection_IDAndGroupLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'SectionProperties'
-- based on a foreign key field.
-- Gets: @Section_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[SectionProperties_SelectAllWSection_IDAndGroupLogic]
	@Section_ID int,
	@Group nvarchar(32),
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Section_ID],
	[Group],
	[Name],
	[Value]
FROM [dbo].[SectionProperties]
WHERE
	[Section_ID] = @Section_ID
	AND [Group] = @Group
	
-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select Stored procedure, based on field [Section_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PortletProperties_SelectAllWPortlet_IDAndGroupLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[PortletProperties_SelectAllWPortlet_IDAndGroupLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'PortletProperties'
-- based on a foreign key field.
-- Gets: @Portlet_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[PortletProperties_SelectAllWPortlet_IDAndGroupLogic]
	@Portlet_ID int,
	@Group nvarchar(32),
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Portlet_ID],
	[Group],
	[Name],
	[Value]
FROM [dbo].[PortletProperties]
WHERE
	[Portlet_ID] = @Portlet_ID
	AND [Group] = @Group
	
-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select Stored procedure, based on field [Section_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CommunityProperties_SelectAllWCommunity_IDAndGroupLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[CommunityProperties_SelectAllWCommunity_IDAndGroupLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'CommunityProperties'
-- based on a foreign key field.
-- Gets: @Community_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[CommunityProperties_SelectAllWCommunity_IDAndGroupLogic]
	@Community_ID int,
	@Group nvarchar(32),
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Community_ID],
	[Group],
	[Name],
	[Value]
FROM [dbo].[CommunityProperties]
WHERE
	[Community_ID] = @Community_ID
	AND [Group] = @Group
	
-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select Stored procedure, based on field [Section_ID].
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionContainerLink_SelectAllWSection_IDAndPositionLogic]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[SectionContainerLink_SelectAllWSection_IDAndPositionLogic]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select one or more existing rows from the table 'SectionContainerLink'
-- based on a foreign key field.
-- Gets: @Section_ID int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[SectionContainerLink_SelectAllWSection_IDAndPositionLogic]
	@Section_ID int,
	@Position int,
	@ErrorCode int OUTPUT
AS
-- SELECT one or more existing rows from the table.
SELECT
	[Section_ID],
	[Container_ID],
	[Order],
	[Position]
FROM [dbo].[SectionContainerLink]
WHERE
	[Section_ID] = @Section_ID
	AND [Position] = @Position
	
-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO