if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_PortalProperties_Portals]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[CommunityProperties] DROP CONSTRAINT FK_PortalProperties_Portals
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Sites_Portals]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Sites] DROP CONSTRAINT FK_Sites_Portals
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ContainerPortletLink_Containers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ContainerPortletLink] DROP CONSTRAINT FK_ContainerPortletLink_Containers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionContainerLink_Containers]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SectionContainerLink] DROP CONSTRAINT FK_SectionContainerLink_Containers
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_ContainerPortletLink_Portlets]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[ContainerPortletLink] DROP CONSTRAINT FK_ContainerPortletLink_Portlets
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_PortletRoles_Portlets]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[PortletRoles] DROP CONSTRAINT FK_PortletRoles_Portlets
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionContainerLink_Sections]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SectionContainerLink] DROP CONSTRAINT FK_SectionContainerLink_Sections
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionProperties_Sections]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SectionProperties] DROP CONSTRAINT FK_SectionProperties_Sections
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionRoles_Sections]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SectionRoles] DROP CONSTRAINT FK_SectionRoles_Sections
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionSiteMapping_Sections]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SiteSectionLink] DROP CONSTRAINT FK_SectionSiteMapping_Sections
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_SectionSiteMapping_Sites]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[SiteSectionLink] DROP CONSTRAINT FK_SectionSiteMapping_Sites
GO

/****** Object:  Table [dbo].[Communities]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Communities]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Communities]
GO

/****** Object:  Table [dbo].[CommunityProperties]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CommunityProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CommunityProperties]
GO

/****** Object:  Table [dbo].[ContainerPortletLink]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ContainerPortletLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ContainerPortletLink]
GO

/****** Object:  Table [dbo].[Containers]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Containers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Containers]
GO

/****** Object:  Table [dbo].[Errors]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Errors]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Errors]
GO

/****** Object:  Table [dbo].[PortletProperties]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PortletProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PortletProperties]
GO

/****** Object:  Table [dbo].[PortletRoles]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PortletRoles]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PortletRoles]
GO

/****** Object:  Table [dbo].[Portlets]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Portlets]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Portlets]
GO

/****** Object:  Table [dbo].[SectionContainerLink]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionContainerLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SectionContainerLink]
GO

/****** Object:  Table [dbo].[SectionProperties]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionProperties]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SectionProperties]
GO

/****** Object:  Table [dbo].[SectionRoles]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SectionRoles]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SectionRoles]
GO

/****** Object:  Table [dbo].[Sections]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Sections]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Sections]
GO

/****** Object:  Table [dbo].[SiteSectionLink]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SiteSectionLink]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SiteSectionLink]
GO

/****** Object:  Table [dbo].[Sites]    Script Date: 2/24/2005 2:44:32 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Sites]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Sites]
GO

/****** Object:  Table [dbo].[Communities]    Script Date: 2/24/2005 2:44:34 PM ******/
CREATE TABLE [dbo].[Communities] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[UniversalIdentity]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Title] [nvarchar] (64) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Touched] [datetime] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[CommunityProperties]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[CommunityProperties] (
	[Community_ID] [int] NOT NULL ,
	[Group] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[ContainerPortletLink]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[ContainerPortletLink] (
	[Container_ID] [int] NOT NULL ,
	[Portlet_ID] [int] NOT NULL ,
	[Order] [int] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Containers]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[Containers] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Title] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Touched] [datetime] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Errors]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[Errors] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Occurrence] [datetime] NOT NULL ,
	[Message] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Hash] [int] NOT NULL ,
	[Category] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[UserAgent] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IPAddress] [nvarchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HttpReferrer] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HttpVerb] [nvarchar] (5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HttpPathAndQuery] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[PortletProperties]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[PortletProperties] (
	[Portlet_ID] [int] NOT NULL ,
	[Group] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[PortletRoles]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[PortletRoles] (
	[Portlet_ID] [int] NOT NULL ,
	[Role] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Permissions] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Portlets]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[Portlets] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Title] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Module]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Touched] [datetime] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SectionContainerLink]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[SectionContainerLink] (
	[Section_ID] [int] NOT NULL ,
	[Container_ID] [int] NOT NULL ,
	[Order] [int] NOT NULL ,
	[Position] [int] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SectionProperties]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[SectionProperties] (
	[Section_ID] [int] NOT NULL ,
	[Group] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Name] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value] [ntext] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SectionRoles]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[SectionRoles] (
	[Section_ID] [int] NOT NULL ,
	[Role] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Tasks] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Sections]    Script Date: 2/24/2005 2:44:35 PM ******/
CREATE TABLE [dbo].[Sections] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Name] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Title] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PrimaryParentID] [int] NOT NULL ,
	[ParentID] [int] NOT NULL ,
	[Order] [int] NOT NULL ,
	[Visible] [bit] NOT NULL ,
	[Syndicated] [bit] NOT NULL ,
	[Theme] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Style] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Module]  uniqueidentifier ROWGUIDCOL  NOT NULL ,
	[Owner] [nvarchar] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Touched] [datetime] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[SiteSectionLink]    Script Date: 2/24/2005 2:44:36 PM ******/
CREATE TABLE [dbo].[SiteSectionLink] (
	[Site_ID] [int] NOT NULL ,
	[Section_ID] [int] NOT NULL 
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Sites]    Script Date: 2/24/2005 2:44:36 PM ******/
CREATE TABLE [dbo].[Sites] (
	[ID] [int] IDENTITY (1, 1) NOT NULL ,
	[Domain] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[SubDomain] [nvarchar] (128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Touched] [datetime] NOT NULL ,
	[Community_ID] [int] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Communities] WITH NOCHECK ADD 
	CONSTRAINT [PK_Portals] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CommunityProperties] WITH NOCHECK ADD 
	CONSTRAINT [PK_PortalProperties] PRIMARY KEY  CLUSTERED 
	(
		[Community_ID],
		[Group],
		[Name]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[ContainerPortletLink] WITH NOCHECK ADD 
	CONSTRAINT [PK_ContainerPortletLink] PRIMARY KEY  CLUSTERED 
	(
		[Container_ID],
		[Portlet_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Containers] WITH NOCHECK ADD 
	CONSTRAINT [PK_Containers] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Errors] WITH NOCHECK ADD 
	CONSTRAINT [PK_Errors] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[PortletProperties] WITH NOCHECK ADD 
	CONSTRAINT [PK_PortletModuleData] PRIMARY KEY  CLUSTERED 
	(
		[Portlet_ID],
		[Group],
		[Name]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[PortletRoles] WITH NOCHECK ADD 
	CONSTRAINT [PK_PortletRoles] PRIMARY KEY  CLUSTERED 
	(
		[Portlet_ID],
		[Role]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Portlets] WITH NOCHECK ADD 
	CONSTRAINT [PK_Portlets] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SectionContainerLink] WITH NOCHECK ADD 
	CONSTRAINT [PK_SectionContainerLink] PRIMARY KEY  CLUSTERED 
	(
		[Section_ID],
		[Container_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SectionProperties] WITH NOCHECK ADD 
	CONSTRAINT [PK_SectionProperties] PRIMARY KEY  CLUSTERED 
	(
		[Section_ID],
		[Name],
		[Group]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SectionRoles] WITH NOCHECK ADD 
	CONSTRAINT [PK_SectionRoles] PRIMARY KEY  CLUSTERED 
	(
		[Section_ID],
		[Role]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Sections] WITH NOCHECK ADD 
	CONSTRAINT [PK_Sections] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[SiteSectionLink] WITH NOCHECK ADD 
	CONSTRAINT [PK_SectionSiteMapping] PRIMARY KEY  CLUSTERED 
	(
		[Site_ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Sites] WITH NOCHECK ADD 
	CONSTRAINT [PK_Sites] PRIMARY KEY  CLUSTERED 
	(
		[ID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Communities] ADD 
	CONSTRAINT [DF_Communities_UniversalIdentity] DEFAULT (newid()) FOR [UniversalIdentity],
	CONSTRAINT [DF_Portals_portal_touched] DEFAULT (getdate()) FOR [Touched]
GO

 CREATE  INDEX [IX_CommunityProperties] ON [dbo].[CommunityProperties]([Group]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ContainerPortletLink] ADD 
	CONSTRAINT [DF_ContainerPortletLink_Order] DEFAULT (0) FOR [Order]
GO

ALTER TABLE [dbo].[Containers] ADD 
	CONSTRAINT [DF_Containers_container_touched] DEFAULT (getdate()) FOR [Touched]
GO

ALTER TABLE [dbo].[Errors] ADD 
	CONSTRAINT [DF_Errors_error_occurrence] DEFAULT (getdate()) FOR [Occurrence]
GO

 CREATE  INDEX [IX_PortletProperties] ON [dbo].[PortletProperties]([Group]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Portlets] ADD 
	CONSTRAINT [DF_Portlets_portlet_touched] DEFAULT (getdate()) FOR [Touched]
GO

ALTER TABLE [dbo].[SectionContainerLink] ADD 
	CONSTRAINT [DF_SectionContainerLink_Order] DEFAULT (0) FOR [Order],
	CONSTRAINT [DF_SectionContainerLink_Position] DEFAULT (2) FOR [Position]
GO

 CREATE  INDEX [IX_SectionProperties] ON [dbo].[SectionProperties]([Group]) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Sections] ADD 
	CONSTRAINT [DF_Sections_section_primaryParentID] DEFAULT (1) FOR [PrimaryParentID],
	CONSTRAINT [DF_Sections_section_parentID] DEFAULT ((-1)) FOR [ParentID],
	CONSTRAINT [DF_Sections_section_order] DEFAULT (0) FOR [Order],
	CONSTRAINT [DF_Sections_section_visible] DEFAULT (1) FOR [Visible],
	CONSTRAINT [DF_Sections_Syndicate] DEFAULT (1) FOR [Syndicated],
	CONSTRAINT [DF_Sections_Module] DEFAULT ('AACA68FA-4FA2-4a4a-A70C-BF400AFF278F') FOR [Module],
	CONSTRAINT [DF_Sections_section_touched] DEFAULT (getdate()) FOR [Touched]
GO

ALTER TABLE [dbo].[Sites] ADD 
	CONSTRAINT [DF_Sites_site_domain] DEFAULT ('*') FOR [Domain],
	CONSTRAINT [DF_Sites_site_subDomain] DEFAULT ('*') FOR [SubDomain],
	CONSTRAINT [DF_Sites_site_touched] DEFAULT (getdate()) FOR [Touched],
	CONSTRAINT [IX_Sites_Domain] UNIQUE  NONCLUSTERED 
	(
		[Domain],
		[SubDomain]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[CommunityProperties] ADD 
	CONSTRAINT [FK_PortalProperties_Portals] FOREIGN KEY 
	(
		[Community_ID]
	) REFERENCES [dbo].[Communities] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[ContainerPortletLink] ADD 
	CONSTRAINT [FK_ContainerPortletLink_Containers] FOREIGN KEY 
	(
		[Container_ID]
	) REFERENCES [dbo].[Containers] (
		[ID]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_ContainerPortletLink_Portlets] FOREIGN KEY 
	(
		[Portlet_ID]
	) REFERENCES [dbo].[Portlets] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[PortletRoles] ADD 
	CONSTRAINT [FK_PortletRoles_Portlets] FOREIGN KEY 
	(
		[Portlet_ID]
	) REFERENCES [dbo].[Portlets] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[SectionContainerLink] ADD 
	CONSTRAINT [FK_SectionContainerLink_Containers] FOREIGN KEY 
	(
		[Container_ID]
	) REFERENCES [dbo].[Containers] (
		[ID]
	) ON DELETE CASCADE ,
	CONSTRAINT [FK_SectionContainerLink_Sections] FOREIGN KEY 
	(
		[Section_ID]
	) REFERENCES [dbo].[Sections] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[SectionProperties] ADD 
	CONSTRAINT [FK_SectionProperties_Sections] FOREIGN KEY 
	(
		[Section_ID]
	) REFERENCES [dbo].[Sections] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[SectionRoles] ADD 
	CONSTRAINT [FK_SectionRoles_Sections] FOREIGN KEY 
	(
		[Section_ID]
	) REFERENCES [dbo].[Sections] (
		[ID]
	) ON DELETE CASCADE 
GO

ALTER TABLE [dbo].[SiteSectionLink] ADD 
	CONSTRAINT [FK_SectionSiteMapping_Sections] FOREIGN KEY 
	(
		[Section_ID]
	) REFERENCES [dbo].[Sections] (
		[ID]
	),
	CONSTRAINT [FK_SectionSiteMapping_Sites] FOREIGN KEY 
	(
		[Site_ID]
	) REFERENCES [dbo].[Sites] (
		[ID]
	)
GO

ALTER TABLE [dbo].[Sites] ADD 
	CONSTRAINT [FK_Sites_Portals] FOREIGN KEY 
	(
		[Community_ID]
	) REFERENCES [dbo].[Communities] (
		[ID]
	)
GO

