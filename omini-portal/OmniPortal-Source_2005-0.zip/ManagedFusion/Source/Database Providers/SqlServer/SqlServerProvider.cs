#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Data;
using ManagedFusion.Types;
using ManagedFusion.Providers;

namespace ManagedFusion.Data.SqlServer
{
	[Provider("SqlServer")]
	public class SqlServerProvider : CoreDatabaseProvider
	{
		#region Portlets

		private PortletCollection _Portlets;
		public override PortletCollection Portlets
		{
			#region get
			get
			{
				if (this._Portlets != null) return this._Portlets;

				// get all portlets
				Portlets portlet = new Portlets();
				DataTable portletsTable = portlet.SelectAll();

				// create protlet array
				PortletInfo[] portlets = new PortletInfo[portletsTable.Rows.Count];

				// create protlet for each row
				DataRow row = null;
				for (int i = 0; i < portletsTable.Rows.Count; i++)
				{
					row = portletsTable.Rows[i];
					portlets[i] = new PortletInfo(
						(int)row["ID"],
						(string)row["Title"],
						(Guid)row["Module"],
						(DateTime)row["Touched"]
						);
				}

				this._Portlets = new PortletCollection(portlets);
				return this._Portlets;
			}
			#endregion
			#region set
			set
			{
				bool changed = false;

				foreach (PortletInfo portlet in value.ChangedItems) 
				{
					changed = true;

					this.CommitPortletChanges(portlet);
				}

				// update collection if changed
				if (changed) 
				{
					this.ResetPortletCollection();
				}

				// notify subscribers of change
				this.OnPortletsChanged();
			}
			#endregion
		}

		public override void CommitPortletChanges(PortletInfo portlet)
		{
			Portlets dbportlet = new Portlets();

			dbportlet.ID = portlet.ID;
			dbportlet.Title = portlet.Title;
			dbportlet.Module = portlet.Module.ID;
			dbportlet.Touched = portlet.Touched;

			switch (portlet.State) 
			{
				case State.Added :		// insert 
					dbportlet.Insert();
					break;
				case State.Changed :	// commit changes
					dbportlet.Update();
					break;
				case State.Deleted :	// remove
					dbportlet.Delete();
					break;
			}
		}

		protected override void ResetPortletCollection()
		{
			this._Portlets = null;
			this._Portlets = this.Portlets;
		}

		#endregion

		#region Containers

		private ContainerCollection _Containers;
		public override ContainerCollection Containers
		{
			#region get
			get
			{
				if (this._Containers != null) return this._Containers;

				// get all containers
				Containers container = new Containers();
				DataTable containersTable = container.SelectAll();

				// create container array
				ContainerInfo[] containers = new ContainerInfo[containersTable.Rows.Count];

				// create container for each row
				DataRow row = null;
				for (int i = 0; i < containersTable.Rows.Count; i++)
				{
					row = containersTable.Rows[i];
					containers[i] = new ContainerInfo(
						(int)row["ID"],
						(string)row["Title"],
						(DateTime)row["Touched"]
						);
				}

				this._Containers = new ContainerCollection(containers);
				return this._Containers;
			}
			#endregion
			#region set
			set
			{
				bool changed = false;

				foreach (ContainerInfo container in value.ChangedItems) 
				{
					changed = true;

					this.CommitContainerChanges(container);
				}

				// update collection if changed
				if (changed) 
				{
					this.ResetContainerCollection();
				}

				// notify subscribers of change
				this.OnContainersChanged();
			}
			#endregion
		}

		public override void CommitContainerChanges(ContainerInfo container)
		{
			Containers dbcontainer = new Containers();

			dbcontainer.ID = container.ID;
			dbcontainer.Title = container.Title;
			dbcontainer.Touched = container.Touched;

			switch (container.State) 
			{
				case State.Added :		// insert 
					dbcontainer.Insert();
					break;
				case State.Changed :	// commit changes
					dbcontainer.Update();
					break;
				case State.Deleted :	// remove
					dbcontainer.Delete();
					break;
			}
		}

		protected override void ResetContainerCollection()
		{
			this._Containers = null;
			this._Containers = this.Containers;
		}

		#endregion

		#region Sections

		private SectionCollection _Sections;
		public override SectionCollection Sections
		{
			#region get
			get
			{
				if (this._Sections != null) return this._Sections;

				// get all sections
				Sections section = new Sections();
				DataTable sectionsTable = section.SelectAll();

				// create section array
				SectionInfo[] sections = new SectionInfo[sectionsTable.Rows.Count];

				// create section for each row
				DataRow row = null;
				for(int i = 0; i < sectionsTable.Rows.Count; i++)
				{
					row = sectionsTable.Rows[i];
					sections[i] = new SectionInfo(
						(int)row["ID"],
						(string)row["Name"],
						(row["Title"] == DBNull.Value) ? String.Empty : (string)row["Title"],
						(int)row["PrimaryParentID"],
						(int)row["ParentID"],
						(int)row["Order"],
						(bool)row["Visible"],
						(bool)row["Syndicated"],
						(string)row["Theme"],
						(string)row["Style"],
						(Guid)row["Module"],
						(string)row["Owner"],
						(DateTime)row["Touched"]
						);
				}

				this._Sections = new SectionCollection(sections);
				return this._Sections;
			}
			#endregion
			#region set
			set
			{
				bool changed = false;

				foreach(SectionInfo section in value.ChangedItems) 
				{
					changed = true;

					this.CommitSectionChanges(section);		
				}

				// update collection if changed
				if (changed) 
				{
					this.ResetSectionCollection();
				}

				// notify subscribers of change
				this.OnSectionsChanged();
			}
			#endregion
		}

		public override void CommitSectionChanges(SectionInfo section)
		{
			Sections dbsection = new Sections();

			dbsection.ID = section.ID;
			dbsection.Name = section.Name;
			dbsection.Title = section.Title;
			dbsection.PrimaryParentID = section.PrimaryParent.ID;
			dbsection.ParentID = section.Parent.ID;
			dbsection.Order = section.Order;
			dbsection.Visible = section.Visible;
			dbsection.Syndicated = section.Syndicated;
			dbsection.Theme = section.OriginalTheme;
			dbsection.Style = section.OriginalStyle;
			dbsection.Module = section.Module.ID;
			dbsection.Owner = section.OriginalOwner;
			dbsection.Touched = section.Touched;

			switch (section.State) 
			{
				case State.Added :		// insert 
					dbsection.Insert();
					break;
				case State.Changed :	// commit changes
					dbsection.Update();
					break;
				case State.Deleted :	// remove
					dbsection.Delete();
					break;
			}
		}

		protected override void ResetSectionCollection()
		{
			this._Sections = null;
			this._Sections = this.Sections;
		}

		#endregion

		#region Communities

		private CommunityCollection _Communities;
		public override CommunityCollection Communities
		{
			#region get
			get
			{
				if (_Communities != null) return _Communities;

				// get all Communities
				Communities community = new Communities();
				DataTable CommunitiesTable = community.SelectAll();

				// create community array
				CommunityInfo[] Communities = new CommunityInfo[CommunitiesTable.Rows.Count];

				// create community for each row
				DataRow row = null;
				for (int i = 0; i < CommunitiesTable.Rows.Count; i++)
				{
					row = CommunitiesTable.Rows[i];
					Communities[i] = new CommunityInfo(
						(int)row["ID"],
						(Guid)row["UniversalIdentity"],
						(string)row["Title"],
						(DateTime)row["Touched"]
						);
				}

				this._Communities = new CommunityCollection(Communities);
				return this._Communities;
			}
			#endregion
			#region set
			set
			{
				bool changed = false;

				foreach (CommunityInfo community in value.ChangedItems) 
				{
					changed = true;

					this.CommitPortalChanges(community);
				}

				// update collection if changed
				if (changed) 
				{
					this.ResetCommunityCollection();
				}

				// notify subscribers of change
				this.OnCommunitiesChanged();
			}
			#endregion
		}

		public override void CommitPortalChanges(CommunityInfo community)
		{
			Communities dbcommunity = new Communities();

			dbcommunity.ID = community.ID;
			dbcommunity.Title = community.Title;
			dbcommunity.Touched = community.Touched;

			switch (community.State) 
			{
				case State.Added :		// insert 
					dbcommunity.Insert();
					break;
				case State.Changed :	// commit changes
					dbcommunity.Update();
					break;
				case State.Deleted :	// remove
					dbcommunity.Delete();
					break;
			}
		}

		protected override void ResetCommunityCollection()
		{
			this._Communities = null;
			this._Communities = this.Communities;
		}

		#endregion

		#region Sites

		private SiteCollection _Sites;
		public override SiteCollection Sites
		{
			#region get
			get
			{
				if (_Sites != null) return _Sites;

				// get all sites
				Sites site = new Sites();
				DataTable sitesTable = site.SelectAll();

				// create site array
				SiteInfo[] sites = new SiteInfo[sitesTable.Rows.Count];

				// create site for each row
				DataRow row = null;
				for (int i = 0; i < sitesTable.Rows.Count; i++)
				{
					row = sitesTable.Rows[i];
					sites[i] = new SiteInfo(
						(int)row["ID"],
						(string)row["Domain"],
						(string)row["SubDomain"],
						(DateTime)row["Touched"],
						(row["Community_ID"] == DBNull.Value) ? -1 : (int)row["Community_ID"]
						);
				}

				this._Sites = new SiteCollection(sites);
				return this._Sites;
			}
			#endregion
			#region set
			set
			{
				bool changed = false;

				foreach (SiteInfo site in value.ChangedItems) 
				{
					changed = true;

					this.CommitSiteChanges(site);
				}

				// update collection if changed
				if (changed) 
				{
					this.ResetSiteCollection();
				}
			
				// notify subscribers of change
				this.OnSitesChanged();
			}
			#endregion
		}

		public override void CommitSiteChanges(SiteInfo site)
		{
			Sites dbsite = new Sites();

			dbsite.ID = site.ID;
			dbsite.Domain = site.Domain;
			dbsite.SubDomain = site.SubDomain;
			dbsite.Touched = site.Touched;
			dbsite.Community_ID = (site.ConnectedCommunity == null) ? SqlInt32.Null : site.ConnectedCommunity.ID;

			switch (site.State) 
			{
				case State.Added :		// insert 
					dbsite.Insert();
					break;
				case State.Changed :	// commit changes
					dbsite.Update();
					break;
				case State.Deleted :	// remove
					dbsite.Delete();
					break;
			}
		}

		protected override void ResetSiteCollection()
		{
			this._Sites = null;
			this._Sites = this.Sites;
		}

		#endregion

		#region Errors

		public override void InsertError (ManagedFusionException exc) 
		{
			Errors error = new Errors();
			
			error.Occurrence = DateTime.Now;
			error.Message = exc.Message;
			error.Hash = exc.GetHashCode();
			error.Category = exc.Category;
			error.UserAgent = exc.UserAgent;
			error.IPAddress = exc.IPAddress;
			error.HttpReferrer = exc.HttpReferrer;
			error.HttpVerb = exc.HttpVerb;
			error.HttpPathAndQuery = exc.HttpPathAndQuery;

			try 
			{
				// insert error
				error.Insert();
			} 
			catch (Exception) { }
		}

		#endregion

		#region Properties

		#region SectionModuleData

		public override SectionModuleDataCollection GetModuleDataForSection (SectionInfo section)
		{
			SectionProperties properties = new SectionProperties();
			properties.Section_ID = section.ID;
			properties.Group = SectionModuleDataGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWSection_IDAndGroupLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new SectionModuleDataCollection(section, collection);
		}

		public override void AddModuleDataForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionModuleDataGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateModuleDataForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionModuleDataGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveModuleDataForSection (string name, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionModuleDataGroup;
			property.Name = name;
		
			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region PortletModuleData

		public override PortletModuleDataCollection GetModuleDataForPortlet (PortletInfo portlet)
		{
			PortletProperties properties = new PortletProperties();
			properties.Portlet_ID = portlet.ID;
			properties.Group = PortletModuleDataGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWPortlet_IDLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new PortletModuleDataCollection(portlet, collection);
		}

		public override void AddModuleDataForPortlet (string name, string value, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletModuleDataGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateModuleDataForPortlet (string name, string value, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletModuleDataGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}
		
		public override void RemoveModuleDataForPortlet (string name, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletModuleDataGroup;
			property.Name = name;

			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region SectionMetaProperties

		public override SectionMetaPropertyCollection GetMetaPropertiesForSection (SectionInfo section)
		{
			SectionProperties properties = new SectionProperties();
			properties.Section_ID = section.ID;
			properties.Group = SectionMetaPropertiesGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWSection_IDAndGroupLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new SectionMetaPropertyCollection(section, collection);
		}

		public override void AddMetaPropertyForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionMetaPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateMetaPropertyForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionMetaPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveMetaPropertyForSection (string name, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionMetaPropertiesGroup;
			property.Name = name;
		
			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region CommunityGeneralProperties

		public override CommunityPropertyCollection GetGeneralPropertiesForCommunity (CommunityInfo community)
		{
			CommunityProperties properties = new CommunityProperties();
			properties.Community_ID = community.ID;
			properties.Group = CommunityGeneralPropertiesGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWCommunity_IDAndGroupLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new CommunityPropertyCollection(community, collection);
		}

		public override void AddGeneralPropertyForCommunity (string name, string value, CommunityInfo community)
		{
			CommunityProperties property = new CommunityProperties();
			property.Community_ID = community.ID;
			property.Group = CommunityGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateGeneralPropertyForCommunity (string name, string value, CommunityInfo community)
		{
			CommunityProperties property = new CommunityProperties();
			property.Community_ID = community.ID;
			property.Group = CommunityGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveGeneralPropertyForCommunity (string name, CommunityInfo community)
		{
			CommunityProperties property = new CommunityProperties();
			property.Community_ID = community.ID;
			property.Group = CommunityGeneralPropertiesGroup;
			property.Name = name;
		
			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region SectionGeneralProperties

		public override SectionPropertyCollection GetGeneralPropertiesForSection (SectionInfo section)
		{
			SectionProperties properties = new SectionProperties();
			properties.Section_ID = section.ID;
			properties.Group = SectionGeneralPropertiesGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWSection_IDAndGroupLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new SectionPropertyCollection(section, collection);
		}

		public override void AddGeneralPropertyForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateGeneralPropertyForSection (string name, string value, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveGeneralPropertyForSection (string name, SectionInfo section)
		{
			SectionProperties property = new SectionProperties();
			property.Section_ID = section.ID;
			property.Group = SectionGeneralPropertiesGroup;
			property.Name = name;
		
			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region PortletGeneralProperties

		public override PortletPropertyCollection GetGeneralPropertiesForPortlet (PortletInfo portlet)
		{
			PortletProperties properties = new PortletProperties();
			properties.Portlet_ID = portlet.ID;
			properties.Group = PortletGeneralPropertiesGroup;
			
			// get all properties for section
			DataTable table = properties.SelectAllWPortlet_IDAndGroupLogic();
			NameValueCollection collection = new NameValueCollection(table.Rows.Count);

			// add all rows to NameValueCollection
			foreach(DataRow row in table.Rows) 
				collection.Add(
					(string)row["Name"],
					(string)row["Value"]
					);

			// returns a property collection
			return new PortletPropertyCollection(portlet, collection);
		}

		public override void AddGeneralPropertyForPortlet (string name, string value, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// insert new property
				property.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateGeneralPropertyForPortlet (string name, string value, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletGeneralPropertiesGroup;
			property.Name = name;
			property.Value = value;

			try 
			{
				// update property
				property.Update();
			} 
			catch (Exception) { }
		}
		
		public override void RemoveGeneralPropertyForPortlet (string name, PortletInfo portlet)
		{
			PortletProperties property = new PortletProperties();
			property.Portlet_ID = portlet.ID;
			property.Group = PortletGeneralPropertiesGroup;
			property.Name = name;

			try 
			{
				// delete property
				property.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#endregion

		#region Roles

		#region SectionRoles

		public override RolesTasksDictionary GetRolesForSection(SectionInfo section)
		{
			SectionRoles dbroles = new SectionRoles();
			dbroles.Section_ID = section.ID;

			// return list of roles
			return new RolesTasksDictionary(dbroles.SelectAllWSection_IDLogic());
		}

		public override void AddRoleForSection(string role, string[] tasks, SectionInfo section)
		{
			SectionRoles dbrole = new SectionRoles();
			dbrole.Section_ID = section.ID;
			dbrole.Role = role;
			dbrole.Tasks = String.Join(Global.Delimiter.ToString(), tasks);

			try 
			{
				// add role
				dbrole.Insert();
			} 
			catch (Exception) { }
		}

		public override void RemoveRoleForSection(string role, SectionInfo section)
		{
			SectionRoles dbrole = new SectionRoles();
			dbrole.Section_ID = section.ID;
			dbrole.Role = role;

			try 
			{
				// remove certain role
				dbrole.Delete();
			} 
			catch (Exception) { }
		}

		public override void RemoveAllRolesForSection(SectionInfo section)
		{
			SectionRoles dbrole = new SectionRoles();
			dbrole.Section_ID = section.ID;

			try 
			{
				// remove all roles for one section
				dbrole.DeleteAllWSection_IDLogic();
			} 
			catch (Exception) { }
		}

		public override void RemoveAllOfCertainRoleForSection(string role)
		{
			SectionRoles dbrole = new SectionRoles();
			dbrole.Role = role;

			try 
			{
				// remove all roles of a certain type
				dbrole.DeleteAllWRoleLogic();
			} 
			catch (Exception) { }
		}

		#endregion

		#region PortletRoles

		public override RolesPermissionsDictionary GetRolesForPortlet(PortletInfo portlet)
		{
			PortletRoles dbroles = new PortletRoles();
			dbroles.Portlet_ID = portlet.ID;

			// return list of roles
			return new RolesPermissionsDictionary(dbroles.SelectAllWPortlet_IDLogic());
		}

		public override void AddRoleForPortlet(string role, string[] permissions, PortletInfo portlet)
		{
			PortletRoles dbrole = new PortletRoles();
			dbrole.Portlet_ID = portlet.ID;
			dbrole.Role = role;
			dbrole.Permissions = String.Join(Global.Delimiter.ToString(), permissions);

			try 
			{
				// add role
				dbrole.Insert();
			} 
			catch (Exception) { }
		}

		public override void RemoveRoleForPortlet(string role, PortletInfo portlet)
		{
			PortletRoles dbrole = new PortletRoles();
			dbrole.Portlet_ID = portlet.ID;
			dbrole.Role = role;

			try 
			{
				// remove certain role
				dbrole.Delete();
			} 
			catch (Exception) { }
		}

		public override void RemoveAllRolesForPortlet(PortletInfo portlet)
		{
			PortletRoles dbrole = new PortletRoles();
			dbrole.Portlet_ID = portlet.ID;

			try 
			{
				// remove all roles for one section
				dbrole.DeleteAllWPortlet_IDLogic();
			} 
			catch (Exception) { }
		}

		public override void RemoveAllOfCertainRoleForPortlet(string role)
		{
			PortletRoles dbrole = new PortletRoles();
			dbrole.Role = role;

			try 
			{
				// remove all roles of a certain type
				dbrole.DeleteAllWRoleLogic();
			} 
			catch (Exception) { }
		}

		#endregion

		#endregion

		#region Links

		#region SiteSectionLink

		public override int GetSectionForSite (SiteInfo site)
		{
			// get containers for specific section
			SiteSectionLink link = new SiteSectionLink();
			link.Site_ID = site.ID;
			DataTable section = link.SelectOne();

			// if one section was returned, return it's id
			if (section.Rows.Count == 1)
				return (int)section.Rows[0]["Section_ID"];

			// if no sections were found return section not found
			return -1;
		}

		public override bool SiteSectionLinked (SectionInfo section, SiteInfo site)
		{
			SiteSectionLink link = new SiteSectionLink();
			link.Section_ID = section.ID;
			link.Site_ID = site.ID;

			try 
			{
				// return if combination is found
				return link.SelectOne().Rows.Count == 1;
			} 
			catch (Exception) 
			{
				return false; 
			}
		}

		public override void SetSiteSectionLink (SectionInfo section, SiteInfo site)
		{
			SiteSectionLink link = new SiteSectionLink();
			link.Section_ID = section.ID;
			link.Site_ID = site.ID;

			try 
			{
				if (SiteSectionLinked(section, site))
				{
					//update combination
					link.Update();
				}
				else 
				{
					// add combination
					link.Insert();
				} 
			}
			catch (Exception) { }
		}

		public override void RemoveSiteSectionLink (SiteInfo site)
		{
			SiteSectionLink link = new SiteSectionLink();
			link.Site_ID = site.ID;

			try 
			{
				// delete all with this container
				link.Delete();
			} 
			catch (Exception) { }
		}

		#endregion

		#region SectionContainerLink

		public override int[] GetContainersForSection (SectionInfo section)
		{
			// get containers for specific section
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			DataTable sections = link.SelectAllWSection_IDLogic();

			ArrayList list = new ArrayList(sections.Rows.Count);

			foreach(DataRow row in sections.Rows) 
				list.Add((int)row["Container_ID"]);

			// return array of section ids
			return (int[])list.ToArray(typeof(int));
		}

		public override int[] GetContainersInPositionForSection(SectionInfo section, int position)
		{
			// get containers for specific section
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			link.Position = position;
			DataTable sections = link.SelectAllWSection_IDAndPositionLogic();

			ArrayList list = new ArrayList(sections.Rows.Count);

			foreach(DataRow row in sections.Rows) 
				list.Add((int)row["Container_ID"]);

			// return array of section ids
			return (int[])list.ToArray(typeof(int));
		}

		public override bool SectionContainerLinked (SectionInfo section, ContainerInfo container)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			link.Container_ID = container.ID;

			try 
			{
				// return if combination is found
				return link.SelectOne().Rows.Count == 1;
			} 
			catch (Exception) 
			{
				return false; 
			}
		}

		public override void AddSectionContainerLink (SectionInfo section, ContainerInfo container, int order, int position)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			link.Container_ID = container.ID;
			link.Position = position;

			try 
			{
				// add combination
				link.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateSectionContainerLink(SectionInfo section, ContainerInfo container, int position, int order)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			link.Container_ID = container.ID;
			link.Position = position;
			link.Order = order;

			try 
			{
				// update combination
				link.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveSectionContainerLink (SectionInfo section, ContainerInfo container)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;
			link.Container_ID = container.ID;

			try 
			{
				// delete combination
				link.Delete();
			} 
			catch (Exception) { }
		}

		public override void RemoveContainersForSection (SectionInfo section)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Section_ID = section.ID;

			try 
			{
				// delete all with this section
				link.DeleteAllWSection_IDLogic();
			} 
			catch (Exception) { }
		}

		public override void RemoveSectionsForContainer (ContainerInfo container)
		{
			SectionContainerLink link = new SectionContainerLink();
			link.Container_ID = container.ID;

			try 
			{
				// delete all with this container
				link.DeleteAllWContainer_IDLogic();
			} 
			catch (Exception) { }
		}

		#endregion

		#region ContainerPortletLink

		public override int[] GetPortletsForContainer (ContainerInfo container)
		{
			// get portets for specific container
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;
			DataTable containers = link.SelectAllWContainer_IDLogic();

			ArrayList list = new ArrayList(containers.Rows.Count);

			foreach(DataRow row in containers.Rows) 
				list.Add((int)row["Portlet_ID"]);

			// return array of section ids
			return (int[])list.ToArray(typeof(int));
		}

		public override bool ContainerPortletLinked (ContainerInfo container, PortletInfo portlet)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;
			link.Portlet_ID = portlet.ID;

			try 
			{
				// return if combination is found
				return link.SelectOne().Rows.Count == 1;
			} 
			catch (Exception) 
			{
				return false; 
			}
		}

		public override void AddContainerPortletLink (ContainerInfo container, PortletInfo portlet, int order)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;
			link.Portlet_ID = portlet.ID;
			link.Order = order;

			try 
			{
				// add combination
				link.Insert();
			} 
			catch (Exception) { }
		}

		public override void UpdateContainerPortletLink(ContainerInfo container, PortletInfo portlet, int order)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;
			link.Portlet_ID = portlet.ID;
			link.Order = order;

			try 
			{
				// update combination
				link.Update();
			} 
			catch (Exception) { }
		}

		public override void RemoveContainerPortletLink (ContainerInfo container, PortletInfo portlet)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;
			link.Portlet_ID = portlet.ID;

			try 
			{
				// delete combination
				link.Delete();
			} 
			catch (Exception) { }
		}

		public override void RemovePortletsForContainer (ContainerInfo container)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Container_ID = container.ID;

			try 
			{
				// delete all with this container
				link.DeleteAllWContainer_IDLogic();
			} 
			catch (Exception) { }
		}

		public override void RemoveContainersForPortlet (PortletInfo portlet)
		{
			ContainerPortletLink link = new ContainerPortletLink();
			link.Portlet_ID = portlet.ID;

			try 
			{
				// delete all with this portlet
				link.DeleteAllWPortlet_IDLogic();
			} 
			catch (Exception) { }
		}

		#endregion

		#endregion
	}
}