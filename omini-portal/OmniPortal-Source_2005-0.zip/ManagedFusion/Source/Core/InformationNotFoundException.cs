#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion
{
	/// <summary>
	/// This exception is thrown when the information cannot be found for the current
	/// request.
	/// </summary>
	public class InformationNotFoundException : ManagedFusionException 
	{
		private const string _message = "The requested information could not be found.";

		/// <summary>Used when information cannot be found for a request</summary>
		public InformationNotFoundException () : base(ExceptionType.DataLayer, _message) {}
		
		/// <summary>Used when information cannot be found for a request</summary>
		/// <param name="message">The message to display to the client when the exception is thrown.</param>
		public InformationNotFoundException (string message) : base(ExceptionType.DataLayer, message) {}
		
		/// <summary></summary>
		/// <param name="message">The message to display to the client when the exception is thrown.</param>
		/// <param name="inner">The InnerException, if any, that threw the current exception.</param>
		public InformationNotFoundException (string message, Exception inner) : base(ExceptionType.DataLayer, message, inner) {}

		/// <summary>Used when information cannot be found for a request</summary>
		/// <param name="type"></param>
		/// <param name="message">The message to display to the client when the exception is thrown.</param>
		internal InformationNotFoundException (ExceptionType type, string message) : base(type, message) {}
		
		/// <summary></summary>
		/// <param name="type"></param>
		/// <param name="message">The message to display to the client when the exception is thrown.</param>
		/// <param name="inner">The InnerException, if any, that threw the current exception.</param>
		internal InformationNotFoundException (ExceptionType type, string message, Exception inner) : base(type, message, inner) {}
	}
}