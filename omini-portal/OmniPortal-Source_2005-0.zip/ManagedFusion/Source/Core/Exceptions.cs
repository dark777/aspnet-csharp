#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

// ManagedFusion Classes
using ManagedFusion.Data;
using ManagedFusion.Types;

namespace ManagedFusion
{
	/// <summary>
	/// This exception is used to encapsulate all ManagedFusion Exceptions to make
	/// debugging and error handling easier.
	/// </summary>
	[Serializable]
	public class ManagedFusionException : ApplicationException 
	{
		private ExceptionType _type;
		private string _userAgent;
		private string _ipAddress;
		private string _httpReferrer;
		private string _httpVerb;
		private string _httpPathAndQuery;

		#region Constructors

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		public ManagedFusionException () : this(ExceptionType.UnknownError) { }

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		/// <param name="type">The type of the exception.</param>
		public ManagedFusionException (ExceptionType type)
		{
			_type = type;
			this.Init();
		}

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		/// <param name="message">The message from the exception.</param>
		public ManagedFusionException (string message) : this (ExceptionType.UnknownError, message) { }

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		/// <param name="type">The type of the exception.</param>
		/// <param name="message">The message from the exception.</param>
		public ManagedFusionException (ExceptionType type, string message) : base (message)
		{
			_type = type;
			this.Init();
		}

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		/// <param name="message">The message from the exception.</param>
		/// <param name="inner">Base exception that was used.</param>
		public ManagedFusionException (string message, Exception inner) : this (ExceptionType.UnknownError, message, inner) { }

		/// <summary>The base ManagedFusion Exception, for all exceptions that are related to ManagedFusion.</summary>
		/// <param name="type">The type of the exception.</param>
		/// <param name="message">The message from the exception.</param>
		/// <param name="inner">Base exception that was used.</param>
		public ManagedFusionException (ExceptionType type, string message, Exception inner) : base (message, inner) 
		{
			_type = type;
			this.Init();
		}

		private void Init () 
		{
			if (Global.Context.Request.UrlReferrer != null)
				_httpReferrer = Global.Context.Request.UrlReferrer.ToString();

			_userAgent = Global.Context.Request.UserAgent;
			_ipAddress = Global.Context.Request.UserHostAddress;
			_httpVerb = Global.Context.Request.RequestType;
			_httpPathAndQuery = Global.Context.Request.Url.PathAndQuery;
		}

		#endregion

		/// <summary>
		/// Gets a message that describes the current exception.
		/// </summary>
		public override string Message
		{
			get
			{
				switch (_type) 
				{
					case ExceptionType.Config :
						return Global.CultureResource.GetString(String.Concat("Exception_", _type.ToString()));

					case ExceptionType.AccessDenied :		// Message = Section Path
					case ExceptionType.ControlNotFound :	// Message = Control Path
					case ExceptionType.NotSupported :
						return String.Format(Global.CultureResource.GetString(String.Concat("Exception_", _type.ToString())), base.Message);
				}

				return base.Message;
			}
		}

		#region Public Properties

		/// <summary>
		/// The category for the exception.
		/// </summary>
		public string Category 
		{
			get { return _type.ToString(); }
			set { _type = (ExceptionType)Enum.Parse(typeof(ExceptionType), value, true); }
		}
		
		/// <summary>
		/// The type of the exception.
		/// </summary>
		internal ExceptionType Type 
		{
			get { return _type; } 
		}

		/// <summary>
		/// The user agent of where the exception came from.
		/// </summary>
		public string UserAgent 
		{
			get { return _userAgent; }
			set { _userAgent = value; }
		}

		/// <summary>
		/// The IP address of where the exception came from.
		/// </summary>
		public string IPAddress 
		{
			get { return _ipAddress; }
			set { _ipAddress = value; }
		}

		/// <summary>
		/// The referring URI of where the exception came from.
		/// </summary>
		public string HttpReferrer 
		{
			get { return _httpReferrer; }
			set { _httpReferrer = value; }
		}

		/// <summary>
		/// The HTTP verb of where the exception came from.
		/// </summary>
		public string HttpVerb 
		{
			get { return _httpVerb; }
			set { _httpVerb = value; }
		}

		/// <summary>
		/// The URL they were trying to access of where the exception came from.
		/// </summary>
		public string HttpPathAndQuery 
		{
			get { return _httpPathAndQuery; }
			set { _httpPathAndQuery = value; }
		}

		#endregion

		/// <summary>
		/// Serves as a hash function for a particular type, suitable for use in hashing algorithms and data structures like a hash table.
		/// </summary>
		/// <returns>A hash code for the current <see cref="Object"/>.</returns>
		public override int GetHashCode()
		{
			return String.Concat(CommunityInfo.Current.ID, this.Category, base.Message).GetHashCode();
		}

		/// <summary>Log the exception to the database.</summary>
		public void LogException () 
		{
			Global.DatabaseProvider.InsertError(this);
		}
	}
}