#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion
{
	/// <summary>
	/// This exception is thrown when the requested control cannot be found.
	/// </summary>
	public class ControlNotFoundException : InformationNotFoundException 
	{
		private readonly string _location;

		/// <summary>Used when the requested control cannot be found.</summary>
		/// <param name="location">The requested control.</param>
		public ControlNotFoundException (string location) : base(ExceptionType.ControlNotFound, location) { this._location = location; }
			
		/// <summary>Used when the requested control cannot be found.</summary>
		/// <param name="location">The requested control.</param>
		/// <param name="inner">The InnerException, if any, that threw the current exception.</param>
		public ControlNotFoundException (string location, Exception inner) : base(ExceptionType.ControlNotFound, location, inner) { this._location = location; }

		/// <summary>The page that was not found.</summary>
		public string Location { get { return this._location; } }
	}
}