using System;
using System.IO;
using System.Collections.Specialized;

using ManagedFusion.Path;
using ManagedFusion.Providers;

namespace ManagedFusion.Path.MultiPath
{
	[Provider("MultiPath")]
	internal class MultiPathProvider : PathProvider
	{
		private StringCollection Directories;

		public MultiPathProvider () 
		{
			// create instance of directories
			Directories = new StringCollection();

			// portal directory reference
			string communityPath = Global.Context.Request.ApplicationPath + "/" + "Communities";
			DirectoryInfo portalDirectory = new DirectoryInfo(Global.Context.Server.MapPath(communityPath));

			// get list of all directories
			foreach(DirectoryInfo info in portalDirectory.GetDirectories())
				Directories.Add(info.Name);
		}

		protected override string GetCommunityPath(int communityID, string location)
		{
			location = location.Replace("\\", "/");

			if (Directories.Contains(communityID.ToString()) == false)
				throw new ManagedFusionException(ExceptionType.BusinessLayer, String.Concat("The community with id ", communityID, " could not be found."));

			if (location.StartsWith("/Communities/" + communityID))
				return location;

			string path = "/Communities/" + communityID + "/" + location;
		
			path = RemoveDoubleSeperators(PortalProperties.WebPathSeperator, path);

			return path;
		}

		protected override string GetDefaultPath(string location)
		{
			location = location.Replace("\\", "/");

			if (location.StartsWith("/Communities/Default"))
				return location;

			string path = String.Concat("/Communities/Default/", location);
		
			path = RemoveDoubleSeperators(PortalProperties.WebPathSeperator, path);

			return path;
		}
	}
}
