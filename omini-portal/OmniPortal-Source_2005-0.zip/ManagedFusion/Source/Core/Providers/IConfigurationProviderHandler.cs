using System;
using System.Xml;
using System.Configuration;

// ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Providers
{
	/// <summary>
	/// Represents the base information for a provider that is a "plug-in" to an application.
	/// </summary>
	[RootProvider]
	public interface IConfigurationProviderHandler
	{
		/// <summary>
		/// Implemented by all configuration provider handlers to parse the XML of the configuration section. The returned object is added to the configuration collection and is accessed by GetConfig.
		/// </summary>    
        object Create(XmlNode provider);
	}
}
