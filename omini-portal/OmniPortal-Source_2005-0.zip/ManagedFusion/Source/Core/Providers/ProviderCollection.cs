#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections;
using System.Reflection;

// ManagedFusion Classes
using ManagedFusion.Types;
using ManagedFusion.Data;
using ManagedFusion.Configuration;

namespace ManagedFusion.Providers
{
	public sealed class ProviderCollection : ICollection
	{
		private Hashtable _collection;
		private Type[] _types;

		internal ProviderCollection () 
		{
			ArrayList list = new ArrayList();

			// gets all types
			foreach (string assembly in Global.GetUniqueAssemblies()) 
			{
				Assembly a = Assembly.Load(assembly);
				
				foreach (Type t in a.GetTypes()) 
				{
					if (t.IsDefined(typeof(ProviderAttribute), false)
						|| t.IsDefined(typeof(RootProviderAttribute), false))
					{
						list.Add(t);
					}
				}
			}

			// list of all types
			this._types = (Type[])list.ToArray(typeof(Type));
			this._collection = this.ScourForRootProviders(typeof(RootProviderAttribute));
			this._types = null;
		}

		#region Scour Assemblies

		#region ProviderItem

		private class ProviderItem 
		{
			public ProviderItem (Type provider, Type activator) 
			{
				this.Provider = provider;
				this.Activator = activator;
			}

			public readonly Type Provider;

			public readonly Type Activator;
		}

		#endregion

		private Hashtable ScourForRootProviders(Type type)
		{
			Hashtable providers = new Hashtable();

			foreach (Type t in this._types)
			{
				// checks to see if the type is a root provider
				if (t.IsDefined(typeof(RootProviderAttribute), false))
				{
					object[] attribs = t.GetCustomAttributes(typeof(RootProviderAttribute), false);

					// check to see if there are any attributes
					if (attribs.Length > 0)
					{
						providers.Add(t, this.ScourForImplimentedProviders(t, (attribs[0] as RootProviderAttribute).ActivatorType));
					}
				}
			}

			return providers;
		}

		private Hashtable ScourForImplimentedProviders(Type root, Type activator)
		{
			Hashtable providers = new Hashtable(CaseInsensitiveHashCodeProvider.DefaultInvariant, CaseInsensitiveComparer.DefaultInvariant);

			foreach (Type t in this._types)
			{
				// checks to see if the type is a provider
				// check to see if t contains root
				// root can be a class or an interface, that is the reason for t.GetInterface, because IsSubclassOf
				// only works for classes
				if (t.IsDefined(typeof(ProviderAttribute), false) && (t.IsSubclassOf(root) || t.GetInterface(root.FullName, false) != null))
				{
					object[] attribs = t.GetCustomAttributes(typeof(ProviderAttribute), false);

					// check to see if there are any attributes
					if (attribs.Length > 0)
					{
						ProviderAttribute ptype = attribs[0] as ProviderAttribute;

						if (providers.ContainsKey(ptype.Type) == false) 
						{
							// get the activator type and set default to root activator
							Type atype = activator;

							// if provider activator type is set then use that instead
							if (ptype.ActivatorType != null)
								atype = ptype.ActivatorType;

							// add the new provider item to the hash table
							providers.Add(ptype.Type, new ProviderItem(t, atype));
						}
					}
				}
			}

			return providers;
		}

		#endregion

		/// <summary></summary>
		/// <param name="providerType"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		/// <exception cref="ArgumentNullException"></exception>
		/// <exception cref="ManagedFusionException"></exception>
		private ProviderItem GetProviderType (Type providerType, string name) 
		{
			if (providerType == null) throw new ArgumentNullException("providerType");
			if (name == null) throw new ArgumentNullException("name");

			// get the providerType or root hash table
			Hashtable hash = (Hashtable)_collection[providerType];

			if (hash == null) throw new ManagedFusionException(ExceptionType.Provider, String.Concat("Could not find the type, ", providerType.FullName, ", in the ProviderCollection."));
			if (hash.Contains(name) == false) throw new ManagedFusionException(ExceptionType.Provider, String.Concat("Could not find the implimentation, ", name, " for ", providerType.FullName, " in the ProviderCollection."));

			return (ProviderItem)hash[name]; 
		}

		/// <summary></summary>
		/// <param name="providerType"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		/// <exception cref="ArgumentNullException"></exception>
		/// <exception cref="ManagedFusionException"></exception>
		public object GetProvider (Type providerType, string name) 
		{
			try 
			{
				// get the provider item
				ProviderItem item = this.GetProviderType(providerType, name);

				// get the provider activator
				ProviderActivator activator = ProviderActivator.Instance(item.Activator);
			
				// get the provider object
				return activator.CreateInstance(item.Provider);
			} 
			catch (ApplicationException exc) 
			{
				throw new ManagedFusionException(ExceptionType.Provider, name, exc);
			}
		}

		/// <summary></summary>
		public object this [Type providerType, string name] 
		{
			get { return this.GetProvider(providerType, name); }
		}

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Count; } }

		void ICollection.CopyTo(Array array, int index)
		{
			this._collection.CopyTo(array, index);
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this._collection.GetEnumerator();
		}

		#endregion
	}
}