using System;

namespace ManagedFusion.Providers
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface)]
	public class RootProviderAttribute : Attribute
	{
		public RootProviderAttribute() { }

		public RootProviderAttribute(Type activatorType) 
		{
			this._ActivatorType = activatorType;
		}

		private Type _ActivatorType = typeof(ProviderActivator);
		public Type ActivatorType 
		{ 
			get { return this._ActivatorType; } 
		}
	}
}
