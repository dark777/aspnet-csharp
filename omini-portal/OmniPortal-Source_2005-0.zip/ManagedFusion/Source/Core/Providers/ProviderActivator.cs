using System;

namespace ManagedFusion.Providers
{
	public class ProviderActivator
	{
		protected ProviderActivator () { }

		internal static ProviderActivator Instance (Type type) 
		{
			return (ProviderActivator)Activator.CreateInstance(type, true);
		}

		protected internal virtual object CreateInstance (Type type) 
		{
			return Activator.CreateInstance(type);
		}
	}
}
