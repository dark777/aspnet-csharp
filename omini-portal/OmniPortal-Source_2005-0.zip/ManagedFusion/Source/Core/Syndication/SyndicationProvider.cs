using System;
using System.Web;

// ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Syndication
{
	[RootProvider]
	public abstract class SyndicationProvider
	{
		public abstract ISyndication Feed { get; }

		public abstract IHttpHandler Handler { get; }
	}
}
