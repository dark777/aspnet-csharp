using System;
using System.IO;
using System.Text;

namespace ManagedFusion.Syndication
{
	public class SyndicationWriter : StringWriter
	{
		public SyndicationWriter(StringBuilder builder) : base(builder) {}

		public override Encoding Encoding
		{
			get { return Encoding.UTF8; }
		}
	}
}
