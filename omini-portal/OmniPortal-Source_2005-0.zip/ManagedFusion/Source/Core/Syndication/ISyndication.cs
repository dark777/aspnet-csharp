using System;
using System.Xml;

namespace ManagedFusion.Syndication
{
	public interface ISyndication
	{
		DateTime LastModified { get; }

		string Serialize ();
	}
}
