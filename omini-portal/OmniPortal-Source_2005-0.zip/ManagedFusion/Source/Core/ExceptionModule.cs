using System;
using System.Web;

// ManagedFusion Classes
using ManagedFusion;

namespace ManagedFusion
{
	public class ExceptionModule : IHttpModule
	{
		#region IHttpModule Members

		public void Init(HttpApplication context)
		{
			context.Error += new EventHandler(Application_Error);
		}

		public void Dispose()
		{
		}

		#endregion

		#region Error
		/// <summary>
		/// Call this event to notify the module of an error that occurs during request processing.
		/// </summary>
		private void Application_Error(object sender, EventArgs e) 
		{
			HttpContext Context = ((HttpApplication)sender).Context;
			Exception exc;

			// check to see if the error has been wrapped
			if (Context.Server.GetLastError() is HttpException)
				exc = Context.Server.GetLastError().InnerException;
			else
				exc = Context.Server.GetLastError();

			// check to see if the base error is of ManagedFusionException type
			if ((exc is ManagedFusionException) == false) 
			{
				// create an exception of type ManagedFusionException 
				// because it is not of that type
				exc = new ManagedFusionException(
					ExceptionType.UnknownError, 
					exc.Message,
					exc
					);
			}

			// check for categories that get logged
			switch ((exc as ManagedFusionException).Type) 
			{
				case ExceptionType.ControlNotFound :
				case ExceptionType.Config :
				case ExceptionType.DataLayer :
				case ExceptionType.DisplayLayer :
				case ExceptionType.UnknownError :
					// log the error to the database
					(exc as ManagedFusionException).LogException();
					break;
			} 
		}
		#endregion
	}
}
