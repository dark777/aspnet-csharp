#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

#region References

using System;
using System.IO;
using System.Net;
using System.Web;
using System.Xml;
using System.Web.UI;
using System.Text;
using System.Threading;
using System.Resources;
using System.Drawing;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Reflection;
using System.Security.Permissions;
using System.Diagnostics;
using System.Configuration;
using System.Security.Cryptography;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;
using ManagedFusion.Data;
using ManagedFusion.Types;
using ManagedFusion.Security;
using ManagedFusion.Configuration;
using ManagedFusion.Providers;
using ManagedFusion.Path;
using ManagedFusion.Syndication;

#endregion

namespace ManagedFusion
{
	/// <summary>
	/// The Global class is a collection of global methods that get used through
	/// out the ManagedFusion software.
	/// </summary>
	public sealed class Global
	{
		#region Fields

		private static CacheManager _cacheManager;
		private static ResourceManager _globalCulture;
		private static PortalConfigurationSection _webConfig;
		private static PathProvider _pathProvider;
		private static SyndicationProvider _syndicationProvider;
		private static CoreDatabaseProvider _coreDatabaseProvider;
		private static ProviderCollection _providerCollection;

		#endregion

		#region Constants

		/// <summary>The delimiter is ';'.</summary>
		public const char Delimiter = ';';

		#endregion

		#region Constructors

		static Global () 
		{
			/*
			 * the following statments must be in this order
			 * this is so that everything gets setup correctly
			 */
			_providerCollection = new ProviderCollection();
			_cacheManager = new CacheManager();

			// configuration
			_webConfig = (PortalConfigurationSection)ConfigurationSettings.GetConfig("ManagedFusion");

			// providers
			_pathProvider = (PathProvider)Providers[typeof(PathProvider), WebConfig.PathProviderString];
			_coreDatabaseProvider = (CoreDatabaseProvider)Providers[typeof(CoreDatabaseProvider), WebConfig.DatabaseProviderString];
			_syndicationProvider = (SyndicationProvider)Providers[typeof(SyndicationProvider), WebConfig.SyndicationProviderString];

			// resources
			_globalCulture = new ResourceManager("ManagedFusion.Culture.ManagedFusion", Assembly.GetAssembly(typeof(ManagedFusionException)));
		}

		internal Global () { }

		#endregion

		#region Properties

		#region Public

		/// <summary>The caching system used to manage the cache with in ManagedFusion.</summary>
		public static CacheManager Cache { get { return _cacheManager; } }

		/// <summary>The global culture resource manager for all modules and portlets.</summary>
		public static ResourceManager CultureResource { get { return _globalCulture; } }

		/// <summary>The context for the current web application instance.</summary>
		public static HttpContext Context { get { return HttpContext.Current; } }

		/// <summary></summary>
		public static PortalConfigurationSection WebConfig { get { return _webConfig; } }

		/// <summary></summary>
		public static PortalProperties Properties { get { return PortalProperties.Current; } }

		/// <summary></summary>
		public static PathProvider Path { get { return _pathProvider; } }

		/// <summary></summary>
		public static IModule ExecutingModule { get { return (IModule)Global.Context.Items["ExecutingModule"]; } }

		/// <summary></summary>
		public static SecurityProvider Security { get { return (SecurityProvider)Global.Context.User; } }

		/// <summary></summary>
		public static PageBuilder PageBuilder { get { return (PageBuilder)Global.Context.Items["PageBuilder"]; } }

		/// <summary></summary>
		public static DeviceType ClientDevice 
		{ 
			get 
			{
				try { return (DeviceType)Global.Context.Items["DeviceType"]; }
				catch { return DeviceType.Unknown; }
			}
		}

		/// <summary></summary>
		public static CultureInfo SelectedCulture 
		{ 
			get { return Thread.CurrentThread.CurrentCulture; } 
			set { Thread.CurrentThread.CurrentCulture = value; }
		}

		#endregion

		#region Internal

		/// <summary>The providers found in the assemblies.</summary>
		internal static ProviderCollection Providers { get { return _providerCollection; } }

		/// <summary>The ManagedFusion database for setup and creation of the layout and display.</summary>
		internal static CoreDatabaseProvider DatabaseProvider { get { return _coreDatabaseProvider; } }

		/// <summary></summary>
		internal static SyndicationProvider Syndication { get { return _syndicationProvider; } }

		#endregion

		#endregion

		#region Methods

		/*****************************************************************************
		 * String Manipulation
		 */
		/// <summary>Works like VB's Left function.</summary>
		/// <param name="s">The string.</param>
		/// <param name="length">The number of characters on the left of the string to get.</param>
		/// <returns>Returns a new formated string.</returns>
		public static string Left(string s, int length) 
		{
			// checks to see if length is less than 0
			if (length < 0)
				throw new ArgumentException("Argument 'length' must be greater or equal to zero.", "length");
			if ((s == null) || (s.Length == 0))
				return String.Empty; // VB.net does this.
			if (length >= s.Length)
				return s;

			return s.Substring(0, length);
		}

		/// <summary>Works like VB's Right function.</summary>
		/// <param name="s">The string.</param>
		/// <param name="length">The number of characters on the right of the string to get.</param>
		/// <returns>Returns a new formated string.</returns>
		public static string Right(string s, int length) 
		{
			// checks to see if length is less than 0
			if (length < 0)
				throw new ArgumentException("Argument 'length' must be greater or equal to zero.", "length");
			if (s == null)
				return String.Empty;

			return s.Substring(s.Length - length);
		}
		/*
		 *****************************************************************************/

		/// <summary>Gets a unique set of assemblies from the /bin directory.</summary>
		/// <returns>Returns a list of assemblies.</returns>
		public static string[] GetUniqueAssemblies () 
		{
			DirectoryInfo bin = new DirectoryInfo(Context.Request.PhysicalApplicationPath + "bin");
			FileInfo[] assemblies = bin.GetFiles("*.dll");

			// creates an array list that will contain all assemblies for searching
			ArrayList list = new ArrayList(assemblies.Length);

			// goes through each assembly and removes the .dll
			foreach(FileInfo file in assemblies)
				list.Add(file.Name.Replace(".dll", String.Empty));

			// returns a list of the assemblies
			return (string[])list.ToArray(typeof(string));
		}

		/// <summary>
		/// Creates a cache key from the <see cref="ManagedFusion.Global.PortalID">Global.PortalID</see>.
		/// </summary>
		/// <param name="key">The key used to help create the cache key.</param>
		/// <returns>Returns the key that has been formed from the input.</returns>
		public static string GetCacheKey (string key) 
		{
			try { return GetCacheKey(key, CommunityInfo.Current.UniversalIdentity.ToString("B")); } 
			catch (NullReferenceException exc) 
			{
				throw new ManagedFusionException(ExceptionType.BusinessLayer, "Portal identifier has not been placed into Global.Context yet.", exc);
			}
		}

		/// <summary>Sends the <see cref="HttpStatusCode"/> for <see cref="HttpResponse"/>.</summary>
		/// <remarks>
		/// <note>No other processing in ASP.Net will happen after this method is called, because this method calls <see cref="HttpResponse.End"/>.</note>
		/// This method will sends a <see cref="HttpStatusCode"/>
		/// according to <see href="http://www.w3.org/Protocols/rfc2616/rfc2616.html">RFC 2616</see>.
		/// </remarks>
		/// <param name="statusCode">The status code to send to the client.</param>
		/// <param name="endRequest">If the request should end after setting the status code.</param>
		/// <seealso href="http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html">HTTP Status Codes</seealso>
		public static void SendHttpStatusCode (HttpStatusCode statusCode) 
		{
			// set all of the status variables
			Context.Response.StatusCode = (int)statusCode;
			Context.Response.StatusDescription = statusCode.ToString();
			Context.Response.End();
		}

		/// <summary>
		/// Creates a cache key from the <see cref="ManagedFusion.Global.PortalID">Global.PortalID</see>.
		/// </summary>
		/// <param name="key">The key used to help create the cache key.</param>
		/// <param name="id">The id used to help create the cache key.</param>
		/// <returns>Returns the key that has been formed from the input.</returns>
		public static string GetCacheKey (string key, string id) 
		{
			return String.Format("{0}:{1}", key, id);
		}

		/// <summary>
		/// Get value of a specified <see cref="System.Xml.XmlNode">XmlNode</see>.
		/// </summary>
		/// <param name="node">Node to retreive value from.</param>
		/// <param name="attribute">Attribute to retreive.</param>
		/// <param name="required">The passed node is required by the program.</param>
		/// <returns>Returns the value of the attribute in the node.</returns>
		public static string GetValue (XmlNode node, string attribute, bool required) 
		{
			XmlNode n = node.Attributes.GetNamedItem(attribute);

			// checks to see if the node was found
			if (n == null) 
			{
				if (required)
					throw new ManagedFusionException(
						ExceptionType.Config, 
						"Attribute Required: " + attribute
						);
				else
					return String.Empty;
			}

			// if node was found returns its value
			return n.Value;
		}

		#endregion
	}
}