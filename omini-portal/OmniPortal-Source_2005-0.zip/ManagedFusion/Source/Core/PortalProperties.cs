#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion
{
	/// <summary>The static properties of the portal.</summary>
	/// <remarks>
	/// This class has the static properties for the portal that will not change.  Context properties can be
	/// found in the class <see cref="PortalContext"/>.  Config properties from <c>Web.Config</c> can
	/// be found in the class <see cref="PortalConfig"/>.
	/// </remarks>
	public sealed class PortalProperties 
	{
		private static PortalProperties _Current = new PortalProperties();

		/// <summary>Gets the <see cref="PortalProperties"/> object for the current portal.</summary>
		public static PortalProperties Current 
		{
			get { return _Current; }
		}

		/// <summary>Only allows <see langword="static"/> methods and properties to be able to create an instance of this class.</summary>
		/// <remarks><see cref="PortalProperties.Current"/> is the only property in this class that creates an instance.</remarks>
		private PortalProperties () {}

		#region Constants

		/// <summary>The path seperator for web URLs.</summary>
		public const char WebPathSeperator = '/';

		/// <summary>The path seperator for physical disks.</summary>
		public const char DiskPathSeperator = '\\';

		/// <summary>The </summary>
		public const string DefaultCommunity = "Default";

		/// <summary>Modules directory name.</summary>
		public const string PagesDirectory = "Pages";

		/// <summary>Modules directory name.</summary>
		public const string ModulesDirectory = "Modules";

		/// <summary>Portlets directory name.</summary>
		public const string PortletsDirectory = "Portlets";

		/// <summary>Images directory name.</summary>
		public const string ImagesDirectory = "Images";

		/// <summary>Skins directory name.</summary>
		public const string SkinsDirectory = "Skin";

		/// <summary>Styles directory name.</summary>
		public const string StylesDirectory = "Styles";

		/// <summary>The directory of where the themes are located in the current web application.</summary>
		public const string ThemeDirectory = "Themes";

		/// <summary>The portlet template file</summary>
		public const string PortletTemplateFile = "Template.ascx";

		/// <summary>The header file.</summary>
		public const string HeaderFile = "Head.html"; 

		#endregion

		/// <summary>The formal name of the software including the name and version.</summary>
		public string SoftwareName { get { return String.Concat(PortalName, " ", PortalVersion.ToString(2)); } }

		/// <summary>The formal name of this portal software.</summary>
		public string PortalName { get { return "ManagedFusion"; } }

		/// <summary>The copyright date of this portal software.</summary>
		public string PortalCopyrightDate { get { return String.Concat("2002-", DateTime.Now.Year); } }

		/// <summary>The copyright of this portal software.</summary>
		public string PortalCopyright 
		{ 
			get 
			{
				return String.Format(
					"{0} (www.ManagedFusion.com) Copyright {1}, Nicholas Berardi, All rights reserved.",
					PortalName,
					PortalCopyrightDate
					);
			}
		}

		/// <summary>The formal version of this portal software.</summary>
		public Version PortalVersion 
		{ 
			get 
			{ 
				// gets the file version for the assembly
				return this.GetType().Assembly.GetName().Version;
			}
		}
	}
}