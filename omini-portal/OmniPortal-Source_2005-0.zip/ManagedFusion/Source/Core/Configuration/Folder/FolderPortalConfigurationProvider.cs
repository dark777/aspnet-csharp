using System;
using System.IO;
using System.Xml;
using System.Collections;
using System.Web.Caching;

using ManagedFusion;
using ManagedFusion.Configuration;
using ManagedFusion.Providers;

namespace ManagedFusion.Configuration.Folder
{
	[Provider("Folder")]
	internal class FolderPortalConfigurationProvider : PortalConfigurationProvider
	{
		private PortalConfiguration _defaultConfiguration;
		public override PortalConfiguration DefaultConfiguration
		{
			get { return _defaultConfiguration; }
		}

		private PortalConfigurationCollection _collection;
		public override PortalConfigurationCollection PortalConfiguration
		{
			get 
			{
				if (_collection != null) return _collection;

				// portal directory reference
				DirectoryInfo portalDirectory = new DirectoryInfo(Global.Context.Server.MapPath("Communities"));

				// create config collection
				PortalConfigurationCollection collection = new PortalConfigurationCollection();

				// portal directories
				DirectoryInfo[] Communities = portalDirectory.GetDirectories();

				// add each portal to dictionary
				FileInfo[] hosts = null;
				FileInfo host = null;
				XmlDocument doc = null;
				int index = -1;

				try 
				{
					// process default community first
					DirectoryInfo[] defaultCommunity = portalDirectory.GetDirectories("Default");
					
					// check to see if the default community was found
					if (defaultCommunity.Length > 0) 
					{
						hosts = defaultCommunity[0].GetFiles("Community.config");

						// check to see if there is any config files available
						if (hosts.Length < 1) 
							throw new ManagedFusionException(ExceptionType.Config,
								"There is no default portal config file available in the Default folder."
								);

						host = hosts[0];

						// open up a text stream for loading into the XML Document
						using (StreamReader reader = host.OpenText()) 
						{
							// get XML config document
							doc = new XmlDocument();
							doc.Load(reader);

							this._defaultConfiguration = new PortalConfiguration(doc.SelectSingleNode("portal"), null, host.FullName, -1);

							// set the default configuration
							collection.SetDefaultConfiguration(
								_defaultConfiguration,
								host.FullName,
								new CacheDependency(host.FullName),
								new CacheItemRemovedCallback(ConfigurationCacheItemRemoved)
								);
							
							reader.Close();
						}
					} 
					else 
					{
						throw new ManagedFusionException(ExceptionType.Config,
							"There is no default portal available in the Communities folder."
							);
					}

					// process the rest of the communties
					foreach(DirectoryInfo community in Communities) 
					{
						hosts = community.GetFiles("Community.config");

						// goto next directory if there is no config file
						if (hosts.Length < 1) 
							continue;

						host = hosts[0];

						// get the index of the community id
						// if it is the default community just continue processing
						// because the default community has already been processed
						if (host.Directory.Name == "Default")
							continue;
						else 
						{
							// try to convert the directory name to an index
							// if that doesn't work skip and keep processing
							try 
							{ 
								index = Convert.ToInt32(host.Directory.Name); 
							}
							catch (ApplicationException) { continue; }
						}

						// open up a text stream for loading into the XML Document
						using (StreamReader reader = host.OpenText()) 
						{
							// get XML config document
							doc = new XmlDocument();
							doc.Load(reader);

							// add the configuration to the collection
							collection.Add(
								index,
								new PortalConfiguration(doc.SelectSingleNode("portal"), DefaultConfiguration, host.FullName, index),
								host.FullName,
								new CacheDependency(host.FullName),
								new CacheItemRemovedCallback(ConfigurationCacheItemRemoved)
								);
						
							reader.Close();
						}
					}
				} 
				catch (ApplicationException exc) 
				{
					throw new ManagedFusionException(ExceptionType.Config,
						"An error has occured in the portal configuration setup.", 
						new System.Configuration.ConfigurationException(
							exc.Message, exc, doc
							)
						);
				}

				// check to see if there were any portal configurations created
				if (collection.Count == 0) 
					throw new ManagedFusionException(ExceptionType.Config,
						"There are no portal configurations available in the Communities folder."
						);

				this._collection = collection;
				return _collection;
			}
		}

		private void ConfigurationCacheItemRemoved (string key, object value, CacheItemRemovedReason reason) 
		{
			FileInfo host = new FileInfo(key);
			PortalConfiguration config;

			// if key didn't relate to a file, then do nothing
			if (host == null)
				return;

			config = value as PortalConfiguration;

			// if config isn't valid
			if (config == null)
				return;

			// open up a text stream for loading into the XML Document
			using (StreamReader reader = host.OpenText()) 
			{
				// get XML config document
				XmlDocument doc = new XmlDocument();
				doc.Load(reader);

				// add the config to cache
				Global.Cache.Add(
					key, 
					String.Empty, 
					new PortalConfiguration(doc.SelectSingleNode("portal"), config.FallBackConfig, config.Location, config.AssociatedCommunityID), 
					TimeSpan.FromDays(1), 
					new CacheDependency(host.FullName),
					CacheItemPriority.NotRemovable, 
					new CacheItemRemovedCallback(ConfigurationCacheItemRemoved)
					);
						
				reader.Close();
			}
		}

		public override XmlNode GetProviderNode(string name, string location, int communityID)
		{
			XmlNode providerHandler;
			using (TextReader reader = new StreamReader(location)) 
			{
				// create the XML document
				XmlDocument doc = new XmlDocument();
				doc.Load(reader);

				// get the provider handler
				providerHandler = doc.SelectSingleNode(String.Format("/portal/providers/add[@name=\"{0}\"]", name));
						
				// close the reader
				reader.Close();
			}

			return providerHandler;
		}
	}
}