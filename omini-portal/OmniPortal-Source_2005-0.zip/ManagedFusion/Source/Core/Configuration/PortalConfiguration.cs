#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Configuration;
using System.Globalization;
using System.Collections.Specialized;
using System.Web;
using System.Web.Caching;

// ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Configuration
{
	/// <summary>The config properties from <c>Web.Config</c> of the portal.</summary>
	/// <remarks>
	/// This class has the static properties for the portal that will not change.  Context properties can be
	/// found in the class <see cref="ManagedFusion.PortalContext"/>.  Static properties can be found in the 
	/// class <see cref="ManagedFusion.PortalProperties"/>.
	/// </remarks>
	public class PortalConfiguration
	{
		private readonly PortalConfiguration _fallBackConfig;
		private readonly string _location;
		private readonly int _communityID;

		#region Program Constants

		private readonly CultureInfo	ConstantDefaultLanguage = CultureInfo.InvariantCulture;
		private readonly string			ConstantDefaultTheme = "Default";
		private readonly string			ConstantDefaultStyle = "Default";
		private readonly string			ConstantDefaultSkinControl = "Template.ascx";
		private readonly string			ConstantDefaultPageHandler = "ManagedFusion.Display.DesktopPage, ManagedFusion.Core";
		private readonly ExpirationType	ConstantExpirationType = ExpirationType.Default;
		private readonly double			ConstantCacheTime = 30D;
		private readonly double			ConstantDatabaseCacheTime = 30D;

		#endregion

		#region Properties

		public PortalConfiguration FallBackConfig 
		{
			get { return this._fallBackConfig; }
		}

		public string Location 
		{
			get { return this._location; }
		}

		public int AssociatedCommunityID 
		{
			get { return this._communityID; }
		}

		#region <settings>

		#region Private

		private StringDictionary _settings;

		private CultureInfo _defaultLanguage;
		private string _defaultTheme;
		private string _defaultStyle;
		private string _defaultSkinControl;
		private string _defaultPageHandler;
		private string _databaseConnectionString;
		private Type _defaultPageHandlerType;

		private ExpirationType _expirationType = ExpirationType.NotSet;
		private double _cacheTime = -1;
		private double _databaseCacheTime = -1;

		#endregion

		/// <summary>Gets a value from the settings.</summary>
		public string this [string key] 
		{
			get { return this._settings[key]; }
		}

		/// <summary>Gets the database connection string for the community.</summary>
		public string DatabaseConnectionString 
		{
			get 
			{
				// return value
				return _databaseConnectionString;
			}
		}

		/// <summary>Gets the default language for the community.</summary>
		public CultureInfo DefaultLanguage 
		{
			get 
			{
				// check to see if the value is set
				if (this._defaultLanguage == null)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.DefaultLanguage;
					else
						return this.ConstantDefaultLanguage;
				}
				
				// return value
				return _defaultLanguage;
			}
		}

		/// <summary></summary>
		public string DefaultTheme 
		{
			get 
			{
				// check to see if the value is set
				if (this._defaultTheme == null)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.DefaultTheme;
					else
						return this.ConstantDefaultTheme;
				}
				
				// return value
				return _defaultTheme;
			}
		}

		/// <summary></summary>
		public string DefaultStyle 
		{
			get 
			{
				// check to see if the value is set
				if (this._defaultStyle == null)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.DefaultStyle;
					else
						return this.ConstantDefaultStyle;
				}
				
				// return value
				return _defaultStyle;
			}
		}

		/// <summary>The default skin control that is used when loading the page.</summary>
		public string DefaultSkinControl 
		{
			get 
			{
				// check to see if the value is set
				if (this._defaultSkinControl == null)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.DefaultSkinControl;
					else
						return this.ConstantDefaultSkinControl;
				}
				
				// return value
				return _defaultSkinControl;
			}
		}

		/// <summary>The default handler to use to create the output.</summary>
		public IHttpHandler DefaultPageHandler
		{
			get 
			{
				// check to see if the type has been stored yet
				if (this._defaultPageHandlerType == null) 
				{
					string pageHandlerString;

					// check to see if the value is set
					if (this._defaultSkinControl == null)
					{
						// check to see if there is a fall back settings set
						if (this._fallBackConfig != null)
							pageHandlerString = this._fallBackConfig._defaultPageHandler;
						else
							pageHandlerString = this.ConstantDefaultPageHandler;
					} 
					else 
						pageHandlerString = this._defaultPageHandler;

					// check to see if the set type inherits from IHttpHandler
					try 
					{
						Type type = System.Type.GetType(pageHandlerString, false, true);

						if (type.IsSubclassOf(typeof(IHttpHandler)))
							throw new InvalidCastException("DefaultHandler must use the interface IHttpHandler.");
				
						// set the interface for the handler
						this._defaultPageHandlerType = type;
					} 
					catch (NullReferenceException exc) 
					{
						throw new TypeInitializationException(_defaultPageHandler, exc);
					}
				}

				return (IHttpHandler)Activator.CreateInstance(this._defaultPageHandlerType);
			}
		}

		/// <summary></summary>
		public ExpirationType ExpirationType 
		{
			get 
			{
				// check to see if the value is set
				if (this._expirationType == ExpirationType.NotSet)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.ExpirationType;
					else
						return this.ConstantExpirationType;
				}
				
				// return value
				return _expirationType;
			}
		}

		/// <summary></summary>
		public double CacheTime 
		{
			get 
			{
				// check to see if the value is set
				if (this._cacheTime == -1)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.CacheTime;
					else
						return this.ConstantCacheTime;
				}
				
				// return value
				return _cacheTime;
			}
		}

		/// <summary></summary>
		public double DatabaseCacheTime 
		{
			get 
			{
				// check to see if the value is set
				if (this._databaseCacheTime == -1)
				{
					// check to see if there is a fall back settings set
					if (this._fallBackConfig != null)
						return this._fallBackConfig.DatabaseCacheTime;
					else
						return this.ConstantDatabaseCacheTime;
				}
				
				// return value
				return _databaseCacheTime;
			}
		}

		#endregion

		#region <providers>

		#region Private

		private StringDictionary _providers;

		#endregion

		/// <summary>
		/// Get instance directly from provider collection.
		/// </summary>
		/// <remarks>
		/// <para>This method will not go to the Community.config when looking for guidance one what
		/// to do when searching for the correct provider.</para>
		/// <para>This method first uses <paramref name="type"/> which must be attributed with 
		/// <see cref="RootProviderAttribute"/> and finds the <see cref="ProviderAttribute"/> that has
		/// the value of <paramref name="name"/> and inherits from <paramref name="type"/>.</para>
		/// </remarks>
		/// <param name="type">The <see cref="Type"/> that has a <see cref="RootProviderAttribute"/>.</param>
		/// <param name="name">The name of the <see cref="Object"/> that has <see cref="ProviderAttribute"/> and inherits from <paramref name="type"/>.</param>
		/// <returns>
		/// Returns an instance of the provider with the name of <paramref name="name"/> and and inherits
		/// from <paramref name="type"/>.
		/// </returns>
		public object GetProviderDirectly (Type type, string name) 
		{
			return Global.Providers[type, name];
		}

		/// <summary>
		/// Get an instance of the provider.
		/// </summary>
		/// <param name="name">The name of the provider.</param>
		/// <param name="checkType">The <see cref="Type"/> to check the provider against.</param>
		/// <returns>Returns the provider that is specified by <paramref name="name"/> or if the <paramref name="checkType"/> is different from the provider then a <see langword="null"/> reference is returned.</returns>
		public object GetProvider (string name, Type checkType) 
		{
			return this.GetProvider(name, checkType, false);
		}

		/// <summary>
		/// Get an instance of the provider.
		/// </summary>
		/// <param name="name">The name of the provider.</param>
		/// <param name="checkType">The <see cref="Type"/> to check the provider against.</param>
		/// <param name="throwError">Determins if an error should be thrown or a <see langword="null"/> reference should be returned.</param>
		/// <returns>Returns the provider that is specified by <paramref name="name"/> or if the <paramref name="checkType"/> is different from the provider then a <see langword="null"/> reference is returned.</returns>
		public object GetProvider (string name, Type checkType, bool throwError) 
		{
			object provider = this.GetProvider(name);

			// check to make sure that the type is the same as the one
			// being expected
			if (provider.GetType().IsSubclassOf(checkType) == false)
			{
				// check to see if an error should be thrown
				if (throwError) 
				{
					throw new ManagedFusionException(ExceptionType.Config,
						String.Format("{0} is not of type {1}.", name, checkType)
						);
				}
				else 
				{
					// return null because it wasn't of the correct type
					return null;
				}
			}

			return provider;
		}

		/// <summary>
		/// Get an instance of the provider.
		/// </summary>
		/// <param name="name">The name of the provider.</param>
		/// <returns>Returns the provider that is specified by <paramref name="name"/>.</returns>
		/// <exception cref="ManagedFusionException">
		///		<para><paramref name="name"/> is not a valid provider.</para>
		///		<para>-or-</para>
		///		<para>No valid mapping (alias) could be found for the provider.</para>
		///		<para>-or-</para>
		///		<para>The provider does not have any child node.</para>
		///	</exception>
		public object GetProvider (string name)
		{
			string cacheKey = "ConfigurationProvider-" + name;

			// check to see if the ouput is cached
			if (Global.Cache.IsCached(cacheKey) == false) 
			{
				// check for the name in the providers
				if (this._providers.ContainsKey(name))
				{
					object handler;

					// create the type from the providers type
					// this will check to see if it is an actual type
					// or just an alias type from the web.config mappings
					Type type = Type.GetType(this._providers[name]);

					// if it wasn't a type then get it from the config mapping
					if (type == null) 
					{
						try 
						{
							Type providerAlias = Global.WebConfig.GetMapping(name);
							handler = this.GetProviderDirectly(providerAlias, this._providers[name]);
						} 
						catch (ArgumentException exc) 
						{
							throw new ManagedFusionException(ExceptionType.Config,
								String.Format("The alias, {0}, is not valid, please check the web.config", name),
								exc
								);
						}
					}
					// else create an instance of the type
					else
					{
						handler = Activator.CreateInstance(type);
					}

					// if the object is a configuration provider handler
					if (handler is IConfigurationProviderHandler) 
					{
						XmlNode providerHandler = Global.WebConfig.ConfigurationProvider.GetProviderNode(name, this._location, this._communityID);

						if (providerHandler.HasChildNodes) 
						{
							// create the config object generated by the provider factory handler
							// get the first child node (because a provider should only contain one child node)
							// and create the object with that first child node
							object cachableObject = (handler as IConfigurationProviderHandler).Create(providerHandler.ChildNodes[0]);

							// cache the object
							Global.Cache.Add(cacheKey, cachableObject, TimeSpan.FromMinutes(CacheTime));
						}
						else
							throw new ManagedFusionException(ExceptionType.Config,
								String.Format("The configuration provider tag, named {0}, does not have any child node for processing.", name)
								);
					}
					// else just return the handler because it is a normal not configuration provider
					else
						return handler;
				} 
				else
					throw new ManagedFusionException(ExceptionType.Config,
						String.Format("No provider with the name of {0}.", name)
						);
			}

			return Global.Cache[cacheKey];
		}

		#endregion

		#region <filters>

		#region Private

		private FilterTagCollection _filters;

		#endregion

		/// <summary></summary>
		public FilterTagCollection Filters 
		{ 
			get { return _filters; }
		}

		#endregion

		#endregion

		public PortalConfiguration (XmlNode section, PortalConfiguration fallBackConfig, string location, int communityID) 
		{
			// set the location of this config file
			this._location = location;

			// set the community id that this config is associated with
			this._communityID = communityID;

			// set the fall back configuration settings if they exist
			this._fallBackConfig = fallBackConfig;

			// create providers and filters
			this._providers = new StringDictionary();
			this._filters = new FilterTagCollection();

			// get <settings>
			this.SetSettings(section.SelectSingleNode("settings"));

			// get <provider>
			this.SetProviders(section.SelectSingleNode("providers"));

			// get <filters>
			this.SetFilters(section.SelectSingleNode("filters"));
		}

		#region <settings>

		private void SetSettings (XmlNode settings) 
		{
			// collection of children in settings
			_settings = new StringDictionary();
			
			string key, value;

			// add each <add> node to the collection
			foreach(XmlNode node in settings.SelectNodes("add")) 
			{
				key = GetValue(node, "key", false);
				value = GetValue(node, "value", false);

				if (key != null
					&& key.Length > 0
					&& value != null
					&& value.Length > 0)
					_settings.Add(key, value);
			}
			
			// set the properties for the following values
			string s = null;

			s = _settings["DefaultLanguage"];
			try { if (s != null) _defaultLanguage = CultureInfo.CreateSpecificCulture(s); }
			catch (ArgumentException) { }

			s = _settings["DefaultTheme"];
			if (s != null) _defaultTheme = s;

			s = _settings["DefaultStyle"];
			if (s != null) _defaultStyle = s;

			s = _settings["DefaultSkinControl"];
			if (s != null) _defaultSkinControl = s;

			s = _settings["DefaultPageHandler"];
			if (s != null) _defaultPageHandler = s;

			s = _settings["ExpirationType"];
			try { if (s != null) _expirationType = (ExpirationType)Enum.Parse(typeof(ExpirationType), s, true); }
			catch (ArgumentException) { }

			s = _settings["CacheTime"];
			if (s != null) _cacheTime = XmlConvert.ToDouble(s);

			s = _settings["DatabaseConnectionString"];
			if (s != null) _databaseConnectionString = s;

			s = _settings["DatabaseCacheTime"];
			if (s != null) _databaseCacheTime = XmlConvert.ToDouble(s);
		}

		#endregion

		#region <providers>

		private void SetProviders (XmlNode providers) 
		{
			// add each <add> node to the collection
			foreach(XmlNode node in providers.SelectNodes("add")) 
			{
				_providers.Add(
					GetValue(node, "name", true),
					GetValue(node, "type", true)
					);
			}
		}

		#endregion

		#region <filters>

		private void SetFilters (XmlNode filters) 
		{
			// add each <add> node to the collection
			foreach(XmlNode node in filters.SelectNodes("add")) 
			{
				Filters.Add(
					new FilterTag(
						GetValue(node, "name", true),
						GetValue(node, "type", true),
						GetValue(node, "content", true)
					));
			}
		}

		#endregion

		private string GetValue (XmlNode node, string attribute, bool required) 
		{
			return Global.GetValue(node, attribute, required);
		}
	}
}