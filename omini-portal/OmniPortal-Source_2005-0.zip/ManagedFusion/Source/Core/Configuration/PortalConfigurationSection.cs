using System;
using System.Xml;
using System.Collections;

using ManagedFusion.Types;
using ManagedFusion.Data;

namespace ManagedFusion.Configuration
{
	public class PortalConfigurationSection
	{
		private string _DatabaseProviderString = "None";
		private string _ConfigurationProviderString = "Folder";
		private string _DatabaseConnectionString = "*.*";
		private string _PathProviderString = "MultiPath";
		private string _SyndicationProviderString = "Module";

		private Hashtable _mappings;

		private PortalConfigurationProvider _ConfigurationProvider;

		public PortalConfigurationSection(XmlNode section)
		{
			try 
			{
				// set the configuration provider
				if (section.Attributes["configurationProvider"] != null)
					_ConfigurationProviderString = section.Attributes["configurationProvider"].Value;

				// set the database provider
				if(section.Attributes["databaseProvider"] != null)
					_DatabaseProviderString = section.Attributes["databaseProvider"].Value;

				// set the database connection string
				if(section.Attributes["databaseConnectionString"] != null)
					_DatabaseConnectionString = section.Attributes["databaseConnectionString"].Value;

				// set the path provider
				if(section.Attributes["pathProvider"] != null)
					_PathProviderString = section.Attributes["pathProvider"].Value;

				// set the syndication provider
				if(section.Attributes["syndicationProvider"] != null)
					_SyndicationProviderString = section.Attributes["syndicationProvider"].Value;

				string name, type;
				Type mappedType;
				this._mappings = new Hashtable(section.ChildNodes.Count);

				foreach(XmlNode map in section.SelectNodes("map")) 
				{
					name = Global.GetValue(map, "name", true);
					type = Global.GetValue(map, "type", true);

					mappedType = Type.GetType(type);

					this._mappings.Add(name, mappedType);
				}
			} 
			catch { }
		}

		#region Web.Config Properties

		public string DatabaseConnectionString 
		{
			get { return this._DatabaseConnectionString; }
		}

		public string SyndicationProviderString 
		{
			get { return this._SyndicationProviderString; }
		}

		public string DatabaseProviderString 
		{
			get { return this._DatabaseProviderString; }
		}

		public string PathProviderString 
		{
			get { return this._PathProviderString; }
		}

		internal PortalConfigurationProvider ConfigurationProvider
		{
			get 
			{ 
				if (this._ConfigurationProvider == null)
					this._ConfigurationProvider = (PortalConfigurationProvider)Global.Providers[typeof(PortalConfigurationProvider), this._ConfigurationProviderString];

				return this._ConfigurationProvider;
			}
		}

		#endregion

		public Type GetMapping (string name) 
		{
			if (this._mappings.ContainsKey(name) == false)
				throw new ArgumentException(String.Format("The name, {0}, for the mapping is not valid.", name), "name");

			return (Type)this._mappings[name];
		}

		private PortalConfigurationCollection CommunityCollection 
		{
			get { return this.ConfigurationProvider.PortalConfiguration; }
		}

		public PortalConfiguration Default
		{ 
			get { return CommunityCollection.DefaultConfiguration; } 
		}

		public PortalConfiguration Current 
		{
			get 
			{
				// get portal
				CommunityInfo portal = CommunityInfo.Current;
				
				// if the portal hasn't been set yet use the default config
				if (portal == null)
					 return this.Default;
			
				return this[portal.ID]; 
			}
		}

		public PortalConfiguration this[int id] 
		{
			get { return CommunityCollection[id]; }
		}
	}
}
