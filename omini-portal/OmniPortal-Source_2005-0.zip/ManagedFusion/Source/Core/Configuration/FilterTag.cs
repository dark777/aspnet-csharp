using System;

namespace ManagedFusion.Configuration
{
	public class FilterTag
	{
		public FilterTag(string name, string type, string content)
		{
			this._Name = name;
			this._Type = type;
			this._Content = content;
		}

		private string _Name;
		public string Name { get { return _Name; } }

		private string _Type;
		public string Type { get { return _Type; } }

		private string _Content;
		public string Content { get { return _Content; } }
	}
}
