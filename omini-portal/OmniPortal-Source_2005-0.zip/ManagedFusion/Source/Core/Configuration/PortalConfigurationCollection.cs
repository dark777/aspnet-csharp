#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Xml;
using System.Collections;
using System.Collections.Specialized;
using System.Web.Caching;

// ManagedFusion Classes
using ManagedFusion.Types;

namespace ManagedFusion.Configuration
{
	[System.Xml.Serialization.XmlRoot("ManagedFusion")]
	public class PortalConfigurationCollection : ICollection
	{
		private Hashtable _innerDictionary;
		private object _defaultObjectKey;

		public PortalConfigurationCollection() 
		{ 
			this._innerDictionary = new Hashtable();
			this._defaultObjectKey = new object();
		}

		protected IDictionary InnerDictionary 
		{
			get { return _innerDictionary; }
		}

		public PortalConfiguration DefaultConfiguration 
		{
			get { return this[_defaultObjectKey]; }
		}

		public void SetDefaultConfiguration (PortalConfiguration value, string cacheKey, CacheDependency dependency, CacheItemRemovedCallback callback)
		{
			this.Add(_defaultObjectKey, value, cacheKey, dependency, callback);
		}

		public PortalConfiguration this[object id] 
		{
			get 
			{
				// get the portal config key
				string key = this.InnerDictionary[id] as string;

				// check to see if the key was found
				if (key == null)
					return this.DefaultConfiguration;

				// get the portal config
				PortalConfiguration config = Global.Cache[key, String.Empty] as PortalConfiguration;

				// if config is null then config is default
				if (config == null)
					return this.DefaultConfiguration;

				return config;
			}
		}

		public void Add (object id, PortalConfiguration config, string cacheKey, CacheDependency dependency, CacheItemRemovedCallback callback) 
		{
			if (this.InnerDictionary.Contains(id))
				this.InnerDictionary.Remove(id);

			// add id/cacheKey mapping to the dictionary
			this.InnerDictionary.Add(id, cacheKey);

			// add the config to cache
			Global.Cache.Add(cacheKey, String.Empty, config, TimeSpan.FromDays(1), dependency, CacheItemPriority.NotRemovable, callback);
		}

		public bool Contains (object id) 
		{
			return this.InnerDictionary.Contains(id);
		}

		#region ICollection Members

		bool ICollection.IsSynchronized
		{
			get { return this.InnerDictionary.IsSynchronized; }
		}

		public int Count { get { return this.InnerDictionary.Count; } }

		void ICollection.CopyTo(Array array, int index)
		{
			this.InnerDictionary.CopyTo(array, index);
		}

		object ICollection.SyncRoot
		{
			get { return this.InnerDictionary.SyncRoot; }
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator()
		{
			return new Enumerator(this.InnerDictionary.GetEnumerator());
		}

		private class Enumerator : IEnumerator
		{
			IDictionaryEnumerator _e;

			public Enumerator (IDictionaryEnumerator e) { _e = e; }

			#region IEnumerator Members

			public void Reset() { _e.Reset(); }

			public object Current { get { return _e.Value; } }

			public bool MoveNext() { return _e.MoveNext(); }

			#endregion
		}

		#endregion
	}
}