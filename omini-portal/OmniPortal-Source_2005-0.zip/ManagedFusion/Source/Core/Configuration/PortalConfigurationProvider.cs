using System;
using System.Xml;

using ManagedFusion.Providers;

namespace ManagedFusion.Configuration
{
	[RootProvider]
	public abstract class PortalConfigurationProvider
	{
		public abstract PortalConfiguration DefaultConfiguration { get; }
		public abstract PortalConfigurationCollection PortalConfiguration { get; }
		public abstract XmlNode GetProviderNode (string name, string location, int communityID);
	}
}
