#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Xml;
using System.Xml.Serialization;
using System.Configuration;

namespace ManagedFusion.Configuration
{
	/// <summary>
	/// Handles the configuration of the <see cref="ManagedFusion.Data.Provider">Provider</see> object.
	/// </summary>
	/// <remarks>
	/// <para>The <see cref="ManagedFusion.Data.Provider"/> object is created from configuration
	/// settings found in the <c>web.config</c> file under the node <c>providers</c> and then added in to the 
	/// Communities <see cref="ManagedFusion.PortalConfig.DefaultProvider"/></para>
	/// <note>Parts of this class were designed from Brian Ritchie's contribution to the Data Tools for Mono ADO.NET
	/// which gives a foundation for abstract data provider access within ManagedFusion.</note>
	/// </remarks>
	public class PortalConfigurationSectionHandler : IConfigurationSectionHandler 
	{
		#region IConfigurationSectionHandler Members

		/// <summary>
		/// Impliments <see cref="System.Configuration.IConfigurationSectionHandler.Create">IConfigurationSectionHandler.Create</see>.
		/// </summary>
		/// <param name="parent">The configuration settings in a corresponding parent configuration section.</param>
		/// <param name="configContext">An <see cref="System.Web.Configuration.HttpConfigurationContext"/> when <b>Create</b> is called from the ASP.NET configuration system. Otherwise, this parameter is reserved and is a <see langword="null"/> reference.</param>
		/// <param name="section">The <see cref="System.Xml.XmlNode"/> that contains the configuration information from the configuration file. Provides direct access to the XML contents of the configuration section.</param>
		/// <returns>A configuration object.</returns>
		public virtual object Create(object parent, object configContext, XmlNode section)
		{
			return new PortalConfigurationSection(section);
		}

		#endregion
	}
}