using System;
using System.Collections;

namespace ManagedFusion.Configuration
{
	public class FilterTagCollection : CollectionBase
	{
		public FilterTagCollection() { }

		internal void Add (FilterTag filter) 
		{
			if (this.InnerList.Contains(filter) == false)
				this.InnerList.Add(filter);
		}

		public FilterTag this [int i] 
		{
			get { return (FilterTag)this.InnerList[i]; }
		}

		public FilterTag this [string name] 
		{
			get 
			{
				// find the filter with same name
				foreach(FilterTag filter in this.InnerList)
					if (filter.Name.ToLower() == name.ToLower())
						return filter;

				// nothing found return null
				return null;
			}
		}
	}
}
