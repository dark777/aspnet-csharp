#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.ComponentModel;

namespace ManagedFusion.Display
{
	[DefaultProperty("Text")]
	[ToolboxData("<{0}:Title runat=server></{0}:Title>")]
	public class Title : WebControl
	{
		private string _text;
	
		[	Bindable(true), 
			Category("Data"), 
			DefaultValue("")] 
		public string Text 
		{
			get { return _text; }
			set 
			{
				Global.PageBuilder.PageTitle.Add(value); 
				_text = value;
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
#if DEBUG
			Context.Trace.Write("Title Element", "Adding " + Text);
			writer.WriteLine("<!-- {0} -->", Text);
#endif
		}
	}
}