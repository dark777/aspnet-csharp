using System;
using System.Web.UI;
using System.Collections.Specialized;

namespace ManagedFusion.Display
{
	public enum CssVersion 
	{
		One = 1,
		Two = 2,
		Default = Two
	}

	public class PageBuilder
	{
		internal PageBuilder () {}

		#region Properties

		private CssVersion _cssVersion = CssVersion.Default;
		/// <summary></summary>
		public CssVersion CssVersion 
		{
			get { return this._cssVersion; }
			set { this._cssVersion = value; }
		}

		/// <summary></summary>
		public StringCollection StyleSheets 
		{ 
			get 
			{
				if (Global.Context.Items["StyleSheetCollection"] == null)
					Global.Context.Items["StyleSheetCollection"] = new StringCollection();

				return (StringCollection)Global.Context.Items["StyleSheetCollection"]; 
			}
		}

		/// <summary></summary>
		public StringCollection PageHeadContent 
		{
			get 
			{
				if (Global.Context.Items["PageHeadContent"] == null)
					Global.Context.Items["PageHeadContent"] = new StringCollection();

				return (StringCollection)Global.Context.Items["PageHeadContent"];
			}
		}

		/// <summary></summary>
		public StringCollection PageTitle 
		{
			get 
			{
				if (Global.Context.Items["PageTitle"] == null)
					Global.Context.Items["PageTitle"] = new StringCollection();

				return (StringCollection)Global.Context.Items["PageTitle"];
			}
		}

		/// <summary></summary>
		public NameValueCollection PageMetaData 
		{
			get 
			{
				if (Global.Context.Items["PageMetaData"] == null)
					Global.Context.Items["PageMetaData"] = new NameValueCollection();

				return (NameValueCollection)Global.Context.Items["PageMetaData"];
			}
		}

		/*****************************************************************************
		 * Form Tag Manipulation
		 */
		/// <summary>
		/// Used to add attribute <c>enctype="multipart/form-data"</c> to the pages form,
		/// for uploading of data.
		/// </summary>
		public bool FormUploadMode 
		{
			get 
			{
				if (Global.Context.Items["FormUploadMode"] == null)
					FormUploadMode = false;
				return (bool)Global.Context.Items["FormUploadMode"];
			}
			set { Global.Context.Items["FormUploadMode"] = value; }
		}
		/*
		 *****************************************************************************/

		/*****************************************************************************
		 * Body Tag Manipulation
		 */

		/// <summary>
		/// Used to allow the use of <c>frameset</c> tag in the page.
		/// </summary>
		public bool FramesetMode 
		{
			get 
			{
				if (Global.Context.Items["FramesetMode"] == null)
					FramesetMode = false;
				return (bool)Global.Context.Items["FramesetMode"];
			}
			set { Global.Context.Items["FramesetMode"] = value; }
		}

		/*
		 *****************************************************************************/

		#endregion

		#region Methods

		public void RenderPageStart (HtmlTextWriter writer) 
		{
			// creates a string builder to construct the page header
			writer.Indent = 0;
			writer.WriteLine(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01//EN"" ""http://www.w3.org/TR/html4/strict.dtd"">");

			writer.WriteLine("<!-- {0} -->", Global.Properties.PortalCopyright);
			writer.WriteLine();

			// add start to page
			writer.WriteFullBeginTag("html");
			writer.WriteLine();
		}

		public void RenderHead (HtmlTextWriter writer) 
		{
			PortalHead head = new PortalHead(this);

			// render head
			head.RenderControl(writer);
			writer.WriteLine();
		}

		public void RenderBodyStart (HtmlTextWriter writer) 
		{
			writer.WriteLine();

			// start body
			if (!FramesetMode) writer.WriteFullBeginTag("body");
			writer.WriteLine();
		}

		public void RenderBodyEnd (HtmlTextWriter writer) 
		{
			// add end to page and reset indent;
			writer.Indent = 0;
			writer.WriteLine();
			if (!FramesetMode) writer.WriteEndTag("body");
			writer.WriteLine();
		}

		public void RenderPageEnd (HtmlTextWriter writer) 
		{
			writer.WriteEndTag("html");
		}

		#endregion
	}
}
