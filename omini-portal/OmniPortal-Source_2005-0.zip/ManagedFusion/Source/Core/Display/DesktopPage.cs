#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;

namespace ManagedFusion.Display
{
	/// <summary>
	/// Main page for the desktop version of the website.
	/// </summary>
	public class DesktopPage : Page
	{
		/// <summary>Renders the page for output to the client.</summary>
		/// <param name="writer">The writer used for writing to the client.</param>
		protected override void Render(HtmlTextWriter writer)
		{
			// render the start of the page
			Global.PageBuilder.RenderPageStart(writer);

			// render the head
			Global.PageBuilder.RenderHead(writer);

			// render the start of the body
			Global.PageBuilder.RenderBodyStart(writer);

			// render the controls added durring PortalDesktop_Init
			this.RenderChildren(writer);

			// rend the end of the body
			Global.PageBuilder.RenderBodyEnd(writer);

			// render the end of the body
			Global.PageBuilder.RenderPageEnd(writer);
		}

		protected override void OnInit(EventArgs e)
		{
			this.Controls.Clear();

			SectionInfo section = SectionInfo.Current;
			CommunityInfo community = CommunityInfo.Current;

			// set the view state key to the name of the user
			this.ViewStateUserKey = Global.Security.Identity.Name;

			// set CSS type that page supports
			Global.PageBuilder.CssVersion = CssVersion.Two;

			// add community header to page header
			Global.PageBuilder.PageHeadContent.Add(community.HeaderText);

			// add theme header to page header
			Global.PageBuilder.PageHeadContent.Add(section.Theme.HeaderText);

			// set the page id
			this.ID = "Page";

			// create Form Control
			PortalForm pageForm = new PortalForm(Global.PageBuilder);
			pageForm.ID = "PageForm";

			// set page title elements
			Global.PageBuilder.PageTitle.Add(community.Title);
			Global.PageBuilder.PageTitle.Add(section.Title);

			// set the page meta info
			Global.PageBuilder.PageMetaData.Add("generator", String.Format("<meta name=\"generator\" content=\"{0}\">", Global.Properties.SoftwareName));
			Global.PageBuilder.PageMetaData.Add(section.MetaProperties);

			// check to see if this section is syndicated
			if (section.Syndicated)
				Global.PageBuilder.PageMetaData.Add(
					"syndication", 
					String.Format("<link rel=\"alternate\" title=\"{0} Feed\" href=\"{1}?feed\" type=\"application/x.atom+xml\">", 
						section.Title, 
						section.UrlPath.ToString()
						)
					);

			// add page style to style list, put this at the top of the style sheet list
			Global.PageBuilder.StyleSheets.Insert(0, section.Style.Path);

			// load the page skin
			Control pageSkin;
			
			// checks to see if there should be a theme applied to this section
			if (SectionInfo.Current.NoTheme) 
				pageSkin = Global.ExecutingModule.GetContentHolder(Position.Center);
			else 
				pageSkin = Global.Path.GetControlFromLocation(
					Global.Path.GetPagePath(community.Config.DefaultSkinControl)
					);

			pageSkin.ID = "PageContent";

			// add page skin to form
			pageForm.Controls.Add(pageSkin);

			// add the form to the page
			this.Controls.Add(pageForm);

			base.OnInit (e);
		}
	}
}