#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;

namespace ManagedFusion.Display
{
	/// <summary>
	/// Overridden to provide support for the ManagedFusion PathInfo page.
	/// </summary>
	internal class PortalHead : HtmlContainerControl
	{
		private PageBuilder _builder;

		public PortalHead (PageBuilder builder) : base("head") 
		{
			this._builder = builder;
		}

		#region Properties

		public CssVersion CssVersion 
		{
			get { return _builder.CssVersion; }
		}

		public string Title 
		{
			get 
			{
				string[] elements = new string[_builder.PageTitle.Count];
				_builder.PageTitle.CopyTo(elements, 0);
				return String.Join(" - ", elements);
			}
		}

		public StringCollection Content 
		{
			get { return _builder.PageHeadContent; }
		}

		public NameValueCollection MetaData 
		{
			get { return _builder.PageMetaData; }
		}

		public StringCollection Link 
		{
			get { return _builder.StyleSheets; }
		}

		#endregion

		#region Render Tag

		public override string TagName { get { return "head"; } }

		protected override void RenderBeginTag(HtmlTextWriter writer)
		{
			writer.WriteFullBeginTag(TagName);
		}

		protected override void RenderEndTag(HtmlTextWriter writer)
		{
			writer.WriteEndTag(TagName);
		}

		#endregion

		protected override void RenderChildren(HtmlTextWriter writer)
		{
			writer.Indent++;
			writer.WriteLine();

			// add the page title
			writer.WriteLine("<title>{0}</title>", this.Title);
			writer.WriteLine();

			// add the page meta data info
			foreach(string key in this.MetaData.Keys)
				writer.WriteLine(this.MetaData[key]);

			writer.WriteLine();

			// render the correct CSS style version
			switch((int)this.CssVersion) 
			{
				case 1 : 
					this.RenderCss1(writer);
					break;

				case 2 :
					this.RenderCss2(writer);
					break;
			}

			writer.WriteLine();

			// add content to page
			writer.WriteLine("<!-- Start of Head Content -->");
			writer.WriteLine();

			string[] content = new string[this.Content.Count];
			this.Content.CopyTo(content, 0);
			
			// write the full content with empty line between each
			writer.WriteLineNoTabs(String.Join(
				String.Concat(Environment.NewLine, Environment.NewLine), 
				content)
				);

			writer.WriteLine();
			writer.WriteLine("<!-- End of Head Content -->");

			writer.Indent--;
		}

		private void RenderCss1 (HtmlTextWriter writer) 
		{
			// add all style sheets to page
			foreach (string style in this.Link)
				writer.WriteLine("<link rel=\"stylesheet\" href=\"{0}\" type=\"text/css\">", style);

			writer.WriteLine();
		}

		private void RenderCss2 (HtmlTextWriter writer) 
		{
			writer.WriteLine("<!-- to correct the unsightly Flash of Unstyled Content. http://www.bluerobot.com/web/css/fouc.asp -->");
			writer.WriteLine(@"<script type=""text/javascript""></script>");
			writer.WriteLine();

			writer.WriteLine(@"<style type=""text/css"" media=""all"" title=""OmniPortalStyles"">");
			writer.Indent++;

			// add all style sheets to page
			foreach (string style in this.Link)
				writer.WriteLine(@"@import ""{0}"";", style);

			writer.Indent--;
			writer.WriteEndTag("style");
			writer.WriteLine();
		}
	}
}