#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace ManagedFusion.Display
{
	/// <summary>
	/// Overridden to provide support for the ManagedFusion PathInfo page.
	/// </summary>
	internal class PortalForm : HtmlForm
	{
		private PageBuilder _builder;

		public PortalForm (PageBuilder builder)
		{
			this._builder = builder;
		}

		/// <summary>
		/// Raises the PreRender event to check for <see cref="ManagedFusion.Global.FormUploadMode">FormUploadMode</see>.
		/// </summary>
		/// <param name="e">An EventArgs object that contains the event data.</param>
		protected override void OnPreRender(EventArgs e)
		{
			this.Enctype = (_builder.FormUploadMode == true) ?
				"multipart/form-data" : "application/x-www-form-urlencoded";

			base.OnPreRender (e);
		}

		/// <summary>
		/// Renders the form tag using the defined ManagedFusion way, that adds the whole path
		/// to the <c>action</c> attribute, that ASP.Net doesn't support.
		/// </summary>
		/// <param name="writer">The writer used to write the output.</param>
		protected override void RenderAttributes(HtmlTextWriter writer)
		{
			writer.WriteAttribute("name", this.Name);
			this.Attributes.Remove("name");

			writer.WriteAttribute("method", this.Method);
			this.Attributes.Remove("method");

			writer.WriteAttribute("action", this.Action, true);
			this.Attributes.Remove("action");

			writer.WriteAttribute("enctype", this.Enctype);
			this.Attributes.Remove("enctype");

			// check for an onsubmit event for HtmlForm
			string onSubmit = this.Page_ClientOnSubmitEvent;
			if (onSubmit != null && onSubmit.Length > 0) 
			{
				if (this.Attributes["onsubmit"] != null) 
				{
					onSubmit = onSubmit + this.Attributes["onsubmit"];
					this.Attributes.Remove("onsubmit");
				}

				// add the attributes for onsubmit
				writer.WriteAttribute("language", "javascript");
				writer.WriteAttribute("onsubmit", onSubmit);
			}

			// write the id to the attributes
			writer.WriteAttribute("id", this.ClientID);

			// this is for HtmlContainerControl
			this.ViewState.Remove("innerhtml");

			// this if for HtmlControl
			this.Attributes.Render(writer);
		}

		/// <summary>Gets the target url of the form post.</summary>
		/// <remarks>Leave blank to postback to the same page.</remarks>
		protected virtual string Action 
		{
			get { return Global.Context.Request.RawUrl; }
		}

		/// <summary>
		/// Uses reflection to access the ClientOnSubmitEvent property of the Page class
		/// </summary>
		private string Page_ClientOnSubmitEvent 
		{
			get 
			{
				Type targetType = typeof(System.Web.UI.Page);
				PropertyInfo property = targetType.GetProperty("ClientOnSubmitEvent", BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.NonPublic );
				
				if ( property != null ) 
					return (string)property.GetValue(this.Page, null);
				else
					return null;
			}
		}
	}
}