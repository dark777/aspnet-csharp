#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Resources;
using System.Reflection;

namespace ManagedFusion.Display
{
	public sealed class CultureManager
	{
		private readonly bool _resourceFound;
		private ResourceManager _resource;

		// only lets the internal assembly create the CultureManager
		internal CultureManager(string baseName, Type type)
		{
			// sets resource found
			_resourceFound = true;

			// sets values based on constructor parameters
			try 
			{
				_resource = new ResourceManager(
					  String.Format("{0}.Culture.{1}", type.Namespace, baseName), 
					  type.Assembly); 
			}
			// sets resource not found so it will default to the Global
			catch (ArgumentNullException) { _resourceFound = false; }
		}

		public bool ResourceFound { get { return _resourceFound; } }

		public string this [string name] { get { return this.GetString(name); } }

		public string GetString(string name)
		{
			string resource;

			try 
			{
				// checks to see if resource was found
				if (!ResourceFound) throw new MissingManifestResourceException("Resource not found, so defaulting to Global resource.");

				// returns the value of the resource
				resource = _resource.GetString(name, Global.SelectedCulture);

				if (resource == null) throw new MissingManifestResourceException("Resource not found, so defaulting to Global resource.");
			} 
			catch (MissingManifestResourceException) 
			{
				// returns the value from the Global resource because it was not found in the local one.
				resource = Global.CultureResource.GetString(name, Global.SelectedCulture);
			}

			return resource;
		}
	}
}