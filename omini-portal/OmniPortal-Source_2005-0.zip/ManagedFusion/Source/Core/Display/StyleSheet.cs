#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Drawing.Design;
using System.Web.UI;
using System.Web.UI.Design;
using System.Web.UI.WebControls;
using System.Diagnostics;
using System.ComponentModel;

namespace ManagedFusion.Display
{
	[DefaultProperty("Location")]
	[ToolboxData("<{0}:StyleSheet runat=server></{0}:StyleSheet>")]
	public class StyleSheet : WebControl
	{
		private string _location;
	
		[	Bindable(true), 
			Category("Data"), 
			DefaultValue(""),
			Editor(typeof(UrlEditor), typeof(UITypeEditor))] 
		public string Location 
		{
			get { return _location; }
			set 
			{
				Global.PageBuilder.StyleSheets.Add(value); 
				_location = value;
			}
		}

		protected override void Render(HtmlTextWriter writer)
		{
#if DEBUG
			Context.Trace.Write("Style Sheet", "Adding " + Location);
			writer.WriteLine("<!-- {0} -->", Location);
#endif
		}
	}
}