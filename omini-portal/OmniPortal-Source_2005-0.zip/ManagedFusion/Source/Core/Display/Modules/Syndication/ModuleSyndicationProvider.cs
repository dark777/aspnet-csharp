using System;
using System.Web;

// ManagedFusion Classes
using ManagedFusion.Syndication;
using ManagedFusion.Providers;

namespace ManagedFusion.Display.Modules.Syndication
{
	[Provider("Module")]
	public class ModuleSyndicationProvider : SyndicationProvider
	{
		public override ISyndication Feed
		{
			get { return Global.ExecutingModule.Syndication; }
		}

		public override IHttpHandler Handler
		{
			get { return new ModuleSyndicationHandler(this.Feed); }
		}
	}
}
