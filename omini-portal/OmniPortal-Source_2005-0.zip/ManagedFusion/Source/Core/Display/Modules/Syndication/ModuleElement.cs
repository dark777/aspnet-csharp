using System;

using Atom.AdditionalElements;

namespace ManagedFusion.Display.Modules.Syndication
{
	internal class ModuleElement : ScopedElement
	{
		public ModuleElement(string name) : this(name, String.Empty) { }

		public ModuleElement(string name, string content)
		{
			this.LocalName = name;
			this.Content = content;
		}

		public override string NamespacePrefix { get { return "mf"; } }

		public override Uri NamespaceUri { get { return new Uri("http://tempurl.org"); } }
	}
}
