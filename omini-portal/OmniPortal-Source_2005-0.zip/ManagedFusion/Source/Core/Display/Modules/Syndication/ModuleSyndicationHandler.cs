using System;

using ManagedFusion.Syndication;

namespace ManagedFusion.Display.Modules.Syndication
{
	public class ModuleSyndicationHandler : BaseSyndicationHandler
	{
		ISyndication _syndication;

		public ModuleSyndicationHandler(ISyndication syn) 
		{
			this._syndication = syn;
		}

		protected override string CacheKey { get { return this.SectionInformation.ID.ToString(); } }

		protected override SyndicationCacheItem CreateSyndication()
		{
			SyndicationCacheItem item = new SyndicationCacheItem();

			item.LastModified = this._syndication.LastModified;
			item.Xml = this._syndication.Serialize();

			return item;
		}
	}
}
