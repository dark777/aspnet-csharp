using System;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Syndication;
using ManagedFusion.Display.Modules.Syndication;

namespace ManagedFusion.Display.Modules
{
	/// <summary>Event handler for PopulateContent.</summary>
	public delegate void LoadSyndicationEventHandler (object sender, LoadSyndicationEventArgs e);

	/// <summary>Event argumnets for PopulateContent.</summary>
	public class LoadSyndicationEventArgs : EventArgs 
	{
		/// <summary>Creates an instance of PopulateHoldersEventArgs.</summary>
		public LoadSyndicationEventArgs(ModuleFeed feed) 
		{
			this._Feed = feed;
		}

		private ModuleFeed _Feed;
		/// <summary>Left column place holder.</summary>
		public ModuleFeed Feed 
		{ 
			get { return this._Feed; } 
		}
	}
}
