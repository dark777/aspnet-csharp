using System;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;

namespace ManagedFusion.Display.Modules
{
	/// <summary>Event handler for PupulateHolders.</summary>
	public delegate void LoadModuleEventHandler (object sender, LoadModuleEventArgs e);

	/// <summary>Event argumnets for PopulateHolders.</summary>
	public class LoadModuleEventArgs : EventArgs 
	{
		private PlaceHolder[] _holders;

		/// <summary>
		/// Creates an instance of PopulateHoldersEventArgs.
		/// </summary>
		/// <param name="holders"></param>
		public LoadModuleEventArgs(PlaceHolder[] holders) 
		{
			this._holders = holders;
		}

		/// <summary>Left column place holder.</summary>
		public PlaceHolder Left { get { return this._holders[(int)Position.Left]; } }

		/// <summary>Center column place holder.</summary>
		public PlaceHolder Center { get { return this._holders[(int)Position.Center]; } }
		
		/// <summary>Right column place holder.</summary>
		public PlaceHolder Right { get { return this._holders[(int)Position.Right]; } }
	}
}
