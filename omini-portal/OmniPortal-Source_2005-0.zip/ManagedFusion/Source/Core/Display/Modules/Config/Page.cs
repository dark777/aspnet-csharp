#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Web;
using System.Xml.Serialization;
using System.Security.Permissions;
using System.Text.RegularExpressions;

namespace ManagedFusion.Display.Modules.Config
{
	public class Page
	{
		#region Properties

		#region Xml Attributes

		private string _pattern;
		[	XmlAttribute("pattern")]
		public string Pattern 
		{ 
			get { return _pattern; }
			set { _pattern = value; }
		}

		private string _control;
		[	XmlAttribute("control")]
		public string Control 
		{ 
			get { return _control; }
			set { _control = value; }
		}

		private string _access;
		[	XmlAttribute("access")]
		public string Access 
		{ 
			get { return _access; }
			set { _access = value; }
		}

		private string _type;
		[	XmlAttribute("type")]
		public string Type 
		{ 
			get { return _type; }
			set { _type = value; }
		}

		private string _transform;
		[	XmlAttribute("transform")]
		public string Transform 
		{ 
			get { return _transform; }
			set { _transform = value; }
		}

		#endregion

		[XmlIgnore]
		public IHttpHandler HandlerObject
		{
			get 
			{
				// check to see if the set type inherits from IHttpHandler
				try 
				{
					Type type = System.Type.GetType(Type, false, true);
					Type typeInterface = type.GetInterface("IHttpHandler");

					if (typeInterface == null)
						throw new InvalidCastException("Page.Type must use the interface IHttpHandler.");
				
					return (IHttpHandler)Activator.CreateInstance(type);
				} 
				catch (NullReferenceException exc) 
				{
					throw new TypeInitializationException(Type, exc);
				}
			}
		}

		private Regex _pageRegex;
		[XmlIgnore]
		protected Regex Regex
		{
			get
			{
				if(_pageRegex == null)
					_pageRegex = new Regex(this.Pattern,RegexOptions.IgnoreCase|RegexOptions.Compiled);

				return _pageRegex;
			}
		}

		[XmlIgnore]
		public string[] Controls 
		{
			get { return Control.Split(Global.Delimiter); } 
		}

		[XmlIgnore]
		public string[] Tasks 
		{
			get 
			{
				if (Access != null)
					return Access.Split(Global.Delimiter); 
				else
					return new string[] { Task.ViewPageName };
			}
		}

		#endregion

		public bool IsMatch (string path)
		{
			return Regex.IsMatch(path);
		}

		public string TransformPath (string path) 
		{
			return Regex.Replace(path.ToLower(), this.Pattern.ToLower(), this.Transform);
		}
	}
}