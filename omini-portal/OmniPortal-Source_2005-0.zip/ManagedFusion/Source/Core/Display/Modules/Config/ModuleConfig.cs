#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.IO;
using System.Data;
using System.Xml.Serialization;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Display.Modules.Config
{
	[XmlRoot("module")]
	public class ModuleConfig
	{
		private Page[] _pages;
		[	XmlArray("pages"),
			XmlArrayItem("page", typeof(Page))]
		public Page[] Pages 
		{ 
			get { return _pages; }
			set { _pages = value; }
		}

		private Task[] _tasks;
		[	XmlArray("tasks"),
			XmlArrayItem("task", typeof(Task))]
		public Task[] Tasks 
		{ 
			get { return _tasks; }
			set { _tasks = value; }
		}

		private Setup _install;
		[	XmlElement("install", typeof(Setup))]
		public Setup Install 
		{ 
			get { return _install; } 
			set { _install = value; }
		}

		private Setup _uninstall;
		[	XmlElement("uninstall", typeof(Setup))]
		public Setup Uninstall 
		{ 
			get { return _uninstall; } 
			set { _uninstall = value; }
		}

		public string this [string path] 
		{
			get 
			{
				Page p = FindPage(path); 

				return (p == null) ? String.Empty : p.Control;
			}
		}

		public Page FindPage (string path) 
		{
			foreach(Page p in Pages)
				if (p.IsMatch(path))
					return p;

			return null;
		}

		internal void InstallModule () 
		{
			this.ExecuteSetupScript(Install);
		}

		internal void UninstallModule () 
		{
			this.ExecuteSetupScript(Uninstall);
		}

		private void ExecuteSetupScript (Setup setup) 
		{ 
			// run presetup script
			setup.RunPreSetup();
			
			foreach(string file in setup.SqlScripts) 
			{
				// Create an instance of StreamReader to read from a file.
				using (StreamReader reader = new StreamReader(file)) 
				{

				}
			}

			// run postsetup script
			setup.RunPostSetup();
		}
	}
}