#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Xml.Serialization;

// ManagedFusion Classes
using ManagedFusion.Display.Modules;

namespace ManagedFusion.Display.Modules.Config
{
	public class Setup : IModuleSetup
	{
		private string[] _sqlScripts;
		[	XmlArray("sql"),
			XmlArrayItem("file", typeof(string))]
		public string[] SqlScripts 
		{
			get { return _sqlScripts; }
			set { _sqlScripts = value; }
		}

		private string _type;
		[	XmlAttribute("type")]
		public string Type 
		{
			get { return _type; }
			set { _type = value; }
		}

		[	XmlIgnore]
		protected IModuleSetup ModuleSetupObject
		{ 
			get 
			{
				// check to see if the set type inherits from IModuleSetup
				try 
				{
					Type type = System.Type.GetType(Type, false, true);
					Type typeInterface = type.GetInterface("IModuleSetup");

					if (typeInterface == null)
						throw new InvalidCastException("Setup.Type must use the interface IModuleSetup.");
				
					return (IModuleSetup)Activator.CreateInstance(type);
				} 
				catch (NullReferenceException exc) 
				{
					throw new TypeInitializationException(Type, exc);
				}
			}
		}

		#region IModuleSetup Members

		public void RunPreSetup()
		{
			this.ModuleSetupObject.RunPreSetup();
		}

		public void RunPostSetup()
		{
			this.ModuleSetupObject.RunPostSetup();
		}

		#endregion
	}
}