using System;
using System.Web.UI;

namespace ManagedFusion.Display.Modules
{
	/// <summary>Event handler for GetControlUnsucessful.</summary>
	public delegate void GetControlUnsuccessfulEventHandler (object sender, GetControlUnsuccessfulEventArgs e);
	
	/// <summary>Event arguments for GetControlUnsuccessful.</summary>
	public class GetControlUnsuccessfulEventArgs : EventArgs 
	{
		private Exception _exc;
		private bool _throwExc;
		private Control _returnControl;

		/// <summary>
		/// Creates an instance of GetControlUnsuccessfulEventArgs.
		/// </summary>
		/// <param name="exc"></param>
		public GetControlUnsuccessfulEventArgs(Exception exception) 
		{
			this._exc = exception;
#if DEBUG
			this._throwExc = true;
#else
			this._throwExc = false;
#endif
			this._returnControl = new LiteralControl("<center>Sorry we were unable to find the requested page.</center>");
		}

		/// <summary>The exception that was thrown.</summary>
		public Exception ExceptionReturned 
		{
			get { return this._exc; }
		}

		/// <summary>Throw the exception.</summary>
		public bool ThrowException 
		{
			get { return _throwExc; }
			set { _throwExc = value; }
		}

		/// <summary>The control that should be returned if the exceptions is thrown.</summary>
		public Control ReturnControl 
		{
			get { return _returnControl; }
			set { _returnControl = value; }
		}
	}
}
