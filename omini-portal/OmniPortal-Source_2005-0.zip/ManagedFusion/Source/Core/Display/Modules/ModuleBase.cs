#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Resources;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Caching;
using System.Threading;
using System.Security.Permissions;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Data;
using ManagedFusion.Types;
using ManagedFusion.Syndication;
using ManagedFusion.Display.Modules.Syndication;
using ManagedFusion.Security;
using ManagedFusion.Display.Containers;
using ManagedFusion.Display.Modules.Config;

namespace ManagedFusion.Display.Modules
{
	/// <summary>The base class for all modules created for ManagedFusion.</summary>
	public abstract class ModuleBase : IModule
	{
		private PlaceHolder[] _holders;
		private ModuleAttribute _attribute;

		#region Events

		/// <summary>Occurs when the module cannot get a control from the passed location.</summary>
		public event GetControlUnsuccessfulEventHandler GetControlUnsuccessful;

		/// <summary>Occurs when the module cannot get a control from the passed location.</summary>
		/// <param name="e">Events.</param>
		protected virtual void OnGetControlUnsuccessful (GetControlUnsuccessfulEventArgs e) 
		{
			if (GetControlUnsuccessful != null) 
				GetControlUnsuccessful(this, e);
		}

		public event EventHandler Installed;

		protected virtual void OnInstalled (EventArgs e) 
		{
			if (Installed != null)
				Installed(this, e);
		}

		public event EventHandler UnInstalled;

		protected virtual void OnUnInstalled (EventArgs e) 
		{
			if (UnInstalled != null)
				UnInstalled(this, e);
		}

		/// <summary>Occurs when the module is initialized, which is the first step in the its lifecycle right after authentication is checked.</summary>
		public event EventHandler Init;

		/// <summary>Occurs when the module is initialized, which is the first step in the its lifecycle right after authentication is checked.</summary>
		/// <param name="e">Events.</param>
		protected virtual void OnInit (EventArgs e)
		{
			if (Init != null)
				Init(this, e);
		}

		public event LoadSyndicationEventHandler LoadSyndication;

		protected virtual void OnLoadSyndication (LoadSyndicationEventArgs e) 
		{
			if (LoadSyndication != null)
				LoadSyndication(this, e);
		}

		/// <summary>Occurs when the module holders are getting populated with the module controls.</summary>
		public event LoadModuleEventHandler Load;

		/// <summary>Occurs when the module holders are getting populated with the module controls.</summary>
		/// <param name="e">Events.</param>
		protected virtual void OnLoad (LoadModuleEventArgs e)
		{
			if (Load != null) 
				Load(this, e);
		}

		#endregion

		#region Constructor

		/// <summary>
		/// 
		/// </summary>
		protected ModuleBase ()
		{
			if (this.GetType().IsDefined(typeof(ModuleAttribute), false) == false) 
				throw new ManagedFusionException(ExceptionType.BusinessLayer,
					String.Format("{0} doesn't contain ModuleAttribute", this.GetType())
					);

			// get the module attribute
            this._attribute = this.GetType().GetCustomAttributes(typeof(ModuleAttribute), false)[0] as ModuleAttribute;

			// launch event Init
			this.OnInit(EventArgs.Empty);

			// setup content feed
			this._Syndication = new ModuleFeed(this.SectionInformation);

			// create culture information
			this._CultureManager = new CultureManager(this._attribute.CultureResourceName, this.GetType());

			// configure modules place holder
			this._holders = new PlaceHolder[] {new PlaceHolder(), new PlaceHolder(), new PlaceHolder()};

			// process config file
			ProcessConfigFile();

			// get properties for section
			this._Properties = this.SectionInformation.ModuleData;
		}

		#endregion

		#region Properties

		/// <summary>The web servers Context used in this application.</summary>
		/// <remarks>This is here for the convience of the module developer.</remarks>
		protected HttpContext Context { get { return Global.Context; } }

		/// <summary>A reference for <see cref="SiteInfo">SiteInfo</see>.</summary>
		/// <remarks>This is here for the convience of the module developer.</remarks>
		protected SiteInfo SiteInformation { get { return SiteInfo.Current; } }

		/// <summary>A reference for <see cref="SectionInfo">SectionInfo</see>.</summary>
		/// <remarks>This is here for the convience of the module developer.</remarks>
		protected SectionInfo SectionInformation { get { return SectionInfo.Current; } }

		/// <summary>A reference for <see cref="CommunityInfo">CommunityInfo</see>.</summary>
		/// <remarks>This is here for the convience of the module developer.</remarks>
		protected CommunityInfo CommunityInformation { get { return CommunityInfo.Current; } }

		#endregion

		#region Methods

		#region Setup Methods

		/// <summary></summary>
		private void ConfigureContainers () 
		{
			ContainerCollection containers = this.SectionInformation.Containers;
#if DEBUG
			Context.Trace.Write("ModuleBase", String.Concat(containers.Count.ToString(), " Container(s) Found"));
#endif
			// left pane
			foreach(ContainerInfo c in containers.GetContainersForPosition((int)Position.Left)) 
				this._holders[(int)Position.Left].Controls.Add(new ContainerHolder(c));

			// center pane
			foreach(ContainerInfo c in containers.GetContainersForPosition((int)Position.Center)) 
				this._holders[(int)Position.Center].Controls.Add(new ContainerHolder(c));

			// right pane
			foreach(ContainerInfo c in containers.GetContainersForPosition((int)Position.Right)) 
				this._holders[(int)Position.Right].Controls.Add(new ContainerHolder(c));
		}

		/// <summary>Process the <c>Module.config</c> file located in the module directory.</summary>
		[FileIOPermission(SecurityAction.Demand)]
		private void ProcessConfigFile () 
		{
			string configLocation = this._attribute.ConfigLocation;
			string key = configLocation + "ConfigFile";
#if DEEP
			Context.Trace.Write("ModuleBase", "Module.config Location : " + configLocation);
#endif
			if(Global.Cache.IsCached(key, String.Empty) == false) 
			{
				// create the reader
				StreamReader reader = StreamReader.Null;
				
				try 
				{
					// check on where the application should look for a config file
					if (this._attribute.FolderBased == false) 
					{
						reader = new StreamReader(this.GetType().Assembly.GetManifestResourceStream(this._attribute.ConfigLocation));
					}
					else 
					{
						reader = new StreamReader(Global.Path.GetAbsoluteDiskPath(configLocation));
					}

					XmlSerializer ser = new XmlSerializer(typeof(ModuleConfig));
					this._config = (ModuleConfig)ser.Deserialize(reader);
				
					// add to the cache
					Global.Cache.Add(key, String.Empty, this._config);
				}
				finally 
				{
					// close the reader
					reader.Close();
				}
			}
			else 
			{
				// gets the cached config collection
				this._config = (ModuleConfig)Global.Cache[key, String.Empty];
			}
		}

		private void AddControlsToCenter (ManagedFusion.Display.Modules.Config.Page page) 
		{
			// load current control according to the page address
			foreach(Control control in GetControls(page))
				this._holders[(int)Position.Center].Controls.Add(control);
		}

		#endregion

		/// <summary>Gets the controls that is called from the current module for the location.</summary>
		/// <remarks>Gets the controls that is called from the current module for the location.  
		/// This method splits the <see cref="ManagedFusion.Display.Modules.ModuleBase.Location">Location</see>
		/// with the <see cref="ManagedFusion.Global.Delimiter">Delimiter</see> and then gets each control.
		/// If a control cannot be found then it goes to the default theme and gets that version 
		/// of the control.</remarks>
		/// <param name="page">The page to get the controls from.</param>
		/// <returns>The control that was loaded.</returns>
		private Control[] GetControls (ManagedFusion.Display.Modules.Config.Page page) 
		{
			ArrayList controls = new ArrayList(0);

			// add all the controls to the controls list
			if (page.Control != null)
				foreach(string controlLocation in page.Controls)
					controls.Add(GetControl(controlLocation));

			return (Control[])controls.ToArray(typeof(Control));
		}

		/// <summary>Gets the control that is called from the module.</summary>
		/// <remarks>Gets the control that is called from the current module.  If the control cannot be found
		/// then it goes to the default theme and gets that version of the control.</remarks>
		/// <param name="controlLocation">The controls location.</param>
		/// <returns>The control that was loaded.</returns>
		protected Control GetControl (string controlLocation) 
		{
#if DEEP
			Context.Trace.Write("ModuleBase", "Get Control : " + controlLocation);
#endif
			try 
			{
				// go get control
				return Global.Path.GetControlFromLocation(Global.Path.GetModulePath(this._attribute.FolderName, controlLocation));
			} 
			catch (Exception exc) 
			{
				GetControlUnsuccessfulEventArgs e = new GetControlUnsuccessfulEventArgs(exc);

				this.OnGetControlUnsuccessful(e);
			
				// throw exception if event say to
				if (e.ThrowException == true)
					throw;

				// return default control
				return e.ReturnControl;
			}
		}

		/// <summary>
		/// Assigns a <see cref="HttpContext.RewritePath"/> using portal specific logic to
		/// determin the correct URL to rewrite.
		/// </summary>
		/// <param name="page">The page to rewrite the path for.</param>
		private void RewritePath (ManagedFusion.Display.Modules.Config.Page page) 
		{
			// checks to see if there is a transform marker
			// sends the transformed path on to get rewritten
			// else just stops at this point and does nothing
			if (page.Transform != null) 
				RewritePath(page.TransformPath(this.InternalLocation));
			else return;
		}

		protected void RewritePath (string url) 
		{
			this.Context.RewritePath(CombineUrl(url).PathAndQuery);
		}

		protected void RewritePath (string path, params string[] queryStrings) 
		{
			this.Context.RewritePath(CombineUrl(path, queryStrings).ToString());
		}

		/// <summary>
		/// Assigns a <see cref="HttpContext.RewritePath"/> using portal specific logic to
		/// determin the correct URL to rewrite.
		/// </summary>
		/// <param name="url">The url path.</param>
		protected Uri CombineUrl (string url) 
		{
			// get parts of paths
			string[] path = url.Split(new char[] { '?' }, 2);

			// if there is no query string just pass the first part
			// else pass the first part and split the second part by '&'
			if (path.Length == 1)
				return CombineUrl(path[0], new string[0]);
			else
				return CombineUrl(path[0], path[1].Split('&'));
		}

		/// <summary>
		/// Assigns a <see cref="HttpContext.RewritePath"/> using portal specific logic to
		/// determin the correct URL to rewrite.
		/// </summary>
		/// <param name="path">The path url.</param>
		/// <param name="queryStrings">The query strings to add to the old url.</param>
		protected Uri CombineUrl (string path, params string[] queryStrings) 
		{
			string newUrl = path + "?";

			if (Context.Request.QueryString.Count > 0)
			{				
				// write current query strings
				foreach(string key in Context.Request.QueryString)
					newUrl += String.Format("{0}={1}&", key, Context.Request.QueryString[key]);
			}
			
			if (queryStrings != null && queryStrings.Length > 0)
			{
				// write new query strings
				newUrl += String.Join("&", queryStrings);
			}

			// remove all trailing '&'
			newUrl.TrimEnd('&');

			// remove all trailing '?'
			newUrl.TrimEnd('?');
#if DEBUG
			Context.Trace.Write("ModuleBase", String.Concat("URL Rewrite : ", newUrl));
#endif
			return Global.Path.GetPortalUrl(newUrl);
		}

		/// <summary></summary>
		/// <param name="tasks"></param>
		/// <returns></returns>
		protected bool IsInTasks (params string[] tasks) 
		{
			return Global.Security.IsInTasks(tasks, this.SectionInformation);
		}

		protected Control CreatePortlet (int id, string title, Control controlToAdd) 
		{
			// get Portlet Template
			Control template = ManagedFusion.Display.Containers.ContainerHolder.PortletTemplate;
			template.ID = String.Format("{0}_portlet_{1}",
				title.Replace(" ", "_"),
				id
				);

			// set title
			((Label)template.FindControl("title")).Text = title;

			// add portlet content
			((PlaceHolder)template.FindControl("content")).Controls.Add(controlToAdd);

			return template;
		}

		#endregion

		#region IModule Members

		/// <summary></summary>
		public bool AccessGranted 
		{
			get 
			{
				// checks to see if the module is using a config file or not
				if (this.Config.Pages != null) 
				{
					ManagedFusion.Display.Modules.Config.Page page = this.Config.FindPage(InternalLocation);
				
					return this.HasAccess(page);
				}

				return false;
			}
		}

		/// <summary></summary>
		/// <param name="page"></param>
		/// <returns></returns>
		private bool HasAccess (ManagedFusion.Display.Modules.Config.Page page) 
		{
			return Global.Security.IsInTasks(page.Tasks, this.SectionInformation);
		}

		/// <summary>Gets the left over URL after the section path is removed.</summary>
		/// <returns>Returns the local location of the mdoule in the path info.</returns>
		public string InternalLocation
		{
			get 
			{
				string path = Global.Path.UrlPath;
				
				string location = path.Remove(0, this.SectionInformation.Path.Length);
#if DEEP
				Context.Trace.Write("ModuleBase", "Getting Path : " + location);
#endif
				return location;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="localPath"></param>
		/// <returns></returns>
		public Uri GetUrlPath (string localPath) 
		{
			return Global.Path.GetAbsoluteUrl(this.GetPath(localPath));
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="localPath"></param>
		/// <returns></returns>
		public string GetDiskPath (string localPath) 
		{
			return Global.Path.GetAbsoluteDiskPath(this.GetPath(localPath));
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="localPath"></param>
		/// <returns></returns>
		private string GetPath (string localPath) 
		{
			return Global.Path.GetModulePath(this._attribute.FolderName, localPath);
		}

		private CultureManager _CultureManager;
		/// <summary>Provides a convient interface to the modules resource manager.</summary>
		public CultureManager CultureManager { get { return this._CultureManager; } }

		private NameValueCollection _Properties;
		/// <summary>Gets a list of all properties for module.</summary>
		public NameValueCollection Properties { get { return this._Properties; } }

		/// <summary>Gets the <c>content</c> of the current module to be placed in the executing page.</summary>
		public PlaceHolder GetContentHolder (Position p) 
		{
			Control c = this._holders[(int)p];
			c.ID = String.Concat("holder_", p.ToString());

			return (PlaceHolder)c;
		}

		private ModuleConfig _config;
		/// <summary>Config file for this module.</summary>
		public ModuleConfig Config 
		{ 
			get 
			{ 
				if (this._config == null)
					throw new ManagedFusionException(ExceptionType.Config,
						String.Format("There has been a problem with the module.config for {0}.", this._attribute.Title)
						);

				return this._config; 
			}
		}

		private ModuleFeed _Syndication;
		/// <summary></summary>
		public ModuleFeed Syndication 
		{
			get { return this._Syndication; }
		}

		/// <summary></summary>
		IHttpHandler IModule.Handler 
		{
			get 
			{
				// checks to see if the module is using a config file or not
				if (this.Config.Pages != null) 
				{
					ManagedFusion.Display.Modules.Config.Page page = this.Config.FindPage(InternalLocation);

					// load current handler according to the page address
					if (page.Type != null)
						return page.HandlerObject;
				} 
					
				// the default handler is going to get used
				return CommunityInfo.Current.Config.DefaultPageHandler;
			}
		}

		/// <summary></summary>
		void IModule.ProcessRequest ()
		{
			ManagedFusion.Display.Modules.Config.Page page = null;

			// checks to see if the center module has anything added to it
			if (this.Config.Pages != null) 
			{
				page = this.Config.FindPage(InternalLocation);

				// rewrite the path for the page if there is a transform marker
				if (page.Transform != null)
					RewritePath(page);

				// an alternative handler is being loaded so no futher processing has to be done
				if (page.Type != null) 
					return;
			}

			// executes the correct even depending on if we are creating a page or syndication
			if (SectionInformation.Syndicated
				&& Context.Request.Url.Query.ToLower().IndexOf("feed") > -1) 
			{
				LoadSyndicationEventArgs pcea = new LoadSyndicationEventArgs(this._Syndication);
				this.OnLoadSyndication(pcea);
			} 
			else
			{
				// checks to see if the center module has anything added to it
				if (page != null && page.Control != null)
				{
					AddControlsToCenter(page);
				}

				// setup content holders
				LoadModuleEventArgs phea = new LoadModuleEventArgs(this._holders);
				this.OnLoad(phea);

				// configure the containers
				this.ConfigureContainers();
#if DEBUG
				for(int i = 0; i < this._holders.Length; i++)
					Context.Trace.Write("ModuleBase", String.Format("Found {0} Containers for {1}", this._holders[i].Controls.Count, (Position)i));
#if DEEP
				Context.Trace.Write("ModuleBase", "Has Read Permissions : " + Global.Security.HasPermissions(Permissions.Read, this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Has Add Permissions : " + Global.Security.HasPermissions(Permissions.Add, this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Has Edit Permissions : " + Global.Security.HasPermissions(Permissions.Edit, this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Has Delete Permissions : " + Global.Security.HasPermissions(Permissions.Delete, this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Has Admin Permissions : " + Global.Security.HasPermissions(Permissions.Administrate, this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Is Owner : " + Global.Security.IsOwner(this.SectionInformation));
				Context.Trace.Write("ModuleBase", "Initialize Module : " + this.GetType().FullName);
				Context.Trace.Write("ModuleBase", "Left Holder Children Count = " + this._holders[(int)Position.Left].Controls.Count);
				Context.Trace.Write("ModuleBase", "Center Holder Children Count = " + this._holders[(int)Position.Center].Controls.Count);
				Context.Trace.Write("ModuleBase", "Right Holder Children Count = " + this._holders[(int)Position.Right].Controls.Count);
#endif
#endif
			}
		}

		void IModule.Install () 
		{
			Config.InstallModule();

			this.OnInstalled(new EventArgs());
		}

		void IModule.Uninstall () 
		{
			Config.UninstallModule();

			this.OnUnInstalled(new EventArgs());
		}

		#endregion

		#region Un/Install

		public static void Install (Type module) 
		{ 
			IModule m = (IModule)Activator.CreateInstance(module);
			m.Install();
		}

		public static void Uninstall (Type module) 
		{
			IModule m = (IModule)Activator.CreateInstance(module);
			m.Uninstall();
		}

		#endregion
	}
}