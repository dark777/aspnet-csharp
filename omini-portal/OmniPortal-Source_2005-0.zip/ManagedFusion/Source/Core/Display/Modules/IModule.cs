#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using ManagedFusion.Types;
using ManagedFusion.Syndication;
using ManagedFusion.Display.Modules.Config;
using ManagedFusion.Display.Modules.Syndication;

namespace ManagedFusion.Display.Modules
{
	/// <summary>
	/// Summary description for IPortalModule.
	/// </summary>
	public interface IModule
	{
		/// <summary></summary>
		bool AccessGranted { get; }

		/// <summary>Gets the left over URL after the section path is removed.</summary>
		/// <returns>Returns the local location of the mdoule in the path info.</returns>
		string InternalLocation { get; }

		/// <summary></summary>
		/// <param name="localPath"></param>
		/// <returns></returns>
		Uri GetUrlPath (string localPath);

		/// <summary></summary>
		/// <param name="localPath"></param>
		/// <returns></returns>
		string GetDiskPath (string localPath);

		/// <summary>Gets the <c>content</c> of the current module to be placed in the executing page.</summary>
		PlaceHolder GetContentHolder (Position p);

		/// <summary></summary>
		IHttpHandler Handler { get; }

		/// <summary></summary>
		ModuleConfig Config { get; }

		/// <summary></summary>
		ModuleFeed Syndication { get; }

		/// <summary>Provides a convient interface to the modules resource manager.</summary>
		CultureManager CultureManager { get; }

		/// <summary>Gets a list of all properties for module.</summary>
		NameValueCollection Properties { get; }

		/// <summary></summary>
		void ProcessRequest ();

		/// <summary>Install this module into portal.</summary>
		void Install ();

		/// <summary>Uninstall this module out of portal.</summary>
		void Uninstall ();
	}
}