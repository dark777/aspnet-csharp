#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion.Display.Modules
{
	/// <summary>
	/// Used for quick consuming of modules when needed to be displayed in list form.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple=false, Inherited=true)]
	public sealed class ModuleAttribute : SkinAttribute
	{
		private Guid _id;
		private bool _folderBased;
		private string _location;

		private string _cultureResourceName = null;
		private bool _traversablePath = false;
		private bool _installable = false;

		/// <summary>
		/// Creates a new module attribute for a module.
		/// </summary>
		/// <param name="title">Title of module.</param>
		/// <param name="description">Description of module.</param>
		/// <param name="id">The <see cref="System.Guid">Guid</see> of this module.</param>
		/// <param name="folderBased"></param>
		/// <param name="location"></param>
		public ModuleAttribute(string title, string description, string id, bool folderBased, string location) : base(title, description) 
		{
			this._id = new Guid(id);
			this._folderBased = folderBased;
			this._location = location;
		}

		/// <summary>The ID of the module to be used as a unique identifier.</summary>
		public Guid ModuleID { get { return this._id; } }

		public bool FolderBased { get { return this._folderBased; } }

		public string FolderName { get { return this._location; } }

		public string ConfigLocation 
		{ 
			get 
			{ 
				if (this.FolderBased)
					return Global.Path.GetModulePath(this.FolderName, "Module.config");
				else 
					return this._location;
			} 
		}

		public string CultureResourceName 
		{ 
			get { return this._cultureResourceName; } 
			set { this._cultureResourceName = value; }
		}

		/// <summary>Indicates if the URL path after the module is part of the module.</summary>
		/// <remarks>
		/// <note>If the module is traversable then that means the module cannot have an child-modules.</note>
		/// <para>If set to <see langword="true"/> then everything in the URL path after the module, also
		/// belongs to the module.  For example: <c>http://www.mysite.com/default.aspx/MyModule/1980/03/14/0800.aspx</c>  
		/// The <c>1980/03/14/0800.aspx</c> belong to the module.  However, if set to <see langword="false"/> each
		/// wack (<c>/</c>) after <c>MyModule</c> would be an additional module.</para>
		/// </remarks>
		public bool TraversablePath 
		{ 
			get { return this._traversablePath; }
			set { this._traversablePath = value; }
		}

		/// <summary>Tells if this module has an install script.</summary>
		public bool Installable 
		{ 
			get { return this._installable; } 
			set { this._installable = value; }
		}
	}
}