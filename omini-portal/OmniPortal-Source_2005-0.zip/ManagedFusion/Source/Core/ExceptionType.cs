#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion
{
	public enum ExceptionType
	{
		AccessDenied		= 0x00000000,	// 0	- 0
		Config				= 0x00000001,	// 1	- 1
		Provider			= 0x00000002,	// 2	- 2
		ControlNotFound		= 0x00000004,	// 4	- 4
		NotSupported		= 0x00000008,	// 8	- 8
		DataLayer			= 0x00000010,	// 10	- 16
		DisplayLayer		= 0x00000020,	// 20	- 32
		BusinessLayer		= 0x00000040,	// 40	- 64
		Path				= 0x00000080,	// 80	- 128
		Security			= 0x00000100,	// 100	- 256
		Syndication			= 0x00000200,	// 200	- 512
		UnknownError		= 0x7fffffff	// 7fffffff - 2,147,483,647 - Int32.MaxValue
	}
}