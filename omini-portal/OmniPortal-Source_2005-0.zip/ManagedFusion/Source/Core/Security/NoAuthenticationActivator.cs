using System;

using ManagedFusion.Providers;
using ManagedFusion.Security;

namespace ManagedFusion.Security
{
	internal class NoAuthenticationActivator : ProviderActivator
	{
		protected internal override object CreateInstance(Type type)
		{
			object[] args = new object[] {
											 new User(Guid.Empty, User.AnonymousName)
										 };

			return Activator.CreateInstance(type, args);
		}
	}
}
