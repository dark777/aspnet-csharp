using System;
using System.Security.Principal;

using ManagedFusion.Security.Profile;

namespace ManagedFusion.Security
{
	public interface IUser : IIdentity
	{
		Guid ID { get; }

		object this [string path] { get; }

		ProfileCollection Profile { get; }
	}
}
