using System;
using System.Collections;
using System.Collections.Specialized;

namespace ManagedFusion.Security.Profile
{
	public class ProfileCollection : DictionaryBase
	{
		private readonly StringCollection _fields;

		public ProfileCollection (StringCollection fields) 
		{
			this._fields = fields;
		}

		public void Add(string name, string value)
		{
			if (this._fields.Contains(name))
				this.InnerHashtable.Add(name, value);
			else
				throw new ManagedFusionException(ExceptionType.BusinessLayer,
					String.Format("The keyword, {0}, is not contained in this profile.", name)
					);
		}

		public void Set(string name, string value)
		{
			if (this._fields.Contains(name))
				this.InnerHashtable[name] = value;
			else
				throw new ManagedFusionException(ExceptionType.BusinessLayer,
					String.Format("The keyword, {0}, is not contained in this profile.", name)
					);
		}

		public string this [string name] 
		{
			get { return this.InnerHashtable[name] as string; }
			set { this.Set(name, value); }
		}
	}
}
