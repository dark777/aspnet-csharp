using System;
using System.Xml;
using System.Globalization;
using System.Security.Principal;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Security.Profile.BasicProfile
{
	public class BasicProfileConfig : IProfileProviderHandler
	{
		#region Fields

		private StringCollection _fields;
		private Hashtable _users;

		#endregion

		#region Constructor

		public BasicProfileConfig(XmlNode node)
		{
			this._fields = new StringCollection();

			// get <profileDef>
			XmlNode profileDef = node.SelectSingleNode("profileDef");

			if (profileDef != null) 
			{
				if (profileDef.ChildNodes.Count == 0)
					throw new ManagedFusionException(ExceptionType.Config,
						"Your profile definition does not contain any defined fields"
						);

				// get profile definition
				foreach(XmlNode def in profileDef.ChildNodes)
					this._fields.Add(def.Name);
			}

			// get <users>
			XmlNode users = node.SelectSingleNode("users");

			if (users != null) 
			{
				this._users = new Hashtable(users.ChildNodes.Count);

				// get <user>
				foreach(XmlNode user in users.SelectNodes("user")) 
				{
					// get profile
					ProfileCollection profile = new ProfileCollection(this._fields);
					foreach(XmlNode field in user.ChildNodes)
					{
						try 
						{
							profile.Add(field.Name, field.InnerText);
						} 
						catch (ManagedFusionException) { }
					}

					// get @uid
					XmlAttribute uid = user.Attributes["uid"];
					
					// add user with uid as key and profile as value
					this._users.Add(
						new Guid(uid.Value),
						profile
						);
				}
			}
		}

		#endregion

		#region IProfileProviderHandler Members

		public ProfileCollection GetProfile (IUser identity)
		{
			return this.GetProfile(identity.ID);
		}

		public ProfileCollection GetProfile (Guid uid) 
		{
			ProfileCollection collection = this._users[uid] as ProfileCollection;

			if (collection == null)
				collection = new ProfileCollection(this._fields);

			return collection;
		}

		void IProfileProviderHandler.CommitProfile (IUser identity, ProfileCollection profile) 
		{
			throw new NotImplementedException("Commiting a profile is not implimented for BasicProfileConfig, please edit the Community.config file.");
		}

		#endregion
	}
}
