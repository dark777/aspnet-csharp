using System;
using System.Xml;

using ManagedFusion.Providers;

namespace ManagedFusion.Security.Profile.BasicProfile
{
	[Provider("BasicProfile")]
	public class BasicProfileProviderHandler : IConfigurationProviderHandler
	{
		#region IConfigurationProviderHandler Members

		public object Create(XmlNode provider)
		{
			return new BasicProfileConfig(provider);
		}

		#endregion
	}
}
