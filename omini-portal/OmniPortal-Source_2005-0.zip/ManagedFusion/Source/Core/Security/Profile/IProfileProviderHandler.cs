using System;
using System.Collections;
using System.Security.Principal;

//ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Security.Profile
{
	public interface IProfileProviderHandler
	{
		/// <summary>
		/// When implemented by a class, gets the profile information.
		/// </summary>
		/// <param name="identity"><see cref="IUser"/> to be used for accessing the information in the Profile store.</param>
		/// <returns>The profile value being requested.</returns>
		ProfileCollection GetProfile (IUser identity);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="uid"></param>
		/// <returns></returns>
		ProfileCollection GetProfile (Guid uid);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="identity"></param>
		/// <param name="profile"></param>
		void CommitProfile (IUser identity, ProfileCollection profile);
	}
}
