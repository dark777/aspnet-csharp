#region Copyright � 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright � 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Web;
using System.Text;
using System.Security.Principal;

// ManagedFusion Classes
using ManagedFusion.Types;
using ManagedFusion.Security.Profile;

namespace ManagedFusion.Security
{
	/// <summary>
	/// The very basic user object for the user <see cref="IIdentity"/>.
	/// </summary>
	public class User : IUser
	{
		#region Constants

		/// <summary>Name used for un-authenticated people entering site.</summary>
		public const string AnonymousName = "Anonymous";

		#endregion

		#region Private Fields

		// the id of the current authorized user
		private readonly Guid _id;

		// the name of the current authroized user
		private readonly string _name;

		// the profile of the current authroized user
		private ProfileCollection _profile;

		#endregion

		#region Constructors

		/// <summary>
		/// Creates an instance of the <see cref="User"/>.
		/// </summary>
		/// <param name="name">The name of the Identity.</param>
		public User (Guid id, string name) 
		{
			if (id == Guid.Empty && name != AnonymousName) throw new ArgumentException("id, cannot be empty", "id");
			if (name == null) throw new ArgumentNullException("name");
			if (name.Length == 0) throw new ArgumentException("name, cannot be a empty string", "name");

			this._id = id;
			this._name = name;
		}

		#endregion

		#region IIdentity Members

		public virtual string Name
		{
			get { return this._name; }
		}

		public string AuthenticationType
		{
			get { return "ManagedFusion User Authentication"; }
		}

		/// <summary>
		/// If the Identity is authentication and user is not anonymous.
		/// </summary>
		public virtual bool IsAuthenticated
		{
			get	{ return (this.Name != AnonymousName); }
		}

		#endregion

		#region IUser Members

		public Guid ID
		{
			get { return this._id; }
		}

		public object this[string path]
		{
			get { return this.Profile[path]; }
		}

		public ProfileCollection Profile
		{
			get
			{
				// if profile doesn't exisit get it
				if (this._profile == null) 
				{
					IProfileProviderHandler profileHandler = CommunityInfo.Current.Config.GetProvider("Profile") as IProfileProviderHandler;
					this._profile = profileHandler.GetProfile(this);
				}

				return this._profile;
			}
		}

		#endregion
	}
}
