#region Copyright � 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright � 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections.Specialized;
using System.Security.Principal;

// ManagedFusion Classes
using ManagedFusion.Providers;
using ManagedFusion.Types;
using ManagedFusion.Security.Authorization;
using ManagedFusion.Security.Authentication;

namespace ManagedFusion.Security
{
	/// <summary>The base class for any user authentication in ManagedFusion.</summary>
	[RootProvider(typeof(SecurityActivator))]
	public abstract class SecurityProvider : IPrincipal
	{
		#region Private Fields

		// the user of the current security
		private IUser _identity;
		private IAuthorizationProviderHandler _authorization;

		#endregion

		#region Constructor

		public SecurityProvider (IUser user)
			: this (user, CommunityInfo.Current.Config.GetProvider("Authorization") as IAuthorizationProviderHandler) { }

		public SecurityProvider (IUser user, IAuthorizationProviderHandler authorization) 
		{
			if (user == null) throw new ArgumentNullException("user");
			if (authorization == null) throw new ArgumentNullException("authorization");

			this._identity = user;
			this._authorization = authorization;
		}

		#endregion

		#region Properties

		protected IAuthorizationProviderHandler Authorization 
		{
			get { return this._authorization; }
		}

		public IUser Identity 
		{
			get { return this._identity; }
		}

		public StringCollection UserRoles 
		{
			get { return this._authorization.GetRoles(this.Identity); }
		}

		/// <summary>List of roles that are availiable to all users.</summary>
		public StringCollection SystemRoles 
		{ 
			get { return this._authorization.Roles; }
		}

		#endregion

		#region Methods

		/// <summary>Checks to see if the principal is the owner of the section.</summary>
		/// <param name="section">The section you want to check to see if the principal is an owner of.</param>
		public bool IsOwner (SectionInfo section)
		{
			string[] roles = new string[section.Owners.Count];
			section.Owners.CopyTo(roles, 0);
			return Global.Security.IsInRoles(roles);
		}

		/// <summary>Checks to see if the principal has <see cref="Permissions"/> passed in.</summary>
		/// <param name="p">Permissions to verify.</param>
		/// <returns>Returns if the Permissions was verified or not.</returns>
		public bool HasPermissions (Permissions p, SectionInfo section)
		{
			if (this.IsOwner(section)) return true;

			// get the tasks that have this permission
			string[] tasks = section.GetTasks(p);

			// get roles that have these tasks
			string[] roles = section.GetRoles(tasks);

			// check to see if identity has roles
			return this.IsInRoles(roles);
		}

		/// <summary>Checks to see if the principal has <see cref="Permissions"/> passed in.</summary>
		/// <param name="p">Permissions to verify.</param>
		/// <returns>Returns if the Permissions was verified or not.</returns>
		public bool HasPermissions (Permissions p, PortletInfo portlet)
		{
			// get roles that have these tasks
			string[] roles = portlet.GetRoles(p);

			// check to see if identity has roles
			return this.IsInRoles(roles);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="taskName"></param>
		/// <returns></returns>
		public bool IsInTask (string task, SectionInfo section)
		{
			return this.IsInTasks(new string[] { task }, section);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="taskName"></param>
		/// <returns></returns>
		public bool IsInTasks (string[] tasks, SectionInfo section)
		{
			// get roles that have these tasks
			string[] roles = section.GetRoles(tasks);
			
			// check to see if identity has roles
			return this.IsInRoles(roles);
		}

		/// <summary>Checks to see if user is in multiple roles.</summary>
		/// <param name="roles">The roles to check.</param>
		/// <returns>Returns a boolean value of if the user has use of this role.</returns>
		public bool IsInRoles(string[] roles)
		{
			foreach (string role in roles) 
			{
				// checks to see if it is a valid role
				if (role.Length == 0)
					continue;

				if (this.IsInRole(role))
					// user is in one of the roles
					return true;
			}

			// user is not in any of these roles
			return false;
		}

		/// <summary>
		/// Checks to see if the principal is in a specific role.
		/// </summary>
		/// <param name="role">The role to check.</param>
		/// <returns>Returns a value indicating if the user is in the role or not.</returns>
		public bool IsInRole(string role)
		{
			try 
			{
				// parse the role looking for a valie PortalRoles
				PortalRoles pRole = (PortalRoles)Enum.Parse(typeof(PortalRoles), role, true);

				// check to see if the user has permissions for this role
				if (	(pRole == PortalRoles.Authenticated && this.Identity.IsAuthenticated == true)
					||	(pRole == PortalRoles.UnAuthenticated && this.Identity.IsAuthenticated == false)
					||	(pRole == PortalRoles.Everybody))
					return true;
			} 
			catch (ArgumentException) { /* Do Nothing */ }

			return this._authorization.CheckAccess(this.Identity, role);
		}

		#endregion

		#region IPrincipal Members

		IIdentity IPrincipal.Identity
		{
			get {  return this.Identity; }
		}

		#endregion
	}
}
