using System;
using System.Xml;
using System.Globalization;
using System.Web.Configuration;
using System.Web.Security;
using System.Collections;
using System.Collections.Specialized;

namespace ManagedFusion.Security.Authentication.BasicAuthentication
{
	public class BasicAuthenticationConfig : IAuthenticationProviderHandler
	{
		#region Fields

		private StringDictionary _userPasswords;
		private Hashtable _userIds;
		private FormsAuthPasswordFormat _passwordFormat;

		#endregion

		#region Constructor

		public BasicAuthenticationConfig(XmlNode node)
		{
			// get password format
			XmlAttribute passwordFormat = node.Attributes["passwordFormat"];
			if (passwordFormat == null 
				&& passwordFormat.Specified == false)
				throw new ManagedFusionException(ExceptionType.Config,
					"passwordFormat is a required attribute of credentials in BasicAuthentication"
					);

			try 
			{
				// get the password format
				this._passwordFormat = (FormsAuthPasswordFormat)Enum.Parse(typeof(FormsAuthPasswordFormat), passwordFormat.Value, true);
			} 
			catch (ArgumentException exc) 
			{
				throw new ManagedFusionException(ExceptionType.Config,
					"passwordFormat must contain a value of Clear, MD5, or SHA1 to be valid",
					exc
					);
			}

            // create user password hash table
			this._userPasswords = new StringDictionary();
			this._userIds = new Hashtable();
			XmlAttribute name, uid, password;

			// add each valid user to the hash table
			foreach(XmlNode user in node.SelectNodes("user"))
			{
				name = user.Attributes["name"];
				uid = user.Attributes["uid"];
				password = user.Attributes["password"];

				if (name != null && password != null)
					this._userPasswords.Add(name.Value, password.Value);

				if (uid != null && password != null)
					this._userIds.Add(
						name.Value,
						new Guid(uid.Value)
						);
			}
		}

		#endregion

		#region Methods

		public bool Authenticate (string name, string password) 
		{
			string storedPassword = this._userPasswords[name.ToLower(CultureInfo.InvariantCulture)];

			// if the name was not in the list then return not authenticated
			if (storedPassword == null)
			{
				return false;
			}

			// format the password correctly
			switch(this._passwordFormat) 
			{
				case FormsAuthPasswordFormat.Clear :
					break;

				case FormsAuthPasswordFormat.MD5 :
					password = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "md5");
					break;

				case FormsAuthPasswordFormat.SHA1 :
					password = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "sha1");
					break;
			}

			// check the passwords to see if they are the same
			return (String.Compare(password, storedPassword, (this._passwordFormat != FormsAuthPasswordFormat.Clear), CultureInfo.InvariantCulture) == 0);
		}

		#endregion

		#region IAuthenticationProviderHandler Members

		public IUser GetAuthorizedUser(IDictionary parameters)
		{
			string name = parameters["name"] as string;
			string password = parameters["password"] as string;

			// if authenticated return user
			if (Authenticate(name, password))
				return new User(GetUsersID(name), name);
			
			// nothing was found retun anonymous user
			return new User(Guid.Empty, User.AnonymousName);
		}

		public Guid GetUsersID (string name) 
		{
			return (Guid)this._userIds[name];
		}

		#endregion
	}
}
