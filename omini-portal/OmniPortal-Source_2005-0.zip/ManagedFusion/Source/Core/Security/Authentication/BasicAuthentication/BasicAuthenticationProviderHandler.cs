using System;
using System.Xml;

using ManagedFusion.Providers;

namespace ManagedFusion.Security.Authentication.BasicAuthentication
{
	[Provider("BasicAuthentication")]
	public class BasicAuthenticationProviderHandler : IConfigurationProviderHandler
	{
		#region IConfigurationProviderHandler Members

		public object Create(XmlNode provider)
		{
			return new BasicAuthenticationConfig(provider);
		}

		#endregion
	}
}
