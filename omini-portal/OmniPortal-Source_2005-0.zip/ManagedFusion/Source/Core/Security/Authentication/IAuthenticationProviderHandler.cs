using System;
using System.Collections;
using System.Security.Principal;

//ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Security.Authentication
{
	public interface IAuthenticationProviderHandler
	{
		/// <summary>
		/// Creates an <see cref="IUser"/>.
		/// </summary>
		/// <param name="parameters">The paramters for the provider.</param>
		/// <returns>An authorized <see cref="IUser"/></returns>
		IUser GetAuthorizedUser (IDictionary parameters);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		Guid GetUsersID (string name);
	}
}