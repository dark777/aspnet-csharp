using System;
using System.Web;

// ManagedFusion Classes
using ManagedFusion.Types;
using ManagedFusion.Providers;
using ManagedFusion.Security.Authentication;

namespace ManagedFusion.Security
{
	internal class SecurityActivator : ProviderActivator
	{
		protected internal override object CreateInstance(Type type)
		{
			// get the current http context
			HttpContext context = HttpContext.Current;
			User user;

			IAuthenticationProviderHandler auth = CommunityInfo.Current.Config.GetProvider("Authentication") as IAuthenticationProviderHandler;

			// check to make sure user and identity exisit
			if (context.User == null || context.User.Identity == null)
				user = new User(Guid.Empty, User.AnonymousName);
			else
				user = new User(
					auth.GetUsersID(context.User.Identity.Name),
					context.User.Identity.Name
					);

			// create arguments to pass into the provider type
			object[] args = new object[] {
											user 
										 };

			// create provider with the arguments from above
			return Activator.CreateInstance(type, args);
		}
	}
}
