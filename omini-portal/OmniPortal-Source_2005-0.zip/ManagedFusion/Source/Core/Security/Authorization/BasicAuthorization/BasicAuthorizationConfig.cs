using System;
using System.Xml;
using System.Globalization;
using System.Security.Principal;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion.Providers;

namespace ManagedFusion.Security.Authorization.BasicAuthorization
{
	public class BasicAuthorizationConfig : IAuthorizationProviderHandler
	{
		private StringCollection _roles;
		private Hashtable _userRoles;
		private string _unAuthorizedRole;

		public BasicAuthorizationConfig(XmlNode node)
		{
			this._roles = new StringCollection();
			this._userRoles = new Hashtable();

			// get unAuthorizedRole attribute value from <users>
			this._unAuthorizedRole = Global.GetValue(node.SelectSingleNode("users"), "unAuthorizedRole", true).ToLower(CultureInfo.InvariantCulture);

			// get all <user> from <users>
			foreach(XmlNode user in node.SelectNodes("users/user")) 
			{
				_userRoles.Add(
					new Guid(Global.GetValue(user, "uid", true)),
					Global.GetValue(user, "role", true).ToLower(CultureInfo.InvariantCulture)
					);
			}

			// get all <role> from <roles>
			foreach(XmlNode role in node.SelectNodes("roles/role"))
			{
				_roles.Add(
					Global.GetValue(role, "name", true).ToLower(CultureInfo.InvariantCulture)
					);
			}
		}

		#region IAuthorizationProviderHandler Members

		public StringCollection Roles { get { return this._roles; } }

		public StringCollection GetRoles(IUser identity)
		{
			StringCollection roles = new StringCollection();

			// check to see if there is a user by this name in the 
			// authorization collection
			if (_userRoles.ContainsKey(identity.ID)) 
			{
				roles.Add((_userRoles[identity.ID] as string).ToLower());
				return roles;
			} 
			else 
			{
				roles.Add(this._unAuthorizedRole);
				return roles;
			}
		}

		public bool IsSuperUser (IUser identity) 
		{
			return CheckAccess(identity, "Administrator");
		}

		public bool CheckAccess(IUser identity, string role)
		{
			// get role to check access for
			StringCollection userRoles = GetRoles(identity);

			// see if the role is in the user's roles
			return userRoles.Contains(role.ToLower());
		}

		#endregion
	}
}
