using System;
using System.Xml;

using ManagedFusion.Providers;

namespace ManagedFusion.Security.Authorization.BasicAuthorization
{
	[Provider("BasicAuthorization")]
	public class BasicAuthorizationProviderHandler : IConfigurationProviderHandler
	{
		#region IConfigurationProviderHandler Members

		public object Create(XmlNode provider)
		{
			return new BasicAuthorizationConfig(provider);
		}

		#endregion
	}
}
