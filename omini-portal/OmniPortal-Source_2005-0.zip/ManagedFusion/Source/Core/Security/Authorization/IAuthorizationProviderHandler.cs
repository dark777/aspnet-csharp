using System;
using System.Collections;
using System.Collections.Specialized;
using System.Security.Principal;

// ManagedFusion Classes
using ManagedFusion.Types;
using ManagedFusion.Providers;

namespace ManagedFusion.Security.Authorization
{
	public interface IAuthorizationProviderHandler
	{
		#region Properties

		/// <summary>
		/// Get all the roles available for all users.
		/// </summary>
		StringCollection Roles { get; }

		#endregion

		#region Methods

		/// <summary>
		/// Gets the roles for an identity in a system.
		/// </summary>
		/// <param name="identity">The <see cref="IUser"/> to get the roles.</param>
		///	<returns>The collection of roles.</returns>
		///	<exception cref="ArgumentException">
		///		<para>The identity information could not be found.</para>
		///		<para>-or-</para>
		///		<para>The Initialize method must be called before any other method.</para>
		///	</exception>
		///	<exception cref="ArgumentNullException"><paramname name="identity"/> is a <see langword="null"/> reference.</exception>
		///	<exception cref="ConfigurationException">The storage location for the policy file was not supplied.</exception>
		///	<exception cref="SecurityException">
		///		<para>The specified network provider name is invalid.</para>
		///		<para>-or-</para>
		///		<para>The scope specified was not found.</para>
		///		<para>-or-</para>
		///		<para>Element not found (the application does not exist).</para>        
		///	</exception>  
		///	<remarks>
		///		<para>The provider returns roles to the client in the format scope\roles. This allows you to specify roles of the same name in different scopes within one application.</para>
		///	</remarks>
		StringCollection GetRoles (IUser identity);

		/// <summary>
		/// Determins if the <see cref="IUser"/> is a <see cref="PortalRoles.SuperUser"/>.
		/// </summary>
		/// <param name="identity">The <see cref="IUser"/> to check to see if they are in the <see cref="PortalRoles.SuperUser"/> role.</param>
		/// <remarks>This method is important because there should always be a <see cref="IIdenity"/> that is a <see cref="PortalRoles.SuperUser"/> for any system.</remarks>
		/// <returns><see langword="true"/> if the user is a <see cref="PortalRoles.SuperUser"/> else it returns <see langword="false"/>.</returns>
		bool IsSuperUser (IUser identity);

		/// <summary>
		/// Checks that an identity has access to a particular operation.
		/// </summary>
		/// <param name="identity">The <see cref="IUser"/> to get the roles.</param>
		/// <param name="role">The role to check access for.</param>
		/// <returns><see langword="true"/> if the user with the specified identity has access to all tasks; otherwise <see langword="false"/>.</returns>
		///	<exception cref="ArgumentException">The identity information could not be found.</exception>
		///	<exception cref="ArgumentNullException"><paramname name="identity"/> is a <see langword="null"/> reference.</exception>        
		///	<exception cref="SecurityException">
		///		<para>The specified network provider name is invalid.</para>
		///		<para>-or-</para>
		///		<para>The scope specified was not found.</para>
		///		<para>-or-</para>
		///		<para>Element not found (the application does not exist).</para>        
		///	</exception>   
		///	<exception cref="NotSupportedException">The action requested is not supported.</exception>
		bool CheckAccess (IUser identity, string role);
		
		#endregion
	}
}
