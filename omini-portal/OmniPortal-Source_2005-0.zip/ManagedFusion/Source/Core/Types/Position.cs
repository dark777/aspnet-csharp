#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion.Types
{
	/// <summary>
	/// The position of the module on the page.
	/// </summary>
	public enum Position
	{
		/// <summary>Center position of the page.</summary>
		Center	= 0,

		/// <summary>Left position of the page.</summary>
		Left	= 1,

		/// <summary>Right position of the page.</summary>
		Right	= 2
	}
}