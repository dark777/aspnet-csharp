using System;

namespace ManagedFusion.Types
{
	public class StyleInfo 
	{
		private string _name;
		private string _path;

		internal StyleInfo (string name, string path) 
		{
			this._name = name;
			this._path = path;
		}

		public string Name 
		{ 
			get { return this._name; }
		}

		public string Path
		{
			get { return this._path; }
		}

		public override string ToString()
		{
			return this.Path;
		}
	}
}
