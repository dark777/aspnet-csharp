#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion.Display;
using ManagedFusion.Data;
using ManagedFusion.Security;
using ManagedFusion.Display.Modules;

namespace ManagedFusion.Types
{
	/// <summary>
	/// Summary description for Portlet.
	/// </summary>
	public class PortletInfo : PortalType
	{
		#region Static

		public static PortletCollection Collection 
		{
			get { return Global.DatabaseProvider.Portlets; }
		}

		public static PortletInfo CreateNew () 
		{
			PortletInfo portlet = new PortletInfo(
				-1
				);

			portlet.SetState(State.Added);

			return portlet;
		}

		public static void AddPortlet (PortletInfo portlet) 
		{
			Collection.Add(portlet);
		}

		public static void RemovePortlet (PortletInfo portlet) 
		{
			Collection.Remove(portlet);
		}

		#endregion

		#region Fields

		private readonly int _id;
		private string _title;
		private Guid _moduleID;
		private DateTime _touched;

		#endregion

		#region Constructors

		public PortletInfo (int id, string title, Guid moduleID, DateTime touched) 
		{
			this._id = id;
			this._title = title;
			this._moduleID = moduleID;
			this._touched = touched;

			// setup events
			this.SetupEvents();
		}

		public PortletInfo (int id, string title, PortletModule module, DateTime touched) 
			: this(id, title, module.ID, touched) { }

		private PortletInfo (int id) 
		{
			this._id = id;
			this._touched = DateTime.Now;
		}

		private void SetupEvents () 
		{
		}

		#endregion

		#region Properties In Database

		public override int ID { get { return this._id; } }

		public string Title 
		{
			get { return this._title; }
			set 
			{ 
				this._title = value;
				this.ValueChanged();
			}
		}

		private Guid ModuleID 
		{
			get { return this._moduleID; } 
		}

		public override DateTime Touched 
		{ 
			get { return this._touched; } 
			set { this._touched = value; }
		}

		#endregion

		#region Properties Not In Database

		public PortletModule Module 
		{
			get { return (PortletModule)PortletModule.Collection[this._moduleID]; }
			set 
			{ 
				this._moduleID = value.ID;
				this.ValueChanged();
			}
		}

		private NameValueCollection _ModuleData;
		/// <summary>Get properties for portlets.</summary>
		/// <returns>Returns a collection of the properties.</returns>
		public NameValueCollection ModuleData 
		{ 
			get 
			{ 
				if (_ModuleData != null) return _ModuleData;

				this._ModuleData = Global.DatabaseProvider.GetModuleDataForPortlet(this);
				return this._ModuleData;
			}
		}

		private NameValueCollection _Properties;
		/// <summary>Get properties for portlets.</summary>
		/// <returns>Returns a collection of the properties.</returns>
		protected NameValueCollection Properties 
		{ 
			get 
			{ 
				if (_Properties != null) return _Properties;

				this._Properties = Global.DatabaseProvider.GetGeneralPropertiesForPortlet(this);
				return this._Properties;
			}
		}

		#endregion

		# region Authorization

		public void AddRole (string role, Permissions permissions) 
		{
			this.AddRole(role, permissions.ToString().Replace(", ", Global.Delimiter.ToString()).Split(Global.Delimiter));
		}

		public void AddRole (string role, string[] permissions) 
		{
			Global.DatabaseProvider.AddRoleForPortlet(role, permissions, this);

			// reset roles to refresh next time
			this._roles = null;
		}

		public void RemoveRole (string role) 
		{
			Global.DatabaseProvider.RemoveRoleForPortlet(role, this);

			// reset roles to refresh next time
			this._roles = null;
		}

		private RolesPermissionsDictionary _roles;
		public RolesPermissionsDictionary Roles 
		{
			get 
			{
				if (this._roles != null) return this._roles;
		
				// get roles list for this section
				this._roles = Global.DatabaseProvider.GetRolesForPortlet(this);
				return this._roles;
			}
		}

		public bool UserHasPermissions (Permissions p) 
		{
			return Global.Security.HasPermissions(p, this);
		}

		/// <summary>Get the roles for selected permissions.</summary>
		/// <param name="permissions">The permissions to get the roles for.</param>
		/// <returns>Returns a list of roles for the <paramref name="permissions">permissions</paramref>.</returns>
		public string[] GetRoles (Permissions permissions) 
		{
			string key = String.Format("Portlet-Roles-{0}--{1}", this.ID, permissions.ToString());

			// checks to see if the roles have been cached for these permissions
			// this is nessisary because RolesDictionary.GetRoles is a potentially
			// intensive operation
			if (Global.Cache.IsCached(key) == false) 
			{
				ArrayList rlist = this.Roles.GetRoles(permissions.ToString().Replace(", ", Global.Delimiter.ToString()).Split(Global.Delimiter));

				// add to cache
				Global.Cache.Add(key, rlist.ToArray(typeof(string)));
			}

			string[] list = Global.Cache[key] as string[];
 
			// if it has no tasks is null then no tasks are returned
			return (list != null) ? list : new string[0];
		}

		#endregion

		protected override void CommitChangesToDatabase()
		{
			Global.DatabaseProvider.CommitPortletChanges(this);

			switch(this.State) 
			{
				case State.Added :
				case State.Deleted :
					Global.DatabaseProvider.ResetPortletCollection();
					break;

				case State.Changed :
					Global.DatabaseProvider.OnPortletsChanged();
					break;
			}
		}
	}
}