#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Web;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types 
{ 
	/// <summary>
	/// The SiteInfo class represents all the data associated with a single site.
	/// </summary>
	public sealed class SiteInfo : PortalType
	{
		#region Fields

		private readonly int _id;
		private string _domain;			// can be * or domain
		private string _subDomain;		// can be * or sub-domain
		private DateTime _touched;		// date and time of creation in database
		private int _portal_id;

		#endregion

		#region Constructors

		public SiteInfo(int id, string domain, string subDomain, DateTime touched, int connectedPortal) 
		{
			if (id < 1) throw new ArgumentOutOfRangeException("id", id, "ID must be greater than zero.");

			this._id = id;
			this._domain = (domain == null) ? "*" : domain;
			this._subDomain = (subDomain == null) ? "*" : subDomain;
			this._touched = (touched != DateTime.MinValue && touched != DateTime.MaxValue) ? touched : DateTime.Now;

			this._portal_id = connectedPortal;

			// setup events
			this.SetupEvents();
		}

		private SiteInfo (int id, string domain, string subDomain) 
		{
			this._id = id;
			this._domain = domain;
			this._subDomain = subDomain;
			this._touched = DateTime.Now;

			// setup events
			this.SetupEvents();
		}

		private void SetupEvents () 
		{
			Global.DatabaseProvider.SectionsChanged += new EventHandler(InvalidateExternalSectionsCollections);
			Global.DatabaseProvider.CommunitiesChanged += new EventHandler(InvalidateExternalCommunitiesCollections);
		}

		#endregion

		#region Static Properties and Methods

		public static SiteCollection Collection 
		{
			get { return Global.DatabaseProvider.Sites; }
		}

		public static SiteInfo CreateNew () 
		{
			SiteInfo site = new SiteInfo(
				-1,
				"*",
				"*"
				);

			site.SetState(State.Added);

			return site;
		}

		public static void AddSite (SiteInfo site) 
		{
			Collection.Add(site);
		}

		public static void RemoveSite (SiteInfo site) 
		{
			Collection.Remove(site);
		}

		#endregion

		#region Properties In Database

		/// <summary>Gets Site ID</summary>
		public override int ID 
		{ 
			get { return this._id; } 
		}
		
		/// <summary>Get and sets Site Domain</summary>
		public string Domain 
		{ 
			get { return this._domain; } 
			set 
			{ 
				this._domain = value;
				this.ValueChanged();
			}
		}
		
		/// <summary>Get and set Site SubDomain</summary>
		public string SubDomain 
		{ 
			get { return this._subDomain; } 
			set 
			{ 
				this._subDomain = value; 
				this.ValueChanged();
			}
		}
		
		/// <summary>Get last touched date.</summary>
		public override DateTime Touched 
		{ 
			get { return this._touched; } 
			set { this._touched = value; }
		}

		#endregion

		#region Properties Not In Database

		public void SetSectionLink (SectionInfo section) 
		{
			// set the site section link
			Global.DatabaseProvider.SetSiteSectionLink(section, this);

			// reset the connected section so it is refreshed
			// next time it is called
			this._ConnectedSection = null;
		}

		public void RemoveSectionLink () 
		{
			// remove the site section link
			Global.DatabaseProvider.RemoveSiteSectionLink(this);

			// reset the connected sites so it is refreshed
			// next time it is called
			this._ConnectedSection = null;
		}

		private SectionInfo _ConnectedSection;
		public SectionInfo ConnectedSection 
		{
			get 
			{
				if (this._ConnectedSection == null)
					this._ConnectedSection = SectionInfo.Collection[Global.DatabaseProvider.GetSectionForSite(this)];

				return this._ConnectedSection;
			}
		}

		private CommunityInfo _ConnectedCommunity;
		/// <summary>Get and set Connected Portal</summary>
		public CommunityInfo ConnectedCommunity
		{
			get 
			{ 
				if (this._ConnectedCommunity == null)
					this._ConnectedCommunity = CommunityInfo.Collection[this._portal_id];

				return this._ConnectedCommunity;
			}
			set 
			{ 
				if (value.ID == -1) throw new ArgumentException("Must be commited to database before it can be connected.");

				this._ConnectedCommunity = value;
				this._portal_id = value.ID;
				this.ValueChanged();
			}
		}

		public string FullDomain 
		{
			get { return String.Concat(this.SubDomain, ".", this.Domain); } 
		}

		#endregion

		#region Get Site For Current URL

		/// <summary>
		/// Gets the <see cref="ManagedFusion.Site.SiteInfo">SiteInfo</see> according to the
		/// host of the current URL request.
		/// </summary>
		/// <returns>Returns the site information from the database.</returns>
		/// <exception cref="ManagedFusion.SiteNotFoundException">Thrown when the current host is not found in sites.</exception>
		public static SiteInfo Current
		{
			get 
			{
				// check to see if the context has already been created with the current site
				if (Global.Context.Items["SiteInfo"] != null)
					return (SiteInfo)Global.Context.Items["SiteInfo"];

				// get host for current portal
				string host = Global.Context.Request.Url.Host.ToLower();
				
				// sets the portal key used for cache
				string siteKey = host;

				// see if portal is in cache
				if (Global.Cache.IsCached(siteKey, String.Empty) == true)
					return (SiteInfo)Global.Cache[siteKey, String.Empty];

				// get host parts
				string[] parts = host.Split('.');

				// get portal information
				string domain = String.Empty;
				string subDomain = "*";

				// get domain and subdomain
				switch(parts.Length) 
				{
					case 3:		// in the form of subDomain.domain.com
						domain = String.Format("{0}.{1}", parts[1], parts[2]);
						subDomain = parts[0];
						break;
					case 4:
						domain = String.Concat(parts[1], ".", parts[2], ".", parts[3]);
						subDomain = parts[0];
						break;
					default:
						domain = host;
						break;
				}

				// get all site combinations
				SiteInfo[] sites = new SiteInfo[4];

				sites[0] = SiteInfo.Collection[String.Concat(subDomain, ".", domain)];
				sites[1] = SiteInfo.Collection[String.Concat("*.", domain)];
				sites[2] = SiteInfo.Collection[String.Concat(subDomain, ".*")];
				sites[3] = SiteInfo.Collection["*.*"];

				// create site info object
				SiteInfo cacheValue = null;

				foreach(SiteInfo site in sites)
					if (site != null) 
					{
						cacheValue = site;
						break;
					}

				// adds the portal to the cache
				Global.Cache.Add(siteKey, String.Empty, cacheValue);

				return cacheValue;
			}
		}

		#endregion

		/// <summary>Writes the object to a string.</summary>
		/// <returns>Returns the name of the page.</returns>
		public override string ToString() 
		{
			return this.FullDomain; 
		}

		private void InvalidateExternalSectionsCollections(object sender, EventArgs e)
		{
			this._ConnectedSection = null;
		}

		private void InvalidateExternalCommunitiesCollections(object sender, EventArgs e)
		{
			this._ConnectedCommunity = null;
		}

		protected override void CommitChangesToDatabase()
		{
			Global.DatabaseProvider.CommitSiteChanges(this);

			switch(this.State) 
			{
				case State.Added :
				case State.Deleted :
					Global.DatabaseProvider.ResetSiteCollection();
					break;

				case State.Changed :
					Global.DatabaseProvider.OnSitesChanged();
					break;
			}
		}
	}
}