#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class ContainerCollection : IPortalTypeCollection
	{
		private SectionInfo _section;
		private ContainerInfo[] _collection;

		public ContainerCollection (ContainerInfo[] containers) : this (containers, null)
		{ }

		public ContainerCollection (ContainerInfo[] containers, SectionInfo section) 
		{
			this._collection = containers;
			this._section = section;
		}

		public ContainerInfo this [int id] 
		{
			get 
			{  
				foreach(ContainerInfo container in this._collection) 
				{
					if (container.ID == id)
						// component found and returned
						return container;
				}

				// component not found and nothing returned
				return null;
			}
		}

		public void CopyTo (ContainerInfo[] array, int index) 
		{
			this._collection.CopyTo(array, index);
		}

		public PortalTypeEnumerator GetEnumerator () 
		{
			return this.CommittedItems;
		}

		public bool Contains (ContainerInfo container) 
		{
			return (this[container.ID] != null);
		}

		#region IPortalTypeCollection Members

		public void CommitChanges()
		{
			Global.DatabaseProvider.Containers = this;
		}

		public IEnumerator AllItems
		{
			get { return this._collection.GetEnumerator(); }
		}

		public PortalTypeEnumerator ChangedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, true); }
		}

		public PortalTypeEnumerator CommittedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, false); }
		}

		PortalType IPortalTypeCollection.GetByIndex (int index) 
		{
			return this.GetByIndex(index);
		}

		public ContainerInfo GetByIndex (int index) 
		{
			if (index < this._collection.Length) throw new ArgumentOutOfRangeException("index");

			return this._collection[index];
		}

		#endregion

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Length; } }

		void ICollection.CopyTo(Array array, int index)
		{
			if (array is ContainerInfo[])
				this._collection.CopyTo(array, index);
			else 
				throw new InvalidCastException(String.Format("Can not cast {0} to ContainerInfo[]", array.GetType()));
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		public ContainerCollection GetContainersForPosition (int position) 
		{
			if (this._section == null) throw new ManagedFusionException(ExceptionType.BusinessLayer, "Cannot get positions in the Global Container Collection.");

			// create the cache key
			string cacheKey = String.Format("{0}-Position_For_Section-{1}-Containers", position, this._section.ID);
			int[] containers;

			// check to see if the value is cached and if it isn't cache the value
			if (Global.Cache.IsCached(cacheKey, String.Empty) == false) 
			{
				Global.Cache.Add(cacheKey, String.Empty, Global.DatabaseProvider.GetContainersInPositionForSection(this._section, position));
			}

			// get the containers from cache
			containers = Global.Cache[cacheKey, String.Empty] as int[];

			ArrayList list = new ArrayList();

			// if there are containes get the values
			if (containers != null)
				foreach(int id in containers)
					list.Add(this[id]);

			return new ContainerCollection(list.ToArray(typeof(ContainerInfo)) as ContainerInfo[], this._section);
		}

		#region Add/Remove

		internal void Add (ContainerInfo container) 
		{
			if (this.Contains(container) == false) 
			{
				container.SetState(State.Added);

				ContainerInfo[] newContainers = new ContainerInfo[this._collection.Length +1];
				this.CopyTo(newContainers, 0);
				newContainers[newContainers.Length -1] = container;
				this._collection = newContainers;
			}
		}

		internal void Remove (ContainerInfo container) 
		{
			if (this.Contains(container) == true) 
			{
				container.SetState(State.Deleted);

				// notify subscribers of change
				Global.DatabaseProvider.OnContainersChanged();
			}
		}

		#endregion
	}
}