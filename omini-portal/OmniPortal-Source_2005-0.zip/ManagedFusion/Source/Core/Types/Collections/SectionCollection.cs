#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class SectionCollection : IPortalTypeCollection
	{
		private SectionInfo[] _collection;

		public SectionCollection (SectionInfo[] sections) 
		{
			this._collection = sections;
		}

		public SectionInfo this [int id] 
		{
			get 
			{
				foreach(SectionInfo section in this._collection) 
				{
					if (section.ID == id)
						// section found and returned
						return section;
				}

				// section not found and nothing returned
				return null;
			}
		}

		public SectionInfo this [string name] 
		{
			get 
			{
				// change name to lower format to normalize compare
				name = name.ToLower();

				foreach(SectionInfo section in this._collection) 
				{
					if (section.Name.ToLower() == name)
						// section found and returned
						return section;
				}

				// section not found and nothing returned
				return null;
			}
		}

		public void CopyTo (SectionInfo[] array, int index) 
		{
			this._collection.CopyTo(array, index);
		}

		#region IPortalTypeCollection Members

		public void CommitChanges()
		{
			Global.DatabaseProvider.Sections = this;
		}

		public IEnumerator AllItems
		{
			get { return this._collection.GetEnumerator(); }
		}

		public PortalTypeEnumerator ChangedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, true); }
		}

		public PortalTypeEnumerator CommittedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, false); }
		}

		PortalType IPortalTypeCollection.GetByIndex (int index) 
		{
			return this.GetByIndex(index);
		}

		public SectionInfo GetByIndex (int index) 
		{
			if (index < this._collection.Length) throw new ArgumentOutOfRangeException("index");

			return this._collection[index];
		}
		#endregion

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Length; } }

		void ICollection.CopyTo(Array array, int index)
		{
			if (array is SectionInfo[])
				this._collection.CopyTo(array, index);
			else 
				throw new InvalidCastException(String.Format("Can not cast {0} to SectionInfo[]", array.GetType()));
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		public PortalTypeEnumerator GetEnumerator () 
		{
			return this.CommittedItems;
		}

		public bool Contains (SectionInfo section) 
		{
			return (this[section.ID] != null);
		}

		internal void Add (SectionInfo section) 
		{
			if (this.Contains(section) == false) 
			{
				section.SetState(State.Added);

				SectionInfo[] newSections = new SectionInfo[this._collection.Length +1];
				this.CopyTo(newSections, 0);
				newSections[newSections.Length -1] = section;
				this._collection = newSections;
			}
		}

		internal void Remove (SectionInfo section) 
		{
			if (this.Contains(section) == true) 
			{
				section.SetState(State.Deleted);

				// notify subscribers of change
				Global.DatabaseProvider.OnSectionsChanged();
			}
		}
	}
}