#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class PortletCollection : IPortalTypeCollection
	{
		private PortletInfo[] _collection;

		public PortletCollection (PortletInfo[] portlets) 
		{
			this._collection = portlets;
		}

		public PortletInfo this [int id] 
		{
			get 
			{  
				foreach(PortletInfo portlet in this._collection) 
				{
					if (portlet.ID == id)
						// component found and returned
						return portlet;
				}

				// component not found and nothing returned
				return null;
			}
		}

		public void CopyTo (PortletInfo[] array, int index) 
		{
			this._collection.CopyTo(array, index);
		}


		#region IPortalTypeCollection Members

		public void CommitChanges()
		{
			Global.DatabaseProvider.Portlets = this;
		}

		public IEnumerator AllItems
		{
			get { return this._collection.GetEnumerator(); }
		}

		public PortalTypeEnumerator ChangedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, true); }
		}

		public PortalTypeEnumerator CommittedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, false); }
		}

		PortalType IPortalTypeCollection.GetByIndex (int index) 
		{
			return this.GetByIndex(index);
		}

		public PortletInfo GetByIndex (int index) 
		{
			if (index < this._collection.Length) throw new ArgumentOutOfRangeException("index");

			return this._collection[index];
		}
		#endregion

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Length; } }

		void ICollection.CopyTo(Array array, int index)
		{
			if (array is PortletInfo[])
				this._collection.CopyTo(array, index);
			else 
				throw new InvalidCastException(String.Format("Can not cast {0} to PortletInfo[]", array.GetType()));
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		public PortalTypeEnumerator GetEnumerator () 
		{
			return this.CommittedItems;
		}

		public bool Contains (PortletInfo portlet) 
		{
			return (this[portlet.ID] != null);
		}

		internal void Add (PortletInfo portlet) 
		{
			if (this.Contains(portlet) == false) 
			{
				portlet.SetState(State.Added);

				PortletInfo[] newPortlets = new PortletInfo[this._collection.Length +1];
				this.CopyTo(newPortlets, 0);
				newPortlets[newPortlets.Length -1] = portlet;
				this._collection = newPortlets;
			}
		}

		internal void Remove (PortletInfo portlet) 
		{
			if (this.Contains(portlet) == true) 
			{
				portlet.SetState(State.Deleted);

				// notify subscribers of change
				Global.DatabaseProvider.OnPortletsChanged();
			}
		}
	}
}