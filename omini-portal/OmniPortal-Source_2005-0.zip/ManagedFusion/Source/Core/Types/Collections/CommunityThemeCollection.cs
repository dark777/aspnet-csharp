using System;
using System.Collections;

namespace ManagedFusion.Types
{
	public class CommunityThemeCollection : DictionaryBase
	{
		internal CommunityThemeCollection () {}

		internal CommunityThemeCollection (ThemeInfo[] themes) 
		{
			this.AddRange(themes);
		}

		internal void AddRange (ThemeInfo[] themes) 
		{
			foreach(ThemeInfo theme in themes)
				this.Add(theme);
		}

		internal void AddRange (CommunityThemeCollection themes) 
		{
			foreach(string key in themes.InnerHashtable.Keys)
				this.Add(themes[key]);
		}

		public void Add (ThemeInfo theme)
		{
			if (Contains(theme.Name) == false)
				this.InnerHashtable.Add(theme.Name, theme);
		}

		public bool Contains (string name) 
		{
			return this.InnerHashtable.Contains(name);
		}

		public ThemeInfo this [string name] 
		{
			get { return this.InnerHashtable[name] as ThemeInfo; }
		}
	}
}
