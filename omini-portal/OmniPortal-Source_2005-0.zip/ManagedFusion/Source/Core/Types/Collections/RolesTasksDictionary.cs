#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class RolesTasksDictionary : DictionaryBase
	{
		public RolesTasksDictionary (DataTable roles) 
		{
			#region Check Table

			if (roles.Columns.Contains("Role") == false
				|| roles.Columns.Contains("Tasks") == false)
				throw new ManagedFusionException(ExceptionType.DataLayer, "Roles table doesn't contain Role and/or Tasks columns.");

			#endregion

			foreach(DataRow row in roles.Rows) 
			{
				this.Add(
					(string)row["Role"],
					(string[])((string)row["Tasks"]).Split(Global.Delimiter)
					);
			}
		}

		/// <summary>Add a role and tasks set to the Dictionary.</summary>
		/// <param name="role">The role.</param>
		/// <param name="tasks">The tasks for the role.</param>
		protected void Add (string role, string[] tasks)
		{
			// check to see if the role has already been added
			// if it hasn't add the role and tasks to the hashtable
			if (this.InnerHashtable.ContainsKey(role) == false)
				this.InnerHashtable.Add(role, new ArrayList(tasks));
		}

		/// <summary>Gets all the roles contained in the Dictionary.</summary>
		public ArrayList Roles 
		{
			get { return new ArrayList(this.InnerHashtable.Keys); }
		}

		/// <summary>Get the tasks for the selected role.</summary>
		/// <param name="role">The role to get tasks for.</param>
		/// <returns>Returns an <see cref="System.Collection.ArrayList"/> of tasks the role has.</returns>
		public ArrayList GetTasks (string role) 
		{
			return (ArrayList)this.InnerHashtable[role];
		}

		/// <summary>Get roles for the task set.</summary>
		/// <param name="tasks">The task set to get roles for.</param>
		/// <returns>Returns a list of roles that have the <paramref name="tasks">tasks</paramref>.</returns>
		/// <remarks>
		/// It should be noted that this is a costly operation on large 
		/// <paramref name="tasks">tasks</paramref> array's or large
		/// roles list in this dictionary.  To asses the potential number of loops
		/// this method may go through you can multiply the following: 
		/// <code><paramref name="tasks">tasks</paramref>.Length * {RolesDictionary}.Count</code>
		/// </remarks>
		public ArrayList GetRoles (params string[] tasks) 
		{
			if (tasks == null) throw new ArgumentNullException("tasks");
			if (tasks.Length == 0) return this.Roles;

			ArrayList roles = new ArrayList(8);
			IList taskList = null;
			bool granted = false;

			// search for the tasks and add the role if found
			foreach(string role in this.Roles) 
			{
				taskList = this[role];
				granted = false;

				// go through each task and check to see if it
				// is in the current tasks list, if granted
				// stays true then the role is allowed access to
				// task set
				for (int i = 0; i < tasks.Length; i++)
					if (taskList.Contains(tasks[i]))
					{
						granted = true;
						break;
					}

				// if the role is granted add to the granted roles list
				if (granted) roles.Add(role);
			}

			roles.TrimToSize();
			return roles;
		}

		/// <summary>Get the tasks for the selected role.</summary>
		/// <param name="role">The role to get tasks for.</param>
		/// <returns>Returns an <see cref="System.Collection.ArrayList"/> of tasks the role has.</returns>
		public ArrayList this [string role] 
		{
			get { return this.GetTasks(role); }
		}
	}
}