#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class RolesPermissionsDictionary : DictionaryBase
	{
		public RolesPermissionsDictionary (DataTable roles) 
		{
			#region Check Table

			if (roles.Columns.Contains("Role") == false
				|| roles.Columns.Contains("Permissions") == false)
				throw new ManagedFusionException("Roles table doesn't contain role_id and/or role_permissions");

			#endregion

			foreach(DataRow row in roles.Rows) 
			{
				this.Add(
					(string)row["Role"],
					(string[])((string)row["Permissions"]).Split(Global.Delimiter)
					);
			}
		}

		/// <summary>Add a role and permissions set to the Dictionary.</summary>
		/// <param name="role">The role.</param>
		/// <param name="permissions">The permissions for the role.</param>
		public void Add (string role, params string[] permissions)
		{
			// check to see if the role has already been added
			// if it hasn't add the role and permissions to the hashtable
			if (this.InnerHashtable.ContainsKey(role) == false)
				this.InnerHashtable.Add(role, new ArrayList(permissions));
		}

		/// <summary>Gets all the roles contained in the Dictionary.</summary>
		public ArrayList Keys 
		{
			get { return new ArrayList(this.InnerHashtable.Keys); }
		}

		/// <summary>Get the permissions for the selected role.</summary>
		/// <param name="role">The role to get permissions for.</param>
		/// <returns>Returns an <see cref="System.Collection.ArrayList"/> of permissions the role has.</returns>
		public ArrayList GetPermissions (string role) 
		{
			return (ArrayList)this.InnerHashtable[role];
		}

		/// <summary>Get roles for the permission set.</summary>
		/// <param name="permissions">The permission set to get roles for.</param>
		/// <returns>Returns a list of roles that have the <paramref name="permissions">permissions</paramref>.</returns>
		/// <remarks>
		/// It should be noted that this is a costly operation on large 
		/// <paramref name="permissions">permissions</paramref> array's or large
		/// roles list in this dictionary.  To asses the potential number of loops
		/// this method may go through you can multiply the following: 
		/// <code><paramref name="permissions">permissions</paramref>.Length * {RolesDictionary}.Count</code>
		/// </remarks>
		public ArrayList GetRoles (string[] permissions) 
		{
			if (permissions == null) throw new ArgumentNullException("permissions");
			if (permissions.Length == 0) return this.Keys;

			ArrayList roles = new ArrayList(8);
			IList permissonList = null;
			bool granted = false;

			// search for the permissions and add the role if found
			foreach(string role in this.Keys) 
			{
				permissonList = this[role];
				granted = true;

				// go through each permission and check to see if it
				// is in the current permissions list, if granted
				// stays true then the role is allowed access to
				// permission set
				for (int i = 0; i < permissions.Length; i++)
					if (permissonList.Contains(permissions[i]) == false)
					{
						granted = false;
						break;
					}

				// if the role is granted add to the granted roles list
				if (granted) roles.Add(role);
			}

			roles.TrimToSize();
			return roles;
		}

		/// <summary>Get the permissions for the selected role.</summary>
		/// <param name="role">The role to get permissions for.</param>
		/// <returns>Returns an <see cref="System.Collection.ArrayList"/> of permissions the role has.</returns>
		public ArrayList this [string role] 
		{
			get { return this.GetPermissions(role); }
		}

	}
}