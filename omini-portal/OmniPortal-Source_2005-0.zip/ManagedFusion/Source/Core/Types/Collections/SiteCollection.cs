#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class SiteCollection : IPortalTypeCollection
	{
		private SiteInfo[] _collection;

		public SiteCollection (SiteInfo[] sites) 
		{
			this._collection = sites;
		}

		public SiteInfo this [int id] 
		{
			get 
			{
				foreach(SiteInfo site in this._collection) 
				{
					if (site.ID == id)
						// site found and returned
						return site;
				}

				// site not found and nothing returned
				return null;
			}
		}

		public SiteInfo this [string host] 
		{
			get 
			{  
				foreach(SiteInfo site in this._collection) 
				{
					if (site.ToString() == host)
						// site found and returned
						return site;
				}

				// site not found and nothing returned
				return null;
			}
		}

		public void CopyTo (SiteInfo[] array, int index) 
		{
			this._collection.CopyTo(array, index);
		}

		#region IPortalTypeCollection Members

		public void CommitChanges()
		{
			Global.DatabaseProvider.Sites = this;
		}

		public IEnumerator AllItems
		{
			get { return this._collection.GetEnumerator(); }
		}

		public PortalTypeEnumerator ChangedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, true); }
		}

		public PortalTypeEnumerator CommittedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, false); }
		}

		PortalType IPortalTypeCollection.GetByIndex (int index) 
		{
			return this.GetByIndex(index);
		}

		public SiteInfo GetByIndex (int index) 
		{
			if (index < this._collection.Length) throw new ArgumentOutOfRangeException("index");

			return this._collection[index];
		}
		#endregion

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Length; } }

		void ICollection.CopyTo(Array array, int index)
		{
			if (array is SiteInfo[])
				this._collection.CopyTo(array, index);
			else 
				throw new InvalidCastException(String.Format("Can not cast {0} to SiteInfo[]", array.GetType()));
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		public PortalTypeEnumerator GetEnumerator () 
		{
			return this.CommittedItems;
		}

		public bool Contains (SiteInfo site) 
		{
			return (this[site.ID] != null);
		}

		internal void Add (SiteInfo site) 
		{
			if (this.Contains(site) == false) 
			{
				site.SetState(State.Added);

				SiteInfo[] newSites = new SiteInfo[this._collection.Length +1];
				this.CopyTo(newSites, 0);
				newSites[newSites.Length -1] = site;
				this._collection = newSites;
			}
		}

		internal void Remove (SiteInfo site) 
		{
			if (this.Contains(site) == true) 
			{
				site.SetState(State.Deleted);

				// notify subscribers of change
				Global.DatabaseProvider.OnSitesChanged();
			}
		}
	}
}