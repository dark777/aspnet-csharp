#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	public class CommunityCollection : IPortalTypeCollection
	{
		private CommunityInfo[] _collection;

		public CommunityCollection (CommunityInfo[] Communities) 
		{
			this._collection = Communities;
		}

		public CommunityInfo this [int id] 
		{
			get 
			{
				foreach(CommunityInfo portal in this._collection) 
				{
					if (portal.ID == id)
						// portal found and returned
						return portal;
				}

				// portal not found and nothing returned
				return null;
			}
		}

		public CommunityInfo this [Guid universalIdentity] 
		{
			get 
			{  
				foreach(CommunityInfo community in this._collection) 
				{
					if (community.UniversalIdentity == universalIdentity)
						// portal found and returned
						return community;
				}

				// portal not found and nothing returned
				return null;
			}
		}

		public void CopyTo (CommunityInfo[] array, int index) 
		{
			this._collection.CopyTo(array, index);
		}

		public PortalTypeEnumerator GetEnumerator () 
		{
			return this.CommittedItems;
		}

		public bool Contains (CommunityInfo portal) 
		{
			return (this[portal.ID] != null);
		}

		#region IPortalTypeCollection Members

		public void CommitChanges()
		{
			Global.DatabaseProvider.Communities = this;
		}

		public IEnumerator AllItems
		{
			get { return this._collection.GetEnumerator(); }
		}

		public PortalTypeEnumerator ChangedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, true); }
		}

		public PortalTypeEnumerator CommittedItems 
		{
			get { return new PortalTypeEnumerator(this._collection, false); }
		}

		PortalType IPortalTypeCollection.GetByIndex (int index) 
		{
			return this.GetByIndex(index);
		}

		public CommunityInfo GetByIndex (int index) 
		{
			if (index < this._collection.Length) throw new ArgumentOutOfRangeException("index");

			return this._collection[index];
		}
		#endregion

		#region ICollection Members

		bool ICollection.IsSynchronized { get { return this._collection.IsSynchronized; } }

		public int Count { get { return this._collection.Length; } }

		void ICollection.CopyTo(Array array, int index)
		{
			if (array is CommunityInfo[])
				this._collection.CopyTo(array, index);
			else 
				throw new InvalidCastException(String.Format("Can not cast {0} to CommunityInfo[]", array.GetType()));
		}

		object ICollection.SyncRoot { get { return this._collection.SyncRoot; } }

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}

		#endregion

		#region Add/Remove

		internal void Add (CommunityInfo portal) 
		{
			if (this.Contains(portal) == false) 
			{
				portal.SetState(State.Added);

				CommunityInfo[] newCommunities = new CommunityInfo[this._collection.Length +1];
				this.CopyTo(newCommunities, 0);
				newCommunities[newCommunities.Length -1] = portal;
				this._collection = newCommunities;
			}
		}

		internal void Remove (CommunityInfo portal) 
		{
			if (this.Contains(portal) == true) 
			{
				portal.SetState(State.Deleted);

				// notify subscribers of change
				Global.DatabaseProvider.OnCommunitiesChanged();
			}
		}

		#endregion
	}
}