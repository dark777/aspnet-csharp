#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.IO;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion.Configuration;
using ManagedFusion.Data;

namespace ManagedFusion.Types
{
	/// <summary>
	/// The CommunityInfo class represents all the information, for the site, 
	/// that is requested by the DesktopDefault page on initialization.  It represents
	/// the current site.
	/// </summary>
	public sealed class CommunityInfo : PortalType
	{
		#region Static

		/// <summary></summary>
		public static CommunityInfo Current { get { return (CommunityInfo)Global.Context.Items["CommunityInfo"]; } }
		
		public static CommunityCollection Collection 
		{
			get { return Global.DatabaseProvider.Communities; }
		}

		public static CommunityInfo CreateNew () 
		{
			CommunityInfo portal = new CommunityInfo(
				-1,
				Guid.NewGuid()
				);

			portal.SetState(State.Added);

			return portal;
		}

		public static void AddPortal (CommunityInfo portal) 
		{
			Collection.Add(portal);
		}

		public static void RemovePortal (CommunityInfo portal) 
		{
			Collection.Remove(portal);
		}

		#endregion

		#region Fileds

		private readonly int _id;
		private readonly Guid _universalIdentity;
		private string _title;
		private DateTime _touched;
		private string _head;

		#endregion

		#region Constructors

		public CommunityInfo (int id, Guid universalIdentity, string title, DateTime touched) 
		{
			if (id < 1) throw new ArgumentOutOfRangeException("id", id, "ID must be greater than zero.");
			if (title == null || title.Length == 0) throw new ArgumentNullException("title");

			this._id = id;
			this._universalIdentity = universalIdentity;
			this._title = title;
			this._touched = touched;

			// setup events
			this.SetupEvents();
		}

		private CommunityInfo (int id, Guid universalIdentity) 
		{
			this._id = id;
			this._universalIdentity = universalIdentity;
			this._touched = DateTime.Now;

			// setup events
			this.SetupEvents();
		}

		private void SetupEvents () 
		{
			Global.DatabaseProvider.SitesChanged += new EventHandler(InvalidateExternalSitesCollections);
		}

		#endregion

		#region Properties

		/// <summary>The ID associated with the portal.</summary>
		public override int ID 
		{ 
			get { return _id; } 
		}

		/// <summary>The Universal Identity associated with the portal.</summary>
		public Guid UniversalIdentity 
		{ 
			get { return this._universalIdentity; } 
		}

		/// <summary>A Pages Title.</summary>
		public string Title 
		{ 
			get { return _title; } 
			set
			{
				this._title = value;
				this.ValueChanged();
			}
		}
		
		/// <summary>The date the site was last updated.</summary>
		public override DateTime Touched 
		{ 
			get { return this._touched; } 
			set { this._touched = value; }
		}

		/// <summary></summary>
		public string HeaderText
		{
			get 
			{
				if (this._head != null)
					return this._head;

				string path;

				// get the path for /Communities/{ID}/Head.html and if it does
				// not exist then return an empty string
				if (Global.Path.VerifyCommunityPath(this.ID, PortalProperties.HeaderFile, out path) == false)
					return String.Empty;

				// read the file from the path
				using (StreamReader reader = File.OpenText(Global.Path.GetAbsoluteDiskPath(path))) 
				{
					// set the head
					this._head = reader.ReadToEnd();
					reader.Close();
				}

				return this._head;
			}
		}

		private SiteCollection _ConnectedSites;
		public SiteCollection ConnectedSites
		{
			get 
			{
				if (this._ConnectedSites != null) return this._ConnectedSites;

				ArrayList list = new ArrayList();

				foreach(SiteInfo site in SiteInfo.Collection) 
				{
					if (site.ConnectedCommunity.ID == this.ID)
						list.Add(site);
				}

				this._ConnectedSites = new SiteCollection((SiteInfo[])list.ToArray(typeof(SiteInfo)));
				return this._ConnectedSites;
			}
		}

		private NameValueCollection _Properties;
		/// <summary></summary>
		public NameValueCollection Properties
		{
			get 
			{
				if (_Properties != null) return this._Properties;

				this._Properties = Global.DatabaseProvider.GetGeneralPropertiesForCommunity(this);
				return this._Properties;
			}
		}

		private CommunityThemeCollection _AvailableSkins;
		/// <summary></summary>
		public CommunityThemeCollection AvailableSkins 
		{
			get 
			{
				if (this._AvailableSkins != null)
					return this._AvailableSkins;
				
				this._AvailableSkins = ThemeInfo.Collection.GetThemes(this, true);
				return this._AvailableSkins;
			}
		}

		/// <summary></summary>
		public CommunityThemeCollection Skins
		{
			get { return ThemeInfo.Collection.GetThemes(this); }
		}

		/// <summary></summary>
		public ThemeInfo DefaultTheme
		{
			get { return ThemeInfo.Collection[Config.DefaultTheme, this]; }
		}

		/// <summary></summary>
		public PortalConfiguration Config 
		{ 
			get { return Global.WebConfig.Current; } 
		}

		#endregion

		#region Methods

		public void AddSite (SiteInfo site) 
		{
			// check to see if site is already pointing
			// to this portal
			if (this._ConnectedSites.Contains(site)) return;

			// set site connected to this portal
			site.ConnectedCommunity = this;

			// reset the connected sites array so it is refreshed
			// next time it is called
			this._ConnectedSites = null;
		}

		public void RemoveSite (SiteInfo site) 
		{
			// check to see if site is already pointing
			// to this portal
			if (this._ConnectedSites.Contains(site) == false) return;

			// set site connected to this portal to nothing
			site.ConnectedCommunity = null;

			// reset the connected sites array so it is refreshed
			// next time it is called
			this._ConnectedSites = null;
		}

		/// <summary>Writes the object to a string.</summary>
		/// <returns>Returns the name of the page.</returns>
		public override string ToString() 
		{
			return this.Title; 
		}

		private void InvalidateExternalSitesCollections(object sender, EventArgs e)
		{
			this._ConnectedSites = null;
		}

		protected override void CommitChangesToDatabase()
		{
			Global.DatabaseProvider.CommitPortalChanges(this);

			switch(this.State) 
			{
				case State.Added :
				case State.Deleted :
					Global.DatabaseProvider.ResetCommunityCollection();
					break;

				case State.Changed :
					Global.DatabaseProvider.OnCommunitiesChanged();
					break;
			}
		}

		#endregion
	}
}