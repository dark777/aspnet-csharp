#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections;

namespace ManagedFusion.Types
{
	public sealed class RootSection
	{
		public const int ID = 0;

		public RootSection() 
		{ 
			this.SetupEvents();
		}

		private void SetupEvents () 
		{
			Global.DatabaseProvider.SectionsChanged += new EventHandler(InvalidateExternalSectionsCollections);
		}

		private SectionCollection _Children;
		/// <summary>The children of the current section.</summary>
		public SectionCollection Children
		{
			get 
			{
				if (this._Children != null) return this._Children;

				ArrayList list = new ArrayList();

				foreach(SectionInfo section in SectionInfo.Collection) 
				{
					if (section.ParentID == ID)
						list.Add(section);
				}

				this._Children = new SectionCollection((SectionInfo[])list.ToArray(typeof(SectionInfo)));

				return this._Children;
			}
		}

		private void InvalidateExternalSectionsCollections(object sender, EventArgs e)
		{
			this._Children = null;
		}
	}
}