#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections;

namespace ManagedFusion.Types
{
	/// <summary>
	/// Summary description for Container.
	/// </summary>
	public class ContainerInfo : PortalType
	{
		#region Static

		public static ContainerCollection Collection 
		{
			get { return Global.DatabaseProvider.Containers; }
		}

		public static ContainerInfo CreateNew () 
		{
			ContainerInfo container = new ContainerInfo();
			container.SetState(State.Added);

			return container;
		}

		public static void AddContainer (ContainerInfo container) 
		{
			Collection.Add(container);
		}

		public static void RemoveContainer (ContainerInfo container) 
		{
			Collection.Remove(container);
		}

		#endregion

		#region Fields

		private readonly int _id;
		private string _title;
		private DateTime _touched;

		#endregion

		#region Constructors

		public ContainerInfo (int id, string title, DateTime touched) 
		{
			this._id = id;
			this._title = title;
			this._touched = touched;

			// setup events
			this.SetupEvents();
		}

		private ContainerInfo () 
		{
			this._id = TempID;
			this._touched = DateTime.Now;

			// setup events
			this.SetupEvents();
		}

		private void SetupEvents () 
		{
			Global.DatabaseProvider.ContainersChanged += new EventHandler(InvalidateExternalPortletsCollections);
		}

		#endregion

		#region Properties

		public override int ID { get { return this._id; } }

		public string Title 
		{
			get { return this._title; }
			set 
			{
				this._title = value;
				this.ValueChanged();
			}
		}

		public override DateTime Touched 
		{ 
			get { return this._touched; }
			set { this._touched = value; }
		}

		private PortletCollection _Portlets;
		public PortletCollection Portlets 
		{
			get 
			{ 
				if (this._Portlets != null) return this._Portlets;

				ArrayList list = new ArrayList();

				// _Portlets was null populate the variable
				foreach(int id in Global.DatabaseProvider.GetPortletsForContainer(this))
					list.Add(PortletInfo.Collection[id]);

				this._Portlets = new PortletCollection((PortletInfo[])list.ToArray(typeof(PortletInfo)));
				return this._Portlets;
			}
		}

		#endregion

		#region Methods

		public void AddPortlet (PortletInfo portlet) 
		{
			// add portlet to this container
			Global.DatabaseProvider.AddContainerPortletLink(this, portlet, 0);

			// reset portlets collection
			this._Portlets = null;
		}

		public void RemovePortlet (PortletInfo portlet) 
		{
			// remove portlet from this container
			Global.DatabaseProvider.RemoveContainerPortletLink(this, portlet);

			// reset portlets collection
			this._Portlets = null;
		}

		private void InvalidateExternalPortletsCollections(object sender, EventArgs e)
		{
			this._Portlets = null;
		}

		protected override void CommitChangesToDatabase()
		{
			Global.DatabaseProvider.CommitContainerChanges(this);

			switch(this.State) 
			{
				case State.Added :
				case State.Deleted :
					Global.DatabaseProvider.ResetContainerCollection();
					break;

				case State.Changed :
					Global.DatabaseProvider.OnContainersChanged();
					break;
			}
		}

		#endregion
	}
}