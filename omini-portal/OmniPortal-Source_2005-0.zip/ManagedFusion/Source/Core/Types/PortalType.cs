#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

namespace ManagedFusion.Types
{
	public enum State 
	{
		NoChanges,
		Changed,
		Added,
		Deleted
	}

	public abstract class PortalType
	{
		/// <summary></summary>
		public const int TempID = -1;

		#region Properties

		/// <summary></summary>
		public abstract int ID { get; }

		/// <summary></summary>
		public abstract DateTime Touched { get; set; }

		private State _State = State.NoChanges;
		/// <summary></summary>
		public State State { get { return _State; } }

		#endregion

		#region Methods

		/// <summary></summary>
		protected internal void SetState (State state) 
		{
			this._State = state;
		}

		/// <summary></summary>
		public void Delete () 
		{
			_State = State.Deleted;
		}

		/// <summary></summary>
		public void UnDelete () 
		{
			_State = State.Changed;
		}

		/// <summary></summary>
		protected void ValueChanged () 
		{
			if (_State != State.Added)
				_State = State.Changed;

			this.Touched = DateTime.Now;
		}

		/// <summary></summary>
		public void CommitChanges () 
		{
			// commit changes only if there are not changes
			if (_State != State.NoChanges)
				this.CommitChangesToDatabase();
		}

		protected abstract void CommitChangesToDatabase ();

		/// <summary></summary>
		/// <returns></returns>
		public new virtual string ToString()
		{
			return this.ID.ToString();
		}
		#endregion
	}
}