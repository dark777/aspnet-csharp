#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;

// ManagedFusion Classes
using ManagedFusion.Display.Modules;
using ManagedFusion.Display.Modules.Config;

namespace ManagedFusion.Types
{
	public sealed class SectionModule : ModuleInfo
	{
		private bool _traversable;

		public SectionModule (ModuleAttribute attribute, Type type)
			: base (attribute.ModuleID, attribute.Title, attribute.Description, type)
		{ 
			this._traversable = attribute.TraversablePath;
		}

		public static ModuleCollection Collection 
		{
			get { return Global.DatabaseProvider.SectionModules; }
		}

		private static SectionModule _ErrorModule = (SectionModule)Collection[new Guid(0xAACA68FA, 0x4FA2, 0x4a4a, 0xA7, 0x0C, 0xBF, 0x40, 0x0A, 0xFF, 0x27, 0x8F)];
		/// <summary>Gets the Error Module with GUID of {AACA68FA-4FA2-4a4a-A70C-BF400AFF278F}.</summary>
		public static SectionModule ErrorModule 
		{
			get { return _ErrorModule; }
		}

		/// <summary>Gets if the module's URL Path is traversable or not.</summary>
		public bool IsUrlPathTraversable { get { return this._traversable; } }

		/// <summary></summary>
		public ModuleConfig Config 
		{
			get 
			{
				ModuleConfig config = Global.ExecutingModule.Config;
			
				// check to see if the config has been processed yet
				if (config == null)
					throw new ManagedFusionException(ExceptionType.BusinessLayer,
						String.Format("The module, {0}, has not had its config processed yet.", this.Title)
						);

				return config;
			}
		}
	}
}