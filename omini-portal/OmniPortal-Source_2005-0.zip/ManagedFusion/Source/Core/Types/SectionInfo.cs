#region Copyright © 2004, Nicholas Berardi
/*
 * ManagedFusion (www.ManagedFusion.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * ManagedFusion is freely available from <http://www.ManagedFusion.net/>
 */
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion.Display;
using ManagedFusion.Data;
using ManagedFusion.Security;
using ManagedFusion.Display.Modules;
using ManagedFusion.Display.Modules.Config;

namespace ManagedFusion.Types
{
	/// <summary>
	/// The SectionInfo class represents all the information that is requested 
	/// by the PortalDesktop page on initialization to customize the over all page.
	/// </summary>
	public sealed class SectionInfo : PortalType
	{
		# region Static

		/// <summary></summary>
		public static SectionInfo Current { get { return (SectionInfo)Global.Context.Items["SectionInfo"]; } }

		public static SectionCollection Collection 
		{
			get { return Global.DatabaseProvider.Sections; }
		}

		private static RootSection _Root = new RootSection();
		public static RootSection Root
		{
			get { return _Root; }
		}

		public static SectionInfo CreateNew () 
		{
			SectionInfo section = new SectionInfo(
				TempID,
				RootSection.ID,
				TempID,
				true
				);

			section.SetState(State.Added);

			return section;
		}

		public static void AddSection (SectionInfo section) 
		{
			Collection.Add(section);
		}

		public static void RemoveSection (SectionInfo section) 
		{
			Collection.Remove(section);
		}

		#endregion

		#region Fields

		private readonly int _id;
		private string _name;			// name to display on buttons
		private string _title;			// title to display on browser
		private int _parentID;			// parent section id
		private int _primaryParentID;	// primary parent section id
		private int _order;
		private bool _syndicated;
		private bool _visible;			// section is enabled for viewing
		private string _originalTheme;
		private string _originalStyle;	
		private string _owner;
		private Guid _moduleID;
		private DateTime _touched;

		#endregion

		#region Constructor

		/// <summary>
		/// Initializes the SectionInfo class by assigining values to its properties.
		/// </summary>
		public SectionInfo(
			int id,
			string name,
			string title,
			int primaryParentID,
			int parentID,
			int order,
			bool visible,
			bool syndicated,
			string theme,
			string style,
			Guid moduleID,
			string owner,
			DateTime touched
			)
		{
			if (id < 1) throw new ArgumentOutOfRangeException("id", id, "ID must be greater than zero.");

			this._id = id;
			this._name = name;
			this._title = title;
			this._parentID = parentID;
			this._primaryParentID = primaryParentID;
			this._order = order;
			this._visible = visible;
			this._syndicated = syndicated;
			this._originalTheme = theme;
			this._originalStyle = style;
			this._moduleID = moduleID;
			this._owner = owner;
			this._touched = touched;

			// setup events
			this.SetupEvents();
		}

		public SectionInfo(
			int id,
			string name,
			string title,
			SectionInfo primaryParent,
			SectionInfo parent,
			int order,
			bool visible,
			bool syndicated,
			string theme,
			string style,
			SectionModule module,
			string owner,
			DateTime touched
			)
			: this (
			id,
			name,
			title,
			primaryParent.ID,
			parent.ID,
			order,
			visible,
			syndicated,
			theme,
			style,
			module.ID,
			owner,
			touched
			)
		{
		}

		private SectionInfo (int id, int parentID, int primaryParentID, bool visible) 
		{
			this._id = id;
			this._parentID = parentID;
			this._primaryParentID = primaryParentID;
			this._visible = visible;
			this._touched = DateTime.Now;

			// setup events
			this.SetupEvents();
		}

		private void SetupEvents () 
		{
			Global.DatabaseProvider.SectionsChanged += new EventHandler(InvalidateExternalSectionsCollections);
			Global.DatabaseProvider.SitesChanged += new EventHandler(InvalidateExternalSitesCollections);
			Global.DatabaseProvider.ContainersChanged += new EventHandler(InvalidateExternalContainersCollections);
		}

		#endregion

		#region Properties In Database

		/// <summary>The ID associated with the page.</summary>
		public override int ID { get { return _id; } }

		/// <summary>A Pages Name.</summary>
		public string Name 
		{ 
			get { return _name; } 
			set 
			{ 
				this._name = value;
				this.ValueChanged();
			}
		}

		/// <summary>A Pages Title.</summary>
		public string Title 
		{ 
			get 
			{
				if (_title.Length == 0)
					return _name;
				return _title; 
			}
			set 
			{
				this._title = value;
				this.ValueChanged();
			}
		}

		/// <summary>The parent of the section.</summary>
		internal int ParentID { get { return this._parentID; } }
		
		/// <summary>The primary partent of the section.</summary>
		private int PrimaryParentID { get { return this._primaryParentID; } }
		
		/// <summary>The module that the section uses.</summary>
		private Guid ModuleID { get { return this._moduleID; } }

		/// <summary>The order of the section.</summary>
		public int Order 
		{ 
			get { return this._order; }
			set 
			{
				this._order = value; 
				this.ValueChanged();
			}
		}
		
		/// <summary>Is the section visible?</summary>
		public bool Visible 
		{ 
			get { return this._visible; } 
			set 
			{
				this._visible = value;
				this.ValueChanged();
			}
		}
		
		/// <summary>Is the section syndicated?</summary>
		public bool Syndicated
		{
			get { return this._syndicated; }
			set 
			{
				this._syndicated = value;
				this.ValueChanged();
			}
		}

		/// <summary>The skin used in this section.</summary>
		public string OriginalTheme
		{ 
			get { return this._originalTheme; } 
			set 
			{
				this._originalTheme = value; 
				this._theme = null;
				this._themeName = null;
				this.ValueChanged();
			}
		}
		
		/// <summary>The style used in this section.</summary>
		public string OriginalStyle 
		{ 
			get { return this._originalStyle; }
			set 
			{
				this._originalStyle = value;
				this._style = null;
				this._styleName = null;
				this.ValueChanged();
			}
		}

		/// <summary>The owner of this section.</summary>
		public string OriginalOwner
		{ 
			get { return this._owner; }
			set 
			{
				this._owner = value;
				this._owners = null;
				this.ValueChanged();
			}
		}

		/// <summary>Last time the section was updated.</summary>
		public override DateTime Touched 
		{ 
			get { return this._touched; } 
			set { this._touched = value; }
		}

		#endregion

		#region Properties Not In Database

		private NameValueCollection _ModuleData;
		/// <summary></summary>
		public NameValueCollection ModuleData
		{
			get 
			{
				if (_ModuleData != null) return this._ModuleData;

				this._ModuleData = Global.DatabaseProvider.GetModuleDataForSection(this);
				return this._ModuleData;
			}
		}

		private NameValueCollection _MetaProperties;
		/// <summary></summary>
		public NameValueCollection MetaProperties 
		{
			get 
			{
				if (_MetaProperties != null) return this._MetaProperties;

				this._MetaProperties = Global.DatabaseProvider.GetMetaPropertiesForSection(this);
				return this._MetaProperties;
			}
		}

		private NameValueCollection _Properties;
		/// <summary></summary>
		private NameValueCollection Properties 
		{
			get 
			{
				if (_Properties != null) return this._Properties;

				this._Properties = Global.DatabaseProvider.GetGeneralPropertiesForSection(this);
				return this._Properties;
			}
		}

		private StringCollection _owners;
		/// <summary>The owners of this section.</summary>
		public StringCollection Owners 
		{
			get 
			{
				if (this._owners != null) return this._owners;

				StringCollection owners = new StringCollection();

				SectionInfo parent = this.Parent;
				owners.Add(this.OriginalOwner);

				// keep working the way to primary parent to
				// create a list of owners
				while(parent != null)
				{
					// check to see if owner is already in list
					if (owners.Contains(parent.OriginalOwner) == false)
						owners.Add(parent.OriginalOwner);

					parent = parent.Parent;
				}

				this._owners = owners;
				return this._owners; 
			}
		}

		/// <summary>The assembly content string.</summary>
		public SectionModule Module 
		{ 
			get 
			{ 
				ModuleInfo module = SectionModule.Collection[this._moduleID];

				// check to see if the module that was referenced is found
				// check to see if module is of IModule
				if (module == null ||
					module.Type.GetInterface("IModule", true) == null)
				{
					Global.Context.Trace.Warn("Module Failure", String.Format("Module, {0:B}, was not found.", this._moduleID));
					return SectionModule.ErrorModule;
				}

				return (SectionModule)module;
			}
			set 
			{
				this._moduleID = value.ID;
				this.ValueChanged();
			}
		}

		private ThemeInfo _theme;
		public ThemeInfo Theme 
		{
			get 
			{
				if (this._theme != null) return this._theme;

				this._theme = ThemeInfo.Collection[ThemeName];
				return this._theme;
			}
		}

		private StyleInfo _style;
		public StyleInfo Style 
		{
			get 
			{
				if (this._style != null) return this._style;

				this._style = Theme.Styles[StyleName]; 
				return this._style;
			}
		}

		private string _themeName;
		/// <summary>The skin used in this section.</summary>
		internal string ThemeName
		{ 
			get 
			{
				if (this._themeName != null) return this._themeName;

				// check to see if this section uses an inherited skin
				// from parent
				if (this.OriginalTheme == ThemeInfo.Inherited) 
				{
					SectionInfo parent = this.Parent;

					// check to see if parent exists
					if (parent != null) 
					{
						// go up parent chain until theme is found
						while (parent.ThemeName == ThemeInfo.Inherited) 
							parent = parent.Parent;

						this._themeName = parent.ThemeName;
					}
					else 
						this._themeName = CommunityInfo.Current.Config.DefaultTheme;
				}
				else
					this._themeName = this.OriginalTheme;

				return this._themeName; 
			}
			set { this.OriginalTheme = value; }
		}
		
		private string _styleName;
		/// <summary>The style used in this section.</summary>
		internal string StyleName
		{ 
			get 
			{
				if (this._styleName != null) return this._styleName;

				// check to see if this section uses an inherited style
				// from parent
				if (this.OriginalStyle == ThemeInfo.Inherited) 
				{
					SectionInfo parent = this.Parent;

					// check to see if parent exists
					if (parent != null) 
					{
						// go up parent chain until theme is found
						while (parent.StyleName == ThemeInfo.Inherited) 
							parent = parent.Parent;

						this._styleName = parent.StyleName;
					} 
					else
						this._styleName = CommunityInfo.Current.Config.DefaultStyle;
				} 
				else
					this._styleName = this.OriginalStyle;

				return this._styleName; 
			}
			set { this.OriginalStyle = value; }
		}

		/// <summary>No Theme is being used?</summary>
		public bool NoTheme 
		{ 
			get { return this.OriginalTheme == ThemeInfo.NoTheme; } 
		}

		private string _fullPath;
		/// <summary>The path to the section.</summary>
		private string FullPath 
		{ 
			get 
			{
				if (this._fullPath != null) return this._fullPath;

				ArrayList pathList = new ArrayList();

				SectionInfo parent = this.Parent;
				pathList.Add(this.Name);

				// keep working the way to primary parent to
				// create a list of names in path
				while(parent != null)
				{
					pathList.Add(parent.Name);
					parent = parent.Parent;
				}

				// remove primary parent from list because it is the root
				pathList.Remove(this.PrimaryParent.Name);

				// reverse the order of the names in list
				pathList.Reverse();

				// create path
				this._fullPath = String.Concat(
					"/", 
					String.Join("/", (string[])pathList.ToArray(typeof(string))),
					"/"
					).Replace("//", "/");
				return this._fullPath; 
			} 
		}

		/// <summary>The Uri to this section.</summary>
		public Uri UrlPath 
		{
			get { return Global.Path.GetPortalUrl(this.Path); }
		}

		/// <summary>The Path to the section that is normalized depending on entry point through Portal.</summary>
		public string Path 
		{
			get 
			{
				return String.Concat("/", 
					FullPath.Remove(0, SiteInfo.Current.ConnectedSection.FullPath.Length),
					"/").Replace("//", "/");
			}
		}

		/// <summary>The parent of the current section.</summary>
		public SectionInfo Parent 
		{
			get { return Collection[this._parentID]; }
			set 
			{
				this._parentID = value.ID; 
				this.ValueChanged();
			}
		}

		/// <summary>The primary parent of the current section.</summary>
		public SectionInfo PrimaryParent
		{
			get { return Collection[this._primaryParentID]; }
			set 
			{
				this._primaryParentID = value.ID;
				this.ValueChanged();
			}
		}

		public void AddContainer (ContainerInfo container, int position) 
		{
			// add container to this section
			Global.DatabaseProvider.AddSectionContainerLink(this, container, position, 0);

			// reset containers collection
			this._Containers = null;
		}

		public void RemoveContainer (ContainerInfo container) 
		{
			// remove container from this section
			Global.DatabaseProvider.RemoveSectionContainerLink(this, container);

			// reset containers collection
			this._Containers = null;
		}

		private ContainerCollection _Containers;
		public ContainerCollection Containers 
		{
			get 
			{ 
				if (this._Containers != null) return this._Containers;

				ArrayList list = new ArrayList();

				// _Containers was null populate the variable
				foreach(int id in Global.DatabaseProvider.GetContainersForSection(this))
					list.Add(ContainerInfo.Collection[id]);

				this._Containers = new ContainerCollection(list.ToArray(typeof(ContainerInfo)) as ContainerInfo[], this);
				return this._Containers;
			}
		}

		private SectionCollection _Children;
		/// <summary>The children of the current section.</summary>
		public SectionCollection Children
		{
			get 
			{
				if (this._Children != null) return this._Children;

				ArrayList list = new ArrayList();

				foreach(SectionInfo section in Collection) 
				{
					if (section.ParentID == this.ID)
						list.Add(section);
				}

				this._Children = new SectionCollection((SectionInfo[])list.ToArray(typeof(SectionInfo)));

				return this._Children;
			}
		}

		private SiteCollection _ConnectedSites;
		public SiteCollection ConnectedSites
		{
			get 
			{
				if (this._ConnectedSites != null) return this._ConnectedSites;

				ArrayList list = new ArrayList();

				foreach(SiteInfo site in SiteInfo.Collection) 
				{
					if (site.ConnectedSection.ID == this.ID)
						list.Add(site);
				}

				this._ConnectedSites = new SiteCollection((SiteInfo[])list.ToArray(typeof(SiteInfo)));
				return this._ConnectedSites;
			}
		}

		#endregion

		# region Authorization

		public void AddRole (string role, string[] tasks) 
		{
			Global.DatabaseProvider.AddRoleForSection(role, tasks, this);

			// reset roles to refresh next time
			this._roles = null;
		}

		public void RemoveRole (string role) 
		{
			Global.DatabaseProvider.RemoveRoleForSection(role, this);

			// reset roles to refresh next time
			this._roles = null;
		}

		private RolesTasksDictionary _roles;
		public RolesTasksDictionary Roles 
		{
			get 
			{
				if (this._roles != null) return this._roles;
		
				// get roles list for this section
				this._roles = Global.DatabaseProvider.GetRolesForSection(this);
				return this._roles;
			}
		}

		public bool UserHasPermissions (Permissions p) 
		{
			return Global.Security.HasPermissions(p, this);
		}

		/// <summary>Get the tasks for selected <see cref="Permissions"/>.</summary>
		/// <param name="permissions">The permissions to get the tasks for.</param>
		/// <returns>Returns a list of tasks for the <paramref name="permissions" />.</returns>
		public string[] GetTasks (Permissions permissions) 
		{
			string key = String.Format("Section-Tasks-{0}--{1}", this.ID, permissions.ToString());

			// checks to see if the tasks have been cached for these permissions
			// this is nessisary because this opperation is a potentially
			// intensive operation
			if (Global.Cache.IsCached(key) == false) 
			{
				ArrayList tlist = new ArrayList();

				// add the view page task if it has the permissions
				// this is default for all sections
				Task viewPage = Task.ViewPageTask;
				if (viewPage.CheckAccess(permissions))
					tlist.Add(viewPage.Name);

				// go through each task and check the access
				foreach(Task task in this.Module.Config.Tasks) 
				{
					if (task.CheckAccess(permissions))
						tlist.Add(task.Name);
				}

				// add to cache
				Global.Cache.Add(key, tlist.ToArray(typeof(string)));
			}

			string[] list = Global.Cache[key] as string[];
 
			// if it has no tasks is null then no tasks are returned
			return (list != null) ? list : new string[0];
		}

		/// <summary>Get the roles for selected tasks.</summary>
		/// <param name="tasks">The tasks to get the roles for.</param>
		/// <returns>Returns a list of roles for the <paramref name="tasks" />.</returns>
		public string[] GetRoles (params string[] tasks) 
		{
			string key = String.Format("Section-Roles-{0}--{1}", this.ID, String.Join(Global.Delimiter.ToString(), tasks));

			// checks to see if the roles have been cached for these tasks
			// this is nessisary because RolesDictionary.GetRoles is a potentially
			// intensive operation
			if (Global.Cache.IsCached(key) == false) 
			{
				ArrayList rlist = this.Roles.GetRoles(tasks);

				// add to cache
				Global.Cache.Add(key, rlist.ToArray(typeof(string)));
			}

			string[] list = Global.Cache[key] as string[];
 
			// if it has no tasks is null then no roles are returned
			return (list != null) ? list : new string[0];
		}

		#endregion

		#region Utilities

		public SectionInfo GetSectionForPath (string path) 
		{
			// return if the module is Traversable
			if (this.Module.IsUrlPathTraversable) return this;

			// removes init whack if exception occures return this SectionInfo
			try 
			{
				if (path[0] == '/') 
					path = path.Substring(1); 
			}
			catch (IndexOutOfRangeException) 
			{
				return this; 
			}
			
			// if there is nothing left return this SectionInfo
			if (path.Length == 0) return this;

			string[] split = path.Split(new char[] { '/' }, 2);

			// if the split URL doesn't get split
			if (split.Length != 2) return this;

			return this.Children[split[0]].GetSectionForPath(split[1]);
		}

		#endregion

		#region Invalidate Data Events

		private void InvalidateExternalSectionsCollections(object sender, EventArgs e)
		{
			this._fullPath	= null;
			this._owners = null;
			this._theme = null;
			this._style = null;
			this._Children = null;
		}

		private void InvalidateExternalSitesCollections(object sender, EventArgs e)
		{
			this._ConnectedSites = null;
		}

		private void InvalidateExternalContainersCollections(object sender, EventArgs e)
		{
			this._Containers = null;
		}

		#endregion

		#region Commit Changes

		protected override void CommitChangesToDatabase()
		{
			Global.DatabaseProvider.CommitSectionChanges(this);

			switch(this.State) 
			{
				case State.Added :
				case State.Deleted :
					Global.DatabaseProvider.ResetSectionCollection();
					break;

				case State.Changed :
					Global.DatabaseProvider.OnSectionsChanged();
					break;
			}
		}

		#endregion

		/// <summary>Writes the object to a string.</summary>
		/// <returns>Returns the name of the page.</returns>
		public override string ToString()
		{
			return this.Name;
		}
	}
}