namespace OmniPortal.Components.Themes.Mambo.Skin.Pages
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Collections.Specialized;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	// ManagedFusion Classes
	using ManagedFusion;
	using ManagedFusion.Types;

	/// <summary>
	///		Summary description for Template.
	/// </summary>
	public class Template : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Repeater topNavRepeater;
		protected System.Web.UI.WebControls.Repeater childrenRepeater;
		protected System.Web.UI.WebControls.Repeater innerMenuRepeater;
		protected System.Web.UI.WebControls.PlaceHolder contentPlaceHolder;
		protected System.Web.UI.WebControls.PlaceHolder rightModulesPlaceHolder;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false) 
			{
				this.topNavRepeater.DataBind();

				this.innerMenuRepeater.Visible = (InnerMenu.Count != 0);
				if (this.innerMenuRepeater.Visible)
					this.innerMenuRepeater.DataBind();

				this.childrenRepeater.Visible = (SectionInformation.Children.Count != 0 && SectionInformation.Parent != null);	
				if (this.childrenRepeater.Visible)
					this.childrenRepeater.DataBind();
			}
		}

		protected SectionInfo SectionInformation 
		{
			get { return SectionInfo.Current; }
		}

		protected NameValueCollection InnerMenu 
		{
			get 
			{
				if (Context.Items["InnerMenu"] == null)
					Context.Items["InnerMenu"] = new NameValueCollection(0);
				return (NameValueCollection)Context.Items["InnerMenu"];
			}
		}

		protected override void OnInit(EventArgs e)
		{

			this.Load += new System.EventHandler(this.Page_Load);
			base.OnInit(e);

			this.contentPlaceHolder.Controls.Add(Global.ExecutingModule.GetContentHolder(Position.Center));
			this.rightModulesPlaceHolder.Controls.Add(Global.ExecutingModule.GetContentHolder(Position.Right));
		}
	}
}
