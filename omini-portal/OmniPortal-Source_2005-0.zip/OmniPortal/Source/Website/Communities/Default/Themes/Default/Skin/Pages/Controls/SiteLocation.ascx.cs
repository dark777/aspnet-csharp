#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	/// <summary>
	///		Summary description for SiteLocation.
	/// </summary>
	public class SiteLocation_Ascx : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater locationRepeater;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
			{
				// data bind
				DataBind();
			}
		}

		protected string[] Locations 
		{
			get { return (string[])ViewState["Locations"]; }
			set { ViewState["Locations"] = value; }
		}
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new EventHandler(Page_Load);

			// enable view state for control
			this.EnableViewState = true;

			// set locations array
			this.Locations = SectionInformation.Path.TrimStart('/').Split('/');
			
			this.locationRepeater.ItemDataBound += new System.Web.UI.WebControls.RepeaterItemEventHandler(this.locationRepeater_ItemDataBound);
			this.locationRepeater.DataSource = this.Locations;
		
			base.OnInit (e);
		}

		private void locationRepeater_ItemDataBound(object sender, System.Web.UI.WebControls.RepeaterItemEventArgs e)
		{
			// checks to see if the item to be bound is item or alternating item
			if (e.Item.ItemType == ListItemType.Item  || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				// create link control
				HyperLink link = (HyperLink)e.Item.FindControl("locationHyperLink");

				// set control data
				link.Text = (string)e.Item.DataItem;
				
				// create location
				string linkLocation = String.Empty;
				int index = e.Item.ItemIndex;

				do 
				{
					linkLocation = String.Format("{0}/{1}", this.Locations[index--], linkLocation);
				} while (index > -1);

				// set the navigation URL
				link.NavigateUrl = Global.Path.GetPortalUrl(String.Concat("/", linkLocation, "Default.aspx")).ToString();
			}
		}
	}
}