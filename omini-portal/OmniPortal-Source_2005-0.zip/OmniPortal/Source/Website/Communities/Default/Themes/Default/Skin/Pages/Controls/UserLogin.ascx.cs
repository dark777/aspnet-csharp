#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	public class UserLogin_Ascx : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Button loginButton;
		protected System.Web.UI.WebControls.Button logoutButton;
		protected System.Web.UI.WebControls.TextBox userNameTextBox;
		protected System.Web.UI.WebControls.TextBox passwordTextBox;
		protected System.Web.UI.WebControls.CheckBox rememberCheckBox;
		protected System.Web.UI.WebControls.Label messageLabel;
		protected System.Web.UI.HtmlControls.HtmlGenericControl logedInPanel;
		protected System.Web.UI.HtmlControls.HtmlGenericControl logedOutPanel;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.IsAuthenticated == true) 
			{
				messageLabel.Visible = true;
				messageLabel.ForeColor = Color.Black;
				messageLabel.Text = String.Format("Welcome, {0}!", Global.Security.Identity.Name);
				this.ShowForm(false);
			} 
			else 
				this.ShowForm(true);
		}

		private void ShowForm (bool visible) 
		{
			this.logedOutPanel.Visible = visible;
			this.logedInPanel.Visible = !visible;
		}

		protected override void OnInit(EventArgs e)
		{
			this.loginButton.Text = this.CultureManager["Login"];
			this.logoutButton.Text = this.CultureManager["Logout"];

			this.Load += new System.EventHandler(this.Page_Load);
			this.loginButton.Click += new EventHandler(loginButton_Click);
			this.logoutButton.Click += new EventHandler(logoutButton_Click);
		
			base.OnInit (e);
		}

		private void loginButton_Click (object sender, EventArgs e) 
		{
//			bool success = ((FormAuthenticationBase)Global.Authentication).SignIn(userNameTextBox.Text, passwordTextBox.Text, rememberCheckBox.Checked);
//			if (success == false) 
//			{
//				messageLabel.Visible = true;
//				messageLabel.Text = "The Username/Password was incorrect.";
//				messageLabel.ForeColor = Color.Red;
//				return;
//			} 
//			
//			// redirect to the correct url
//			Response.Redirect(FormsAuthentication.GetRedirectUrl(userNameTextBox.Text, rememberCheckBox.Checked));
		}

		private void logoutButton_Click (object sender, EventArgs e) 
		{
//			((FormAuthenticationBase)Global.Authentication).SignOut();
//
//			// redirect to the correct url
//			Response.Redirect(Global.GetPortalUrl(String.Empty).ToString());
		}
	}
}