#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web.UI;

// OmniPortal Classes
using ManagedFusion.Display;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	[ToolboxData("<{0}:AdRotator runat=server></{0}:AdRotator>")]
	public class AdRotator : PagesWebControl
	{
		protected override void LoadControl()
		{
			AdRotator_Ascx ad = (AdRotator_Ascx)this.GetControl();

			// set width and height
			ad.Width = Convert.ToInt32(this.Width.Value);
			ad.Height = Convert.ToInt32(this.Height.Value);

			this.Controls.Add(ad);
		}

		protected override string ModuleName
		{
			get { return "Pages"; }
		}

		protected override string ControlLocation
		{
			get { return "Controls/AdRotator.ascx"; }
		}
	}
}