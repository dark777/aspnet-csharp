#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Display;
using OmniPortal.Components.Common;
using OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls;

namespace OmniPortal.Components.Themes.Default.Skin.Pages.Desktop
{
	/// <summary>
	/// Summary description for Desktop.
	/// </summary>
	public class Default : UserControl
	{
		protected Label pageTitleLabel;
		protected PlaceHolder contentPlaceHolder;
		protected OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls.AdRotator topAdRotator;
		protected LeftPanel leftPanel;
		protected SiteLocation siteLocation;
		protected PlaceHolder rightPlaceHolder;

		private void Page_Load (object sender, EventArgs e) 
		{
			// set page title
			pageTitleLabel.Text = SectionInfo.Current.Title;
		}

		protected override void OnInit(EventArgs e)
		{
			Initialize();
			base.OnInit (e);
		}

		private void Initialize () 
		{
			this.Load += new EventHandler(Page_Load);

			// set content mdoule
			contentPlaceHolder.Controls.Add(Global.ExecutingModule.GetContentHolder(Position.Center));

			// set portlet holder
			rightPlaceHolder.Controls.Add(Global.ExecutingModule.GetContentHolder(Position.Right));
		}
	}
}