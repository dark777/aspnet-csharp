#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Text;
using System.Resources;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;
using ManagedFusion.Types;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	public enum SiteMenuDirection 
	{
		Vertical,
		Horizontal
	}

	/// <summary>
	///	Summary description for SectionListItem.
	/// </summary>
	public class SiteMenu_Ascx : SkinnedUserControl
	{
		protected Repeater sectionRepeater;
		protected HyperLink homeHyperLink;
		protected PlaceHolder _menuItems;
		
		#region Properties

		public int TopOffset = 130;
		public int LeftOffset = 165;
		public int PopMenuWidth = 165;
		public int MenuWidth = 100;			// only used for Direction = Horizontal
		public int MenuHeight = 20;			// only used for Direction = Vertical
		public int Seperator = 10;
		public int PopMenuHeight = 20;
		public int PopMenuSeperator = 5;
		public int ZIndexStart = 5;
		public SiteMenuDirection Direction = SiteMenuDirection.Vertical;

		#endregion

		private void Page_Load (object sender, EventArgs e) 
		{
			if (Page.IsPostBack == false) 
			{
				// bind data in page
				this.DataBind();
			}
		}

		protected override void OnInit(EventArgs e)
		{
			this.Load += new EventHandler(Page_Load);
			this.sectionRepeater.ItemDataBound += new RepeaterItemEventHandler(sectionRepeater_ItemDataBound);

			this._menuItems = new PlaceHolder();
			this.Controls.Add(_menuItems);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			SectionCollection collection = SiteInformation.ConnectedSection.Children;

			// get children of this section
			this.sectionRepeater.DataSource = collection;

			base.DataBind ();
		}

		/// <summary>
		/// Overridden to render client script from resource file.
		/// </summary>
		protected override void OnPreRender(EventArgs e)
		{
			// get client ecma script
			ResourceManager manager = new ResourceManager("OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls.SiteMenu.ascx", typeof(SiteMenu_Ascx).Assembly);
			string script = manager.GetString("MenuScriptBlock");
			Page.RegisterClientScriptBlock(Global.Properties.SoftwareName + "_MenuScriptBlock", script);
		}

		#region Menu Render

		private void sectionRepeater_ItemDataBound (object sender, RepeaterItemEventArgs e) 
		{
			// checks to see if the item to be bound is item or alternating item
			if (e.Item.ItemType == ListItemType.Item  || e.Item.ItemType == ListItemType.AlternatingItem)
			{
				SectionInfo info = (SectionInfo)e.Item.DataItem;

				// checks that the title isn't Home and that the section is visible
				if (info.Visible) 
				{
					this.CreateMenuItem(new MenuItemInfo(
						info, 
						this.SetMenuItemLeft(e.Item.ItemIndex), 
						this.SetMenuItemTop(e.Item.ItemIndex), 
						this.ZIndexStart, 
						String.Empty
						));
				}
			}
		}

		private int SetMenuItemLeft (int menuItemIndex)  
		{
			int i = -1;
			switch (this.Direction) 
			{
				case SiteMenuDirection.Vertical :
					i = this.LeftOffset;
					break;
				case SiteMenuDirection.Horizontal :
					i = this.LeftOffset + ((this.MenuWidth + this.Seperator)*(menuItemIndex +1));
					break;
			}
			return i;
		}

		private int SetMenuItemTop (int menuItemIndex) 
		{
			int i = -1;
			switch (this.Direction) 
			{
				case SiteMenuDirection.Vertical :
					i = this.TopOffset + ((this.MenuHeight + this.Seperator)*(menuItemIndex +1));
					break;
				case SiteMenuDirection.Horizontal :
					i = this.TopOffset;
					break;
			}
			return i;
		}

		protected string GetMouseOut(object o) 
		{
			SectionInfo info = (SectionInfo)o;

			// check to see if any menus were created
			if (info.Children.Count > 0)
				return "LinkOut(\"\");";

			return String.Empty;
		}

		protected string GetMouseOver(object o) 
		{
			SectionInfo info = (SectionInfo)o;

			// check to see if any menus were created
			if (info.Children.Count > 0)
				return String.Concat("LinkOver(\"_menu", info.ID, "\");");

			return String.Empty;
		}

		private void AddToMenuList (string s) 
		{
			Page.RegisterArrayDeclaration("layersList", String.Concat("\"", s, "\""));
		}

		private struct MenuItemInfo 
		{
			public MenuItemInfo (SectionInfo info , int left, int top, int zIndex, string parent) 
			{
				Section = info;
				Left = left;
				Top = top;
				ZIndex = zIndex;
				Parent = parent;
			}

			public SectionInfo Section;
			public string Parent;
			public int Left;
			public int Top;
			public int ZIndex;
		}

		private bool CreateMenuItem (MenuItemInfo info) 
		{
			SectionCollection children;

			// get children sections
			try { children = info.Section.Children; } 
			catch {	return false; }

			// check to see if there are any children
			if (children.Count == 0)
				return false;

			StringBuilder menuItem = new StringBuilder();
			string id = String.Concat(info.Parent, "_menu", info.Section.ID);

			this.AddToMenuList(id);

			string menuTemplate = String.Concat(Environment.NewLine, "<!-- ", id, " -->", Environment.NewLine, 
				"<div id=\"{0}\" style=\"position: absolute; left: {1}px; top: {2}px; width: {3}px; visibility: hidden; z-index: {4};\">", Environment.NewLine,
				"<table class=\"PopMenu\" width=\"{3}\" cellspacing=\"2\" cellpadding=\"0\" border=\"0\" onmouseover=\"TableOver('{0}');\" onmouseout=\"TableOut();\">", Environment.NewLine);

			// create begining tag
			menuItem.AppendFormat(menuTemplate, id, info.Left, info.Top, this.PopMenuWidth, info.ZIndex);

			bool hasChildren = false;
			string mouseover = String.Empty, mouseout = String.Empty;
			int childCount = 0;

			// create items
			foreach (SectionInfo section in children) 
			{
				if (section.Visible) 
				{
					// check to see if there are any children and create the children if there are
					hasChildren = this.CreateMenuItem(new MenuItemInfo(
						section, 
						info.Left + this.PopMenuWidth, 
						info.Top + ((this.PopMenuHeight + this.PopMenuSeperator)*childCount) +this.PopMenuSeperator, 
						info.ZIndex +1, 
						id
						));

					// reset mouse over and mouse out
					mouseover = String.Empty;
					mouseout = String.Empty;

					menuTemplate = String.Concat("\t<tr><td class=\"PopMenuItem\" onmouseover=\"this.className = 'PopMenuItemHover';document.getElementById('_link",section.ID,"').className = 'PopMenuItemLinkHover';{0}\" onmouseout=\"this.className = 'PopMenuItem';document.getElementById('_link",section.ID,"').className = 'PopMenuItemLink';{1}\"><a class=\"PopMenuItemLink\" id=\"_link",section.ID,"\" href=\"{2}\">{3}</a></td></tr>" + Environment.NewLine);

					// check to see if any menus were created
					if (hasChildren == true) 
					{
						mouseover = String.Concat("LinkOver('", id, "_menu", section.ID, "');");
						mouseout = String.Concat("LinkOut('", id, "');");
					}

					// create menu item
					menuItem.AppendFormat(menuTemplate,
						mouseover,
						mouseout,
						Global.Path.GetPortalUrl(section.Path),
						section.Title
						);

					// advance the child count once
					childCount++;
				}
			}

			// add end tag
			menuItem.Append(String.Concat("</table>", Environment.NewLine, "</div>", Environment.NewLine));

			// add menuItem to menu
			this._menuItems.Controls.Add(new LiteralControl(menuItem.ToString()));

			// return success
			return true;
		}

		#endregion
	}
}