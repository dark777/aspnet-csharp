#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.ComponentModel;

// OmniPortal Classes
using ManagedFusion.Display;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	[ToolboxData("<{0}:SiteMenu runat=server></{0}:SiteMenu>")]
	public class SiteMenu : PagesWebControl
	{
		#region Properties

		public int TopOffset = 130;		// this value is relative to the menuItem
		public int LeftOffset = 165;	// this value is relative to the menuItem
		public int PopMenuWidth = 165;
		public int Seperator = 10;
		public int PopMenuHeight = 20;
		public int ZIndexStart = 5;
		public SiteMenuDirection Direction = SiteMenuDirection.Vertical;

		#endregion

		protected override void LoadControl()
		{
			SiteMenu_Ascx menu = (SiteMenu_Ascx)this.GetControl();

			// set width and height
			menu.TopOffset = this.TopOffset;
			menu.LeftOffset = this.LeftOffset;
			menu.PopMenuWidth = this.PopMenuWidth;
			menu.PopMenuHeight = this.PopMenuHeight;
			menu.Seperator = this.Seperator;
			menu.ZIndexStart = this.ZIndexStart;
			menu.Direction = this.Direction;

			this.Controls.Add(menu);
		}

		protected override string ModuleName
		{
			get { return "Pages"; }
		}

		protected override string ControlLocation
		{
			get { return "Controls/SiteMenu.ascx"; }
		}
	}
}