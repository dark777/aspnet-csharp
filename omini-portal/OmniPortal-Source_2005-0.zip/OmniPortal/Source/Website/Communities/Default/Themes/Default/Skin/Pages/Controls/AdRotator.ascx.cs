#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;
using ManagedFusion.Types;
using OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Common;

namespace OmniPortal.Components.Communities.Default.Themes.Default.Skin.Pages.Controls
{
	public class AdRotator_Ascx : SkinnedUserControl
	{
		protected Common.AdRotator pageAdRotator;

		public int Width 
		{
			get 
			{ 
				if(ViewState["Width"] == null)
					Width = 468;
				return (int)ViewState["Width"];
			}
			set { ViewState["Width"] = value; }
		}

		public int Height 
		{
			get 
			{ 
				if(ViewState["Height"] == null)
					Height = 60;
				return (int)ViewState["Height"]; 
			}
			set { ViewState["Height"] = value; }
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// get advertisement code from section properties
//			pageAdRotator.AdvertisementCode = CommunityInfo.Current.ConnectedSection.ModuleData
//				[String.Format("{0}x{1} Ad", this.Width, this.Height)];
		}
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}
	}
}