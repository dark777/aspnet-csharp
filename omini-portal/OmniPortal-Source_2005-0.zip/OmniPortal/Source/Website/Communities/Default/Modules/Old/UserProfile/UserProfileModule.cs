#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Display.Modules;

namespace OmniPortal.Components.Modules.UserProfile
{
	/// <summary>
	/// Summary description for UserProfileModule.
	/// </summary>
	[Module("Users Profile Module", 
			"Lets users setup accounts on the website and administrate their profile.", 
			"{F0FAEC91-A94E-4acc-89A4-D7AD14D3D1EC}")]
	public class UserProfileModule : ModuleBase
	{
		public UserProfileModule() : base("UserProfile") { }

		protected override void OnPopulateHolders(PopulateHoldersEventArgs e)
		{
			// load current control according to the page address
			try 
			{
				if (Location == "Register.aspx" || Location == "Update.aspx") 
				{
					e.Center.Controls.Add(this.GetControl(this.Config["Profile.aspx"]));
				
					// change format of URL on server side
					this.RewritePath("Profile.aspx", 
						String.Concat(Location.Replace(".aspx", String.Empty), "=true")
						);
				}
			} 
			catch (FormatException) { /* Do Nothing, Let Module Base do the rest */ }
		}
	}
}