#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Components.Modules.UserProfile.Data;

namespace OmniPortal.Components.Modules.UserProfile.Desktop
{
	/// <summary>
	///		Summary description for _Default.
	/// </summary>
	public class UserDefault : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.DataList requiredInfo;
		protected System.Web.UI.WebControls.DataList contactInfo;
		protected System.Web.UI.WebControls.DataList optionalInfo;
		protected System.Web.UI.WebControls.DataList emailInfo;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// check to see if the user has been authenticated
			if (Global.PortalContext.User.Identity.IsAuthenticated) 
			{
				// set edit hyperlink
				HyperLink link = new HyperLink();
				link.NavigateUrl = Global.GetRelativeUrl("Update.aspx");
				link.Text = "Edit Profile";

				// add control to top of page
				this.Controls.AddAt(0, link);

				// databind fields
				this.DataBind();
			}
			else
				Response.Redirect(Global.GetRelativeUrl("Register.aspx"));
		}
		
		public override void DataBind()
		{
			DataTable table = new DataTable();
			table.Columns.Add("Name", typeof(string));
			table.Columns.Add("Value", typeof(string));

			// data list
			DataTable requiredTable = table.Clone();
			DataTable contactTable = table.Clone();
			DataTable optionalTable = table.Clone();
			DataTable emailTable = table.Clone();

			// get user data
			DataRow userRow = UserUtility.GetUser(Global.PortalContext.User.Identity.Name);

			// required information
			requiredTable.Rows.Add(new object[] { "User Name", (string)userRow["user_name"] });
			requiredTable.Rows.Add(new object[] { "Name", String.Format("{0} {1}", userRow["user_fname"], userRow["user_lname"]) });
			requiredTable.Rows.Add(new object[] { "E-Mail", (string)userRow["user_email"] });
			requiredTable.Rows.Add(new object[] { "Time Zone", ((int)userRow["user_timezone"]).ToString() });
			requiredInfo.DataSource = requiredTable;
			this.Controls.Add(requiredInfo);

			// contact information
			contactTable.Rows.Add(new object[] { "MSN", CheckForDBNull(userRow["user_msn"]) });
			contactTable.Rows.Add(new object[] { "Yahoo", CheckForDBNull(userRow["user_yahoo"]) });
			contactTable.Rows.Add(new object[] { "AIM", CheckForDBNull(userRow["user_aim"]) });
			contactTable.Rows.Add(new object[] { "ICQ", CheckForDBNull(userRow["user_icq"]) });
			contactTable.Rows.Add(new object[] { "Website", CheckForDBNull(userRow["user_website"]) });
			contactTable.Rows.Add(new object[] { "Public E-Mail", CheckForDBNull(userRow["user_publicEmail"]) });
			contactInfo.DataSource = contactTable;
			this.Controls.Add(contactInfo);

			// optional information
			optionalTable.Rows.Add(new object[] { "Occupation", CheckForDBNull(userRow["user_occupation"]) });
			optionalTable.Rows.Add(new object[] { "Location", CheckForDBNull(userRow["user_location"]) });
			optionalTable.Rows.Add(new object[] { "Interests", CheckForDBNull(userRow["user_interests"]) });
			optionalInfo.DataSource = optionalTable;
			this.Controls.Add(optionalInfo);

			// email options
			emailTable.Rows.Add(new object[] { "Receive Newsletters", ((bool)userRow["user_newsletter"]).ToString() });
			emailTable.Rows.Add(new object[] { "Receive Notifications", ((bool)userRow["user_notification"]).ToString() });
			emailInfo.DataSource = emailTable;
			this.Controls.Add(emailInfo);

			base.DataBind ();
		}

		private string CheckForDBNull (object o) 
		{
			if (o == Convert.DBNull)
				return String.Empty;
			
			return o.ToString();
		}

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}
	}
}