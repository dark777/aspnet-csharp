#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Types;
using OmniPortal.Display.Modules;

namespace OmniPortal.Components.Modules.UsersAdministration.Desktop
{
	/// <summary>
	/// Summary description for AdminDefault.
	/// </summary>
	[Owner("nberardi", "$Revision: 1.4 $")]
	public class AdminDefault : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater moduleRepeater;
		protected System.Web.UI.WebControls.Label titleLabel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// set header if there is no theme
			if (SectionInformation.NoTheme)
				titleLabel.Text = SectionInformation.Title;
			else
				titleLabel.Visible = false;

			// get a collection of admin modules
			string[] collection = this.ScourAssembly();

			// sets module collection as datasource
			moduleRepeater.DataSource = collection;

			// databind page
			Page.DataBind();
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.moduleRepeater.ItemDataBound += new System.Web.UI.WebControls.RepeaterItemEventHandler(this.moduleRepeater_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		private string[] ScourAssembly () 
		{
			ArrayList al = new ArrayList();

			// searches each array for AdminModuleAttribute
			foreach (string assembly in Global.GetUniqueAssemblies()) 
			{
				Assembly a = Assembly.Load(assembly);
				ArrayList attribs = new ArrayList();

				// checks each type to see if AdminModuleAttribute is in it
				foreach (Type t in a.GetTypes()) 
				{
					// checks to see if it is portal admin stuff
					if (t.FullName.StartsWith("OmniPortal.Components.Modules.PortalAdministration.Desktop") == false)
					{
						// gets all attributes of AdminModuleAttribute
						object[] o = t.GetCustomAttributes(typeof(ModuleAdminAttribute), false);

						// if attributes are found add to array list
						if (o.Length > 0) 
							attribs.Add(String.Format("{0},{1}", t.FullName, assembly));
					}
				}

#if DEBUG
				Context.Trace.Write("AdminDefault", String.Format("Found {0} in {1} of {2} Types", attribs.Count, assembly, a.GetTypes().Length));
#endif
				al.AddRange(attribs.ToArray());
			}

			// returns all objects of AdminModuleAttribute that were found in all arrays
			return (string[])al.ToArray(typeof(string));
		}

		private void moduleRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			// checks to see if the item to be bound is item or alternating item
			if (e.Item.ItemType == ListItemType.Item  || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				string typeName = (string)e.Item.DataItem;

				// get attribute
				ModuleAdminAttribute attr = (ModuleAdminAttribute)Type.GetType(typeName).GetCustomAttributes(typeof(ModuleAdminAttribute), false)[0];
#if DEBUG
				Context.Trace.Write("Module Bound", attr.Title);
#endif
				// create controls
				HyperLink titleLink = (HyperLink)e.Item.FindControl("titleLink");
				Label descriptionLabel = (Label)e.Item.FindControl("descriptionLabel");

				// set controls data
				titleLink.Text = attr.Title;
				titleLink.NavigateUrl = Global.GetRelativeUrl("ModuleAdmin.aspx?type=" + typeName);
				descriptionLabel.Text = attr.Description;
			}
		}
	}
}