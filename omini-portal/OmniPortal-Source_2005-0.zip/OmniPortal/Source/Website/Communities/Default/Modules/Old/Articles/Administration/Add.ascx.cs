#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Authentication;
using OmniPortal.Display;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Modules.Articles.Data;

namespace OmniPortal.Components.Modules.Articles.Desktop
{
	[ModuleAdmin("Add.aspx", "Add Article", "This module is used for the adding of articles to a section.")]
	public class Add : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.TextBox titleTextBox;
		protected System.Web.UI.WebControls.Button addButton;
		protected System.Web.UI.WebControls.HyperLink addType;
		protected FreeTextBoxControls.FreeTextBox commentsTextBox;
		protected FreeTextBoxControls.FreeTextBox contentTextBox;
		protected System.Web.UI.WebControls.DropDownList typeList;
		
		private void Page_Load(object sender, EventArgs e)
		{
			if (Page.IsPostBack == false) 
			{
				if (Global.PortalContext.User.HasPermissions(Permissions.Edit) && Request.QueryString["id"] != null) 
				{
					DataRow article = ArticleUtility.GetArticleItem(Convert.ToInt32(Request.QueryString["id"]));
				}

				// set type list values
				this.typeList.DataSource = ArticleUtility.GetArticleTypes();
				this.typeList.DataTextField = "type_name";
				this.typeList.DataValueField = "type_id";
				this.DataBind();
			}
		}

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// if the user doesn't have add permissions redirect back to default.aspx
			if (Global.PortalContext.User.HasPermissions(Permissions.Add) == false)
				Response.Redirect(Global.GetRelativePath(String.Empty));
			
			// disables add type if not an administrator
			addType.Enabled = Global.PortalContext.User.IsUserType(UserType.Administrator);

			this.Load += new EventHandler(Page_Load);
			this.addButton.Click += new System.EventHandler(this.addButton_Click);
		
			base.OnInit (e);
		}

		private void InitializeComponent()
		{

		}

		private void addButton_Click(object sender, System.EventArgs e)
		{
			ArticleUtility.AddArticle(
				titleTextBox.Text,
				Convert.ToInt32(typeList.SelectedItem.Value),
				commentsTextBox.Text,
				contentTextBox.Text,
				Global.PortalContext.User.Identity.Name
				);
		}
	}
}