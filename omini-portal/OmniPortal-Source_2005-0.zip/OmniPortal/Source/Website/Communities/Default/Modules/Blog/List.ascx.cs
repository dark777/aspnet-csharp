using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;

// OmniPortal Classes
using OmniPortal.Components.Communities.Default.Modules.Blog.Data;

namespace OmniPortal.Components.Communities.Default.Modules.Blog
{
	/// <summary>
	///		Summary description for List.
	/// </summary>
	public class List : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater BlogList;
		protected bool IsPoster = false;

		private void Page_Load(object sender, System.EventArgs e)
		{
			BlogDatabaseProvider dbprovider = CommunityInfo.Current.Config.GetProviderDirectly(typeof(BlogDatabaseProvider),  CommunityInfo.Current.Config["DatabaseAlias"]) as BlogDatabaseProvider;
			BlogItem[] blogs = dbprovider.GetBlogs(this.Context);

			IsPoster = this.IsInTasks("Poster");

			BlogList.DataSource = blogs;
			BlogList.DataBind();
		}

		protected string GetPostUrl (string id) 
		{
			return ManagedFusion.Global.Path.GetPortalUrl(String.Format("Archive/{0}.aspx", id)).ToString();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
