#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Display.Modules;

namespace OmniPortal.Components.Modules.Contacts
{
	/// <summary>
	/// Summary description for ContactModule.
	/// </summary>
	[Module("Contact Module", 
			"This module is used for the display of contacts.", 
			"{A73C4EC0-FF27-468c-8FAD-27A5949253EC}")]
	public class ContactModule : ModuleBase
	{
		public ContactModule() : base("Contacts") {}

		protected override void OnPopulateHolders(PopulateHoldersEventArgs e)
		{
			// load current control according to the page address
			try 
			{
				Guid contactID = new Guid(Location.Replace(".aspx", String.Empty));
				e.Center.Controls.Add(this.GetControl(this.Config["Contact.aspx"]));
				
				// change format of URL on server side
				this.RewritePath("Contact.aspx", "id=" + contactID.ToString());
			} 
			catch (FormatException) { /* Do Nothing, Let Module Base do the rest */ }
		}
	}
}