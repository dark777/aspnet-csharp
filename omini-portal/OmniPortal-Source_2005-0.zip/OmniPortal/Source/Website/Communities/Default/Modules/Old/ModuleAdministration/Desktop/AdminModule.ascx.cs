#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Data;
using OmniPortal.Display;
using OmniPortal.Types;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.UsersAdministration.Desktop
{
	/// <summary>
	///	Summary description for ModuleAdmin.
	/// </summary>
	public class ModuleAdmin : SkinnedUserControl
	{
		protected DropDownList sectionList;

		private const string NullItemEntry = "--nothing--";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
				this.DataBind();
		}

		protected string PageLocation 
		{
			get { return (string)ViewState["PageLocation"]; }
			set { ViewState["PageLocation"] = value; }
		}

		protected string PageType 
		{ 
			get { return (string)ViewState["PageType"]; }
			set { ViewState["PageType"] = value; }
		}

		protected Guid PageTypeID 
		{
			get { return (Guid)ViewState["PageTypeID"]; }
			set { ViewState["PageTypeID"] = value; } 
		}

		protected override void OnInit(EventArgs e)
		{
			if (Request.QueryString["type"] != null)
				this.PageType = Request.QueryString["type"];

			// get the type
			Type pageType = Type.GetType(this.PageType);

			// checks each module for the correct namespace
			foreach (OmniPortalDataSet.PageTypesRow row in Global.Database.PageTypes) 
			{
				// checks to see if the current namespace starts with the page types namespace
				if (pageType.Namespace.StartsWith(this.GetNamespace(row.object_namespace, row.object_assembly)) == true)
				{
					this.PageTypeID = row.pageType_id;
					break;
				}
			}

			this.Load += new EventHandler(Page_Load);
			this.sectionList.SelectedIndexChanged += new EventHandler(sectionList_SelectedIndexChanged);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			this.sectionList.DataSource = AdminUtility.SectionUtility.GetSectionsRowPageType(this.PageTypeID);
			this.sectionList.DataTextField = "section_name";
			this.sectionList.DataValueField = "section_ID";

			// data bind section list
			this.sectionList.DataBind();

			// add null entry to the top
			this.sectionList.Items.Insert(0, new ListItem("-- Select Page to Edit --", NullItemEntry));
		}

		private string GetNamespace (string type, string assembly) 
		{
			return Type.GetType(String.Format("{0},{1}", type, assembly)).Namespace;
		}

		private void sectionList_SelectedIndexChanged (object sender, EventArgs e) 
		{
			if (sectionList.SelectedValue != NullItemEntry) 
			{
				ModuleAdminAttribute attr = (ModuleAdminAttribute)Type.GetType(this.PageType).GetCustomAttributes(typeof(ModuleAdminAttribute), false)[0];

				// creating the page location
				string location = String.Format("{0}{1}", 
					SectionInfo.GetSectionInfo(Convert.ToInt32(sectionList.SelectedValue)).Path,
					attr.Location
					);
			
				// set page location
				this.PageLocation = Global.GetRelativeUrl(location);
			}
		}
	}
}