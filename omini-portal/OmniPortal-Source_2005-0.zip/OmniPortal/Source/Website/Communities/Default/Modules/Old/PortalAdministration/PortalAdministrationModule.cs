#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;

// OmniPortal Classes
using OmniPortal;
using ManagedFusion.Display.Modules;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Modules.PortalAdministration
{
	[Module("Portal Administration Module", 
			"Used to administrate many of the functions that are associated with setting up OmniPortal", 
			"{D33A16A6-3B45-4a87-B19C-F41D8E155746}")]
	public class PortalAdministrationModule : ModuleBase
	{
		public PortalAdministrationModule() : base("PortalAdministration") { }
	}
}