#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Components.Modules.Downloads.Data;

namespace OmniPortal.Components.Modules.Downloads.Desktop
{
	public class DownloadDefault : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater downloadRepeater;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Page.IsPostBack == false) 
			{
				downloadRepeater.DataSource = Data.DownloadUtility.GetDownloads(this.SectionInformation.ID);
				downloadRepeater.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.downloadRepeater.ItemDataBound += new System.Web.UI.WebControls.RepeaterItemEventHandler(this.downloadRepeater_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void downloadRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				// get data
				DataRowView row = (DataRowView)e.Item.DataItem;

				// get objects
				HyperLink link = (HyperLink)e.Item.FindControl("downloadLink");
				Label description = (Label)e.Item.FindControl("downloadDescription");

				// set objects
				link.Text = (string)row["link_name"];
				link.NavigateUrl = Global.GetRelativeUrl(String.Concat(row["link_id"], "-", row["download_fileName"]));

				description.Text = (string)row["link_description"];
			}
		}
	}
}