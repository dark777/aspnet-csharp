#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Components.Modules.Articles.Data;

namespace OmniPortal.Components.Modules.Articles.Desktop
{
	/// <summary>
	///		Summary description for News.
	/// </summary>
	public class Article : SkinnedUserControl
	{
		protected DataRow ArticleData;
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
//			// add edit button for users with access to edit
//			if (Global.User.HasEditPermissions)
//			{
//				HyperLink editLink = new HyperLink();
//				editLink.Text = "Edit This Page's Content";
//				editLink.NavigateUrl = Global.GetRelativeUrl(String.Concat("Edit.aspx?id=", Request.QueryString["source"]));
//
//				// add link to page
//				this.Controls.AddAt(0, editLink);
//			}

			// get news item
			ArticleData = ArticleUtility.GetArticleItem(Convert.ToInt32(Request.QueryString["source"]));
		
			base.OnInit (e);
		}
	}
}