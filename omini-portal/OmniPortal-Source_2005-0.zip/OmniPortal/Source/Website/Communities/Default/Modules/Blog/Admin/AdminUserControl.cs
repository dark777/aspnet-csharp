using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Display;

// OmniPortal Classes
using OmniPortal.Components.Users;
using OmniPortal.Components.Communities.Default.Modules.Blog.Data;

namespace OmniPortal.Components.Communities.Default.Modules.Blog.Admin
{
	public class AdminUserControl : SkinnedUserControl
	{
		private BlogDatabaseProvider _dbprovider;

		protected override void OnInit(EventArgs e)
		{
			// set db provider for the blog
			_dbprovider = CommunityInfo.Current.Config.GetProviderDirectly(typeof(BlogDatabaseProvider),  CommunityInfo.Current.Config["DatabaseAlias"]) as BlogDatabaseProvider;

			// add admin style sheet
			Global.PageBuilder.StyleSheets.Add(this.Module.GetUrlPath("admin/admin.css").ToString());

			base.OnInit (e);
		}

		public BlogDatabaseProvider DatabaseProvider 
		{
			get { return this._dbprovider; }
		}
	}
}