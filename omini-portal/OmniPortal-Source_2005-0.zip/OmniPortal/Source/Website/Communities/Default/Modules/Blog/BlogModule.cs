using System;
using System.Data;
using System.Text.RegularExpressions;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Display.Modules;

// OmniPortal Classes
using OmniPortal.Components.Communities.Default.Modules.Blog.Data;

// Atom Classes
using Atom.Core;

namespace OmniPortal.Components.Communities.Default.Modules.Blog
{
	[Module("Blog Module",
		 "This module is a web-log (blog), which is used to post a log about what you find informing.",
		 "{A7181415-44BC-48aa-9519-2AFC69DCB92A}",
		 true,
		 "Blog",
		 TraversablePath = true)]
	public class BlogModule : ModuleBase
	{
		#region OnLoadSyndication

		protected override void OnLoadSyndication(LoadSyndicationEventArgs e)
		{
			BlogDatabaseProvider dbprovider = CommunityInfo.Current.Config.GetProviderDirectly(typeof(BlogDatabaseProvider),  CommunityInfo.Current.Config["DatabaseAlias"]) as BlogDatabaseProvider;
			BlogItem[] blogs = dbprovider.GetBlogs(this.Context);
			DateTime modified = DateTime.MinValue;

			// populate content for syndication
			foreach(BlogItem blog in blogs) 
			{
				// check to see if this blog is suppose to be syndicated 
				// or has even been published yet
				if (blog.Syndicate == false || blog.Published == false)
					continue;

				// check to see if the blog date modified is more recent than
				// the previous modified value
				if (blog.Modified > modified)
					modified = blog.Modified;

				// get url id for the current entry
				Uri permalink = Global.Path.GetPortalUrl(String.Format("/archive/{0}.aspx", blog.ID));

				// add the item
				AtomEntry entry = new AtomEntry();

				// set the author
				entry.Author = new AtomPersonConstruct("author", blog.Poster.FullName);
				
				// set the title
				entry.Title = new AtomContentConstruct("title", blog.Title);
				
				// if there is a url for the title
				if (blog.TitleUrl != null)
					try { entry.Links.Add(new AtomLink(blog.TitleUrl, Relationship.Alternate, MediaType.TextHtml, blog.Title)); } 
					catch { }
				
				// if there is a source url
				if (blog.SourceUrl != null)
					try { entry.Links.Add(new AtomLink(blog.SourceUrl, Relationship.Alternate, MediaType.TextHtml, blog.Source)); } 
					catch { }

				// set the permalink
				entry.Id = permalink;

				// set the date time stamps for this entry
				entry.Created = new AtomDateConstruct("created", blog.Created);
				entry.Issued = new AtomDateConstruct("issued", blog.Issued);
				entry.Modified = new AtomDateConstruct("modified", blog.Modified);

				// set the body contents
				entry.Contents.Add(new AtomContent(blog.Body, MediaType.TextHtml, Mode.Escaped));

				// add entry to the feed
				e.Feed.Entries.Add(entry);
			}

			// set the time the feed was last modified
			e.Feed.Modified = new AtomDateConstruct("modified", modified);

			base.OnLoadSyndication (e);
		}

		#endregion

		protected override void OnLoad(LoadModuleEventArgs e)
		{
			// add the blog style sheet to the page.
			Global.PageBuilder.StyleSheets.Add(this.GetUrlPath("blog.css").ToString());

			// check to see if the current has a role with the task of Poster
			if (this.IsInTasks("Poster")) 
			{
				// add admin section to the portlets.
				e.Right.Controls.Add(this.CreatePortlet(2, "Blog Admin", this.GetControl("Portlets/Admin.ascx")));
			}

			// add calendar to the portlets
			e.Right.Controls.Add(this.CreatePortlet(1, "Archive Calendar", this.GetControl("Portlets/Calendar.ascx")));

			base.OnLoad (e);
		}
	}
}
