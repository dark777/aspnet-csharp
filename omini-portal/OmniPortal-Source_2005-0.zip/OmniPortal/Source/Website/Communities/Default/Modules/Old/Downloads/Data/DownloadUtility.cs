#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Data;

namespace OmniPortal.Components.Modules.Downloads.Data
{
	public sealed class DownloadUtility
	{
//		public static DataTable GetDownloads (int sectionID) 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select	*
//					from	Module_Links
//					where	section_id = @section_id
//				");
//
//				adapter.SelectCommand.Parameters.Add(f.CreateParameter("@section_id", DbType.Int32, sectionID));
//
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0];
//		}
//
//		public static string GetUrlByID (int id) 
//		{
//			DataRow row = GetDownloadByID(id);
//
//			if (row != null)
//				return (string)row["link_url"];
//			else
//				return String.Empty;
//		}
//
//		public static DataRow GetDownloadByID (int id) 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select	*
//					from	Module_Links
//					where	link_id = @link_id
//				");
//
//				adapter.SelectCommand.Parameters.Add(f.CreateParameter("@link_id", DbType.Int32, id));
//
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			if (ds.Tables[0].Rows.Count == 0)
//				return null;
//
//			return ds.Tables[0].Rows[0];
//		}
//		public static void EditDownload (
//			int id,
//			int sectionID,
//			string name,
//			string description,
//			string url,
//			string fileName,
//			int size
//			) 
//		{
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbCommand command;
//				IDbConnection connection = f.CreateConnection();
//
//				#region Insert
//				if (id == -1) 
//				{
//					command = f.CreateCommand(@"
//					insert into Module_Links ( 
//						section_id, 
//						link_name, 
//						link_description, 
//						link_url, 
//						download_fileName, 
//						download_size 
//					) values (
//						@section_id,
//						@link_name,
//						@link_description,
//						@link_url,
//						@download_fileName,
//						@download_size
//					)");
//
//					command.Parameters.Add(f.CreateParameter("@section_id", DbType.Int32, sectionID));
//					command.Parameters.Add(f.CreateParameter("@link_name", DbType.String, name));
//					command.Parameters.Add(f.CreateParameter("@link_description", DbType.String, description));
//					command.Parameters.Add(f.CreateParameter("@link_url", DbType.String, url));
//					command.Parameters.Add(f.CreateParameter("@download_fileName", DbType.String, fileName));
//					command.Parameters.Add(f.CreateParameter("@download_size", DbType.Int32, size));
//				} 
//				#endregion
//				else 
//				#region Update
//				{
//					command = f.CreateCommand(@"
//						update Module_Links
//						set
//							section_id			= @section_id,
//							link_name			= @link_name,
//							link_description	= @link_description,
//							link_url			= @link_url,
//							link_touched		= @link_touched,
//							download_fileName	= @download_fileName,
//							download_size		= @download_size
//						where
//							link_id = @link_id
//					");
//
//					command.Parameters.Add(f.CreateParameter("@section_id", DbType.Int32, sectionID));
//					command.Parameters.Add(f.CreateParameter("@link_name", DbType.String, name));
//					command.Parameters.Add(f.CreateParameter("@link_description", DbType.String, description));
//					command.Parameters.Add(f.CreateParameter("@link_url", DbType.String, url));
//					command.Parameters.Add(f.CreateParameter("@link_touched", DbType.Date, DateTime.Now));
//					command.Parameters.Add(f.CreateParameter("@download_fileName", DbType.String, fileName));
//					command.Parameters.Add(f.CreateParameter("@download_size", DbType.Int32, size));
//					command.Parameters.Add(f.CreateParameter("@link_id", DbType.Int32, id));
//				}
//				#endregion
//
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
	}
}