#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;
using ManagedFusion.Display.Containers;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	///	Summary description for Containers.
	/// </summary>
	[	ModuleAdmin(
			"Container.aspx", 
			"Container Setup", 
			"This module is used to setup and add portlets to the containers.", 
			Options=Permissions.Modify
		)]
	public class Containers : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Label containerIDLabel;
		protected System.Web.UI.WebControls.Label touchedLabel;
		protected System.Web.UI.WebControls.Label timePastLabel;
		protected System.Web.UI.WebControls.TextBox nameTextbox;
		protected System.Web.UI.WebControls.DropDownList positionList;
		protected System.Web.UI.WebControls.ListBox availableList;
		protected System.Web.UI.WebControls.ListBox linkedList;
		protected System.Web.UI.WebControls.Button addButton;
		protected System.Web.UI.WebControls.Button removeButton;
		protected System.Web.UI.WebControls.Button sendButton;
		protected System.Web.UI.WebControls.DropDownList containersList;
		protected System.Web.UI.WebControls.RequiredFieldValidator nameValidator;
		protected System.Web.UI.WebControls.Button goButton;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
				this.DataBind();
		}
		
		#region Properties

		protected int ContainerID 
		{ 
			get { return (int)ViewState["ContainerID"]; }
			set { ViewState["ContainerID"] = value; }
		}

		protected ContainerInfo ContainerObject 
		{
			get { return ContainerInfo.Collection[this.ContainerID]; }
		}

		#endregion

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set values
			ContainerID = ContainerInfo.TempID;

			// setup page id when first entering
			if (Request.QueryString["id"] != null)
				ContainerID = Convert.ToInt32(Request.QueryString["id"]);

			this.goButton.Click += new EventHandler(goButton_Click);
			this.sendButton.Click += new EventHandler(sendButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			ContainerInfo container = this.ContainerObject;
			
			// set all available portlets
			this.availableList.DataSource = CommunityInfo.Collection;
			this.availableList.DataTextField = "Title";
			this.availableList.DataValueField = "ID";

			// set all linked portlets
			this.linkedList.DataSource = container.Portlets;
			this.linkedList.DataTextField = "Title";
			this.linkedList.DataValueField = "ID";

			// set the list of containers
			this.containersList.DataSource = ContainerInfo.Collection;
			this.containersList.DataTextField = "Name";
			this.containersList.DataValueField = "ID";

			// set positions list
			this.positionList.DataSource = Enum.GetNames(typeof(Position));

			base.DataBind ();

			// set data for container
			if (container != null) 
			{
				DateTime lastTouched = container.Touched;
				TimeSpan timePast = new TimeSpan((DateTime.Now - lastTouched).Ticks);

				this.containerIDLabel.Text = container.ID.ToString();
				this.touchedLabel.Text = lastTouched.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", timePast.Days, timePast.Hours, timePast.Minutes, timePast.Seconds);

				this.nameTextbox.Text = container.Title;

				this.positionList.DataBind();
				this.positionList.SelectedIndex = this.positionList.Items.IndexOf(this.positionList.Items.FindByText(container.Position.ToString()));

				this.EnableFormObjects(true);

				this.addButton.Click += new EventHandler(addButton_Click);
				this.removeButton.Click += new EventHandler(removeButton_Click);
			}			
			else 
			{
				this.EnableFormObjects(false);
			}
		}

		private void EnableFormObjects (bool enable) 
		{
			this.availableList.Enabled = enable;
			this.linkedList.Enabled = enable;
			this.addButton.Enabled = enable;
			this.removeButton.Enabled = enable;
		}

		#region Events

		private void goButton_Click(object sender, EventArgs e)
		{
			Response.Redirect(Global.Path.GetPortalUrl(
				String.Format("Container.aspx?id={0}", this.containersList.SelectedItem.Value)
				).ToString());
		}

		private void addButton_Click(object sender, EventArgs e)
		{
			this.ContainerObject.AddPortlet(
				PortletInfo.Collection[Convert.ToInt32(this.availableList.SelectedItem.Value)]
				);

			// data bind
			this.DataBind();
		}

		private void removeButton_Click(object sender, EventArgs e)
		{
			this.ContainerObject.RemovePortlet(
				PortletInfo.Collection[Convert.ToInt32(this.linkedList.SelectedItem.Value)]
				);

			// data bind
			this.DataBind();
		}

		private void sendButton_Click(object sender, EventArgs e)
		{
			ContainerInfo container = this.ContainerObject;

			if (container == null)
				container = ContainerInfo.CreateNew();

			// change the values
			container.Title = this.nameTextbox.Text;
			container.Position = (Position)Enum.Parse(typeof(Position), this.positionList.SelectedItem.Value, true);

			// commit the changes
			container.CommitChanges();
		}

		#endregion
	}
}