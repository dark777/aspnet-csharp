using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace OmniPortal.Components.Communities.Default.Modules.Blog.Portlets
{
	public class Calendar : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.Calendar BlogCalendar;

		#region Web Form Designer generated code
		
		protected override void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.BlogCalendar.DayRender += new System.Web.UI.WebControls.DayRenderEventHandler(this.BlogCalendar_DayRender);
			this.BlogCalendar.SelectionChanged += new System.EventHandler(this.BlogCalendar_SelectionChanged);

		}

		#endregion

		private void BlogCalendar_SelectionChanged(object sender, System.EventArgs e)
		{
			DateTime selectedDate = BlogCalendar.SelectedDate;

			Response.Redirect(
				ManagedFusion.Global.Path.GetPortalUrl(
					String.Format("{0}/{1}/{2}/Default.aspx",
						selectedDate.Year,
						selectedDate.Month,
						selectedDate.Day
						)
					).ToString()
				);
		}

		private void BlogCalendar_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
		{
			if (e.Day.Date > DateTime.Today) 
			{
				e.Cell.ForeColor = Color.FromArgb(0x99, 0x99, 0x99);
				e.Day.IsSelectable = false;
			}
		}
	}
}
