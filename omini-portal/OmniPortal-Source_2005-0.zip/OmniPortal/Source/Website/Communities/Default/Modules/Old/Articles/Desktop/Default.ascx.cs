#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Authentication;
using OmniPortal.Display;
using OmniPortal.Components.Modules.Articles.Data;

namespace OmniPortal.Components.Modules.Articles.Desktop
{
	public class ArticleDefault : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater articleRepeater;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// add "add" button for users with access to edit
			if (Global.PortalContext.User.HasPermissions(Permissions.Add))
			{
				HyperLink addLink = new HyperLink();
				addLink.Text = "Add an article.";
				addLink.NavigateUrl = Global.GetRelativeUrl("Add.aspx");

				// add link to page
				this.Controls.AddAt(0, addLink);
			}

			if(Page.IsPostBack == false) 
			{
				this.articleRepeater.DataSource = ArticleUtility.GetArticles(10);

				// data bind page
				this.DataBind();
			}
		}
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}
	}
}