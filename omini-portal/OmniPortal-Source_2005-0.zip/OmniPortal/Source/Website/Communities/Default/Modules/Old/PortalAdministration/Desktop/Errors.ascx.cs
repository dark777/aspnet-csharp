#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Authentication;
using OmniPortal.Display;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	/// Summary description for Errors.
	/// </summary>
	[	Owner("nberardi", "$Revision: 1.4 $"),
	ModuleAdmin("Errors.aspx", "View Errors", "This module is used for viewing all errors that have occured in the portal.", Options=Permissions.Modify)]
	public class Errors : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.DataGrid errorsGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// data bind
			DataBind();
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		/// <summary>
		/// 
		/// </summary>
		public override void DataBind()
		{
			// set errors
			this.errorsGrid.DataSource = CreateDataSource();

			// data bind
			base.DataBind ();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private DataTable CreateDataSource ()
		{
			DataTable table = AdminUtility.ErrorUtility.GetAllErrors();

			// normalize the data in each row
			foreach(DataRow row in table.Rows) 
			{
				// only show text between " ---> " and first " at "
				string error = (string)row["error_message"];
				int start = (error.LastIndexOf("--->") != -1) ? error.LastIndexOf("--->") + 4 : 0;
				int length = (error.IndexOf(" at ") != -1) ? error.IndexOf(" at ") - start : error.Length - start;

				error = error.Substring(start, length);
				row["error_message"] = error;
			}

			return table;
		}
	}
}