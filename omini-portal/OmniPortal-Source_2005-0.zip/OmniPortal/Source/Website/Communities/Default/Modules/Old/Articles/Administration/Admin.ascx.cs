#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Authentication;
using OmniPortal.Display;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Modules.Articles.Data;

namespace OmniPortal.Components.Modules.Articles.Desktop
{
	[ModuleAdmin("Admin.aspx", "Admin Articles Module", "This is used to administrate the articles section and how it will be setup.", Options=Permissions.Administrate)]
	public class Admin : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.TextBox typeTextBox;
		protected System.Web.UI.WebControls.Button addTypeButton;
		protected System.Web.UI.WebControls.DataGrid typeGrid;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Page.IsPostBack == false)
				this.DataBind();
		}
		
		public override void DataBind()
		{
			typeGrid.DataSource = ArticleUtility.GetArticleTypes();
			
			base.DataBind ();
		}

		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
			this.addTypeButton.Click += new EventHandler(addTypeButton_Click);
		
			base.OnInit (e);
		}

		private void addTypeButton_Click(object sender, EventArgs e)
		{
			ArticleUtility.AddType(typeTextBox.Text);
		}
	}
}