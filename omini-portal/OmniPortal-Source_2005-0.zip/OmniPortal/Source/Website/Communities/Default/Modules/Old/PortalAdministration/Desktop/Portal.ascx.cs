#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Data;
using ManagedFusion.Display;
using ManagedFusion.Types;
using ManagedFusion.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	/// Summary description for SiteInformation.
	/// </summary>
	[ModuleAdmin(
			"Portal.aspx", 
			"Portal Setup", 
			"This module is used to setup and administrate site settings and to link Communities to sites.", 
			Options=Permissions.Modify
		)]
	public class Portal : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.TextBox nameTextbox;
		protected System.Web.UI.WebControls.TextBox titleTextbox;
		protected System.Web.UI.WebControls.Button sendButton;
		protected System.Web.UI.WebControls.TextBox additionalTextTextbox;
		protected System.Web.UI.WebControls.RequiredFieldValidator nameValidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator titleValidator;
		protected System.Web.UI.WebControls.ListBox availableList;
		protected System.Web.UI.WebControls.ListBox linkedList;
		protected System.Web.UI.WebControls.Button addButton;
		protected System.Web.UI.WebControls.Button removeButton;
		protected System.Web.UI.WebControls.Label portalIDLabel;
		protected System.Web.UI.WebControls.Button goButton;
		protected System.Web.UI.WebControls.Label touchedLabel;
		protected System.Web.UI.WebControls.Label timePastLabel;
		protected System.Web.UI.WebControls.ListBox sectionList;
		protected System.Web.UI.WebControls.Label selectedSectionLabel;
		protected System.Web.UI.WebControls.DropDownList CommunitiesList;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
			{
				// data bind
				DataBind();
			}
		}

		#region Properties

		/// <summary></summary>
		protected int PortalID 
		{
			get { return (int)this.ViewState["PortalID"]; }
			set { this.ViewState["PortalID"] = value; } 
		}

		protected CommunityInfo PortalObject 
		{
			get { return CommunityInfo.Collection[this.PortalID]; }
		}

		#endregion

		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set values
			PortalID = CommunityInfo.TempID;

			// setup page id when first entering
			if (Request.QueryString["id"] != null)
				PortalID = Convert.ToInt32(Request.QueryString["id"]);

			this.goButton.Click += new System.EventHandler(this.goButton_Click);
			this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		/// <summary>
		/// 
		/// </summary>
		public override void DataBind()
		{
			CommunityInfo portal = this.PortalObject;

			// sets Communities available
			this.availableList.DataSource = SiteInfo.Collection;
			this.availableList.DataTextField = "FullDomain";
			this.availableList.DataValueField = "ID";

			// sets current sites for this portal
			this.linkedList.DataSource = portal.ConnectedSites;
			this.linkedList.DataTextField = "FullDomain";
			this.linkedList.DataValueField = "ID";

			// set sections available
			this.sectionList.DataSource = SectionInfo.Collection;
			this.sectionList.DataTextField = "Title";
			this.sectionList.DataValueField = "ID";

			// set all sites
			this.CommunitiesList.DataSource = CommunityInfo.Collection;
			this.CommunitiesList.DataTextField = "Name";
			this.CommunitiesList.DataValueField = "ID";

			// set data for portal
			if (portal != null) 
			{
				DateTime lastTouched = portal.Touched;
				TimeSpan timePast = new TimeSpan((DateTime.Now - lastTouched).Ticks);

				this.portalIDLabel.Text = portal.ID.ToString();
				this.touchedLabel.Text = lastTouched.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", timePast.Days, timePast.Hours, timePast.Minutes, timePast.Seconds);
				this.titleTextbox.Text = portal.Title;
				
				// checks to see if the there is a section linked to the Portal
//				try 
//				{
//					this.selectedSectionLabel.Text = portal.ConnectedSection.Name;
//					this.selectedSectionLabel.ForeColor = System.Drawing.Color.Green;
//					this.selectedSectionLabel.Font.Bold = true;
//				} 
//				catch (Exception) 
//				{ 
//					this.selectedSectionLabel.Text = "None"; 
//					this.selectedSectionLabel.ForeColor = System.Drawing.Color.Red;
//					this.selectedSectionLabel.Font.Bold = true;
//				}

				this.EnableFormObjects(true);

				this.sectionList.SelectedIndexChanged += new System.EventHandler(this.sectionList_SelectedIndexChanged);
				this.addButton.Click += new System.EventHandler(this.addButton_Click);
				this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
			} 
			else 
			{
				this.EnableFormObjects(false);
			}

			// data bind
			base.DataBind ();
		}

		private void EnableFormObjects (bool enable) 
		{
			this.availableList.Enabled = enable;
			this.linkedList.Enabled = enable;
			this.addButton.Enabled = enable;
			this.removeButton.Enabled = enable;
			this.sectionList.Enabled = enable;
		}

		#region Events

		private void goButton_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(Global.Path.GetPortalUrl(
				String.Format("Portal.aspx?id={0}", this.CommunitiesList.SelectedItem.Value)
				).ToString());
		}

		private void addButton_Click(object sender, System.EventArgs e)
		{
			this.PortalObject.AddSite(
				SiteInfo.Collection[Convert.ToInt32(this.availableList.SelectedItem.Value)]
				);

			// data bind
			DataBind();
		}

		private void removeButton_Click(object sender, System.EventArgs e)
		{
			this.PortalObject.RemoveSite(
				SiteInfo.Collection[Convert.ToInt32(this.linkedList.SelectedItem.Value)]
				);

			// data bind
			DataBind();
		}

		private void sectionList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
//			this.PortalObject.ConnectedSection = SectionInfo.Collection[Convert.ToInt32(this.sectionList.SelectedItem.Value)];

			// data bind
			DataBind();
		}

		private void sendButton_Click(object sender, System.EventArgs e)
		{
			CommunityInfo portal = this.PortalObject;

			if (portal == null)
				portal = CommunityInfo.CreateNew();

			// change the values
			portal.Title = this.titleTextbox.Text;

			// commit the changes
			portal.CommitChanges();
		}

		#endregion
	}
}