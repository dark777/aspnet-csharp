#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Types;
using OmniPortal.Components.Modules.UserProfile.Data;

namespace OmniPortal.Components.Modules.UserProfile.Desktop
{
	/// <summary>
	///	Summary description for Register.
	/// </summary>
	public class Profile : SkinnedUserControl
	{
		#region Objects
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.CompareValidator CompareValidator1;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator2;
		protected System.Web.UI.WebControls.Button registerButton;
		protected System.Web.UI.WebControls.RequiredFieldValidator passwordValidation;
		protected System.Web.UI.WebControls.RequiredFieldValidator password2Validation;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator4;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator5;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator6;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator7;
		protected System.Web.UI.WebControls.TextBox emailTextBox;
		protected System.Web.UI.WebControls.TextBox publicEmailTextBox;
		protected System.Web.UI.WebControls.DropDownList timeZoneDropDown;
		protected System.Web.UI.WebControls.TextBox websiteTextBox;
		protected System.Web.UI.WebControls.TextBox usernameTextBox;
		protected System.Web.UI.WebControls.TextBox passwordTextBox;
		protected System.Web.UI.WebControls.TextBox password2TextBox;
		protected System.Web.UI.WebControls.TextBox firstNameTextBox;
		protected System.Web.UI.WebControls.TextBox msnTextBox;
		protected System.Web.UI.WebControls.TextBox yahooTextBox;
		protected System.Web.UI.WebControls.TextBox aimTextBox;
		protected System.Web.UI.WebControls.TextBox icqTextBox;
		protected System.Web.UI.WebControls.TextBox occupationTextBox;
		protected System.Web.UI.WebControls.TextBox locationTextBox;
		protected System.Web.UI.WebControls.TextBox interestsTextBox;
		protected System.Web.UI.WebControls.CheckBox newsLetterCheckBox;
		protected System.Web.UI.WebControls.CheckBox notificationsCheckBox;
		protected System.Web.UI.WebControls.TextBox lastNameTextBox;
		#endregion
		
		private void Page_Load (object sender, EventArgs e) 
		{
			if (Request.QueryString["update"] != null) 
			{
				if(Page.IsPostBack == false) 
				{
					// databind previous registered values
					this.DataBind();
				}

				this.passwordTextBox.Attributes.Add("value", "xxxxx");
				this.passwordTextBox.Enabled = false;
				this.passwordValidation.Enabled = false;
				this.password2TextBox.Attributes.Add("value", "xxxxx");
				this.password2TextBox.Enabled = false;
				this.password2Validation.Enabled = false;
				
				// change button name
				this.registerButton.Text = "Update";
			}
		}

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.registerButton.Text = this.CultureManager["Register"];

			this.emailTextBox.TextChanged += new System.EventHandler(this.emailTextBox_TextChanged);
			this.registerButton.Click += new EventHandler(registerButton_Click);
			this.Load += new EventHandler(Page_Load);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			if (Request.QueryString["update"] != null) 
			{
				DataRow userRow = UserUtility.GetUser(Global.PortalContext.User.Identity.Name);
				
				// required information
				this.usernameTextBox.Enabled = false;
				this.usernameTextBox.Text = (string)userRow["user_name"];
				this.emailTextBox.Text = (string)userRow["user_email"];
				this.firstNameTextBox.Text = (string)userRow["user_fname"];
				this.lastNameTextBox.Text = (string)userRow["user_lname"];
				this.timeZoneDropDown.SelectedIndex = this.timeZoneDropDown.Items.IndexOf(this.timeZoneDropDown.Items.FindByValue(((int)userRow["user_timezone"]).ToString()));
				
				// contact information
				this.msnTextBox.Text = (string)userRow["user_msn"];
				this.yahooTextBox.Text = (string)userRow["user_yahoo"];
				this.aimTextBox.Text = (string)userRow["user_aim"];
				this.icqTextBox.Text = (string)userRow["user_icq"];
				this.websiteTextBox.Text = (string)userRow["user_website"];
				this.publicEmailTextBox.Text = (string)userRow["user_publicEmail"];

				// optional information
				this.occupationTextBox.Text = (string)userRow["user_occupation"];
				this.locationTextBox.Text = (string)userRow["user_location"];
				this.interestsTextBox.Text = (string)userRow["user_interests"];

				// email options
				this.newsLetterCheckBox.Checked = (bool)userRow["user_newsletter"];
				this.notificationsCheckBox.Checked = (bool)userRow["user_notification"];
			}

			base.DataBind ();
		}

		private void emailTextBox_TextChanged(object sender, System.EventArgs e)
		{
			// gives a public e-mail address if there is none present
			if (this.publicEmailTextBox.Text == String.Empty)
				this.publicEmailTextBox.Text = this.emailTextBox.Text.Replace("@", " [at] ").Replace(".", " [dot] ");
		}

		private void registerButton_Click(object sender, EventArgs e)
		{
			UserUtility.UpdateUser(
				(Request.QueryString["update"] == null),
				this.usernameTextBox.Text,
				this.passwordTextBox.Text,
				this.emailTextBox.Text,
				this.firstNameTextBox.Text,
				this.lastNameTextBox.Text,
				Convert.ToInt32(this.timeZoneDropDown.SelectedItem.Value),
				this.msnTextBox.Text,
				this.yahooTextBox.Text,
				this.aimTextBox.Text,
				this.icqTextBox.Text,
				this.websiteTextBox.Text,
				this.publicEmailTextBox.Text,
				this.occupationTextBox.Text,
				this.locationTextBox.Text,
				this.interestsTextBox.Text,
				this.newsLetterCheckBox.Checked,
				this.notificationsCheckBox.Checked,
				DateTime.Now,
				Request.UserHostAddress
				);
		}

		private string EncodePassword(string password) 
		{
			return String.Empty.PadLeft(password.Length, 'x');
		}
	}
}