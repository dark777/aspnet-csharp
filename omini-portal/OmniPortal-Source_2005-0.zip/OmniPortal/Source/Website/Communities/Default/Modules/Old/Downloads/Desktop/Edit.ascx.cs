#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Components.Modules.Downloads.Data;

namespace OmniPortal.Components.Modules.Downloads.Desktop
{
	public class Edit : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator2;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator3;
		protected System.Web.UI.WebControls.TextBox descriptionText;
		protected System.Web.UI.WebControls.TextBox urlText;
		protected System.Web.UI.WebControls.TextBox fileNameText;
		protected System.Web.UI.WebControls.TextBox fileSizeText;
		protected System.Web.UI.WebControls.TextBox nameText;
		protected System.Web.UI.WebControls.Button editButton;

		private string _id;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false) 
			{
				_id = Request.QueryString["id"];

				// this tells the program that it is a new download
				if (_id == null || _id == String.Empty)
					_id = "-1";
				else 
				{
					DataRow row = DownloadUtility.GetDownloadByID(Convert.ToInt32(_id));

					this.nameText.Text = (string)row["link_name"];
					this.descriptionText.Text = (string)row["link_description"];
					this.urlText.Text = (string)row["link_url"];
					this.fileNameText.Text = (string)row["download_fileName"];
					this.fileSizeText.Text = ((int)row["download_fileSize"]).ToString();
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.editButton.Click += new System.EventHandler(this.editButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void editButton_Click(object sender, System.EventArgs e)
		{
			DownloadUtility.EditDownload(
				Convert.ToInt32(_id),
				SectionInformation.ID,
				this.nameText.Text,
				this.descriptionText.Text,
				this.urlText.Text,
				this.fileNameText.Text,
				Convert.ToInt32(this.fileSizeText.Text)
				);
		}
	}
}