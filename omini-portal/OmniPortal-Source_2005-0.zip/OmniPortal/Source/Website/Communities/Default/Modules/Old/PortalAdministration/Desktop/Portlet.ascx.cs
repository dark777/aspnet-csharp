#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using OmniPortal.Components.Common;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;
using ManagedFusion.Display.Portlets;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	///	Summary description for Portlet.
	/// </summary>
	[ModuleAdmin("Portlet.aspx", "Portlet Setup", "This module is used to setup of portlets for adding to the container at a later time.", Options=Permissions.Modify)]
	public class Portlet : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Label touchedLabel;
		protected System.Web.UI.WebControls.Label timePastLabel;
		protected System.Web.UI.WebControls.DropDownList typesList;
		protected System.Web.UI.WebControls.Button sendButton;
		protected System.Web.UI.WebControls.DropDownList portletsList;
		protected System.Web.UI.WebControls.Label portletIDLabel;
		protected System.Web.UI.WebControls.TextBox titleTextbox;
		protected System.Web.UI.WebControls.Button goButton;
		protected TabControl portletTabControl;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
				this.DataBind();

			if (PortletID != -1) 
			{
				// setup admin section
				this.SetupAdminOptions(this.PortletID, this.typesList.SelectedItem.Text, this.titleTextbox.Text);
			}
		}
		
		#region Properties

		protected int PortletID 
		{ 
			get { return (int)ViewState["PortletID"]; }
			set { ViewState["PortletID"] = value; }
		}

		protected PortletInfo PortletObject 
		{
			get { return PortletInfo.Collection[this.PortletID]; }
		}

		#endregion

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set values
			PortletID = PortletInfo.TempID;

			// setup page id when first entering
			if (Request.QueryString["id"] != null)
				PortletID = Convert.ToInt32(Request.QueryString["id"]);

			this.goButton.Click += new EventHandler(goButton_Click);
			this.sendButton.Click += new EventHandler(sendButton_Click);
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			PortletInfo portlet = this.PortletObject;

			// set portlets
			this.portletsList.DataSource = PortletInfo.Collection;
			this.portletsList.DataTextField = "Title";
			this.portletsList.DataValueField = "ID";

			// set portlets types
			this.typesList.DataSource = PortletModule.Collection;
			this.typesList.DataTextField = "FileName";
			this.typesList.DataValueField = "FolderName";

			// set data for portlet
			if (portlet != null) 
			{
				DateTime lastTouched = portlet.Touched;
				TimeSpan timePast = new TimeSpan((DateTime.Now - lastTouched).Ticks);

				this.portletIDLabel.Text = portlet.ID.ToString();
				this.touchedLabel.Text = lastTouched.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", timePast.Days, timePast.Hours, timePast.Minutes, timePast.Seconds);

				this.titleTextbox.Text = portlet.Title;

				this.typesList.DataBind();
				this.typesList.SelectedIndex = this.typesList.Items.IndexOf(this.typesList.Items.FindByValue(portlet.Module.ID.ToString("D")));
			}

			base.DataBind();
		}

		private void SetupAdminOptions (int id, string name, string title) 
		{
			// set the location of the control
			string location = String.Concat("Portlets/", name, "/{0}");

			// get the location of the control
			PortletUserControl controlToAdd = (PortletUserControl)Global.Path.GetControlFromLocation(String.Format(location,"Read.ascx"));

			// set value for child portlet
			controlToAdd.PortletInformation = PortletInfo.Collection[id];

			// set view in tabs
			portletTabControl.AddTab("Read", controlToAdd);

			try 
			{
				// get attributes
				PortletAttribute[] attr = (PortletAttribute[])controlToAdd.GetType().GetCustomAttributes(typeof(PortletAttribute), true);

				if (attr.Length > 0) 
				{
#if DEBUG
					Context.Trace.Write("Portlet", String.Format("Found {0} Portlet", attr[0].Title));
#endif
					// if there is an 'Add' option add to tab
					if (attr[0].AddPage != null) 
					{
						PortletUserControl temp = (PortletUserControl)Global.Path.GetControlFromLocation(String.Format(location,attr[0].AddPage));
						temp.PortletInformation = PortletInfo.Collection[id];

						portletTabControl.AddTab("Add", temp);
					}

					// if there is an 'Edit' option add to tab
					if (attr[0].EditPage != null)
					{
						PortletUserControl temp = (PortletUserControl)Global.Path.GetControlFromLocation(String.Format(location,attr[0].EditPage));
						temp.PortletInformation = PortletInfo.Collection[id];

						portletTabControl.AddTab("Edit", temp);
					}

					// if there is an 'Delete' option add to tab
					if (attr[0].DeletePage != null)
					{
						PortletUserControl temp = (PortletUserControl)Global.Path.GetControlFromLocation(String.Format(location,attr[0].DeletePage));
						temp.PortletInformation = PortletInfo.Collection[id];

						portletTabControl.AddTab("Delete", temp);
					}

					// if there is an 'Admin' option add to tab
					if (attr[0].AdminPage != null)
					{
						PortletUserControl temp = (PortletUserControl)Global.Path.GetControlFromLocation(String.Format(location,attr[0].AdminPage));
						temp.PortletInformation = PortletInfo.Collection[id];

						portletTabControl.AddTab("Admin", temp);
					}
				}
			} 
			catch (Exception exc) 
			{
#if DEBUG
				Context.Trace.Warn("Portlet Exception", "Error in Portlet", exc);
#endif
			}
		}

		#region Events

		private void goButton_Click(object sender, EventArgs e)
		{
			Response.Redirect(Global.Path.GetPortalUrl(
				String.Format("Portlet.aspx?id={0}", this.portletsList.SelectedItem.Value)
				).ToString());
		}

		private void sendButton_Click(object sender, System.EventArgs e)
		{
			PortletInfo portlet = this.PortletObject;

			if (portlet == null)
				portlet = PortletInfo.CreateNew();

			// change the values
			portlet.Title = this.titleTextbox.Text;
			portlet.Module = (PortletModule)PortletModule.Collection[new Guid(this.typesList.SelectedItem.Value)];

			// commit the changes
			portlet.CommitChanges();
		}

		#endregion
	}
}