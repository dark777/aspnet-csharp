#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Modules.Downloads
{
	/// <summary>
	/// Summary description for NewsModule.
	/// </summary>
	[Module("Download Module", 
			"This module is used to post downloads to your site.", 
			"{1FE3C1CC-9A30-46e6-B66D-F7DBF517CCC6}")]
	public class DownloadModule : ModuleBase
	{
		public DownloadModule() : base("Downloads") {}

		protected override void OnPopulateHolders(PopulateHoldersEventArgs e)
		{
			// load current control according to the page address
			try 
			{
				string location = Location.ToLower();
				if (location != "default.aspx" &&
					location != "edit.aspx") 
				{
					int id = Convert.ToInt32(Location.Split('-')[0]);
					
					Context.Response.Redirect(Data.DownloadUtility.GetUrlByID(id), true);
				}
			} 
			catch (FormatException) { /* Do Nothing, let Module Base do the rest */ }
		}
	}
}