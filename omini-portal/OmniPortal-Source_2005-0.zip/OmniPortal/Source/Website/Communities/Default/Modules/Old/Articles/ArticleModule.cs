#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Modules.Articles
{
	[Module("Article Module", 
			"This module is used to post articles to your site.", 
			"{939FED24-9B28-490e-960C-E2E9A33C3C04}")]
	public class ArticleModule : ModuleBase
	{
		public ArticleModule() : base("Articles") {}
	}
}