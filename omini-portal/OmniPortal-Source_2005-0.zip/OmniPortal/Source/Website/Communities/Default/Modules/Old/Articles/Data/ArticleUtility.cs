#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;

// OmniPortal Classes
using OmniPortal.Data;

namespace OmniPortal.Components.Modules.Articles.Data
{
	internal class ArticleUtility
	{
//		public static DataRow GetArticleItem (int source) 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select	*
//					from	Module_Articles
//					where	article_id = @article_id
//				");
//
//				// input
//				adapter.SelectCommand.Parameters.Add(f.CreateParameter("@article_id", DbType.Int32, source));
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0].Rows[0];
//		}
//
//		public static DataTable GetArticles (int numberOfArticles) 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(String.Format(@"
//					select	top {0} *
//					from	Module_Articles
//					order by	article_date DESC
//				", numberOfArticles));
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0];
//		}
//
//		public static DataTable GetArticleTypes () 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select	*
//					from	Module_ArticleTypes
//				");
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0];
//		}
//
//		/// <summary>
//		/// 
//		/// </summary>
//		/// <param name="type"></param>
//		public static void AddType (string type) 
//		{
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbConnection connection = f.CreateConnection();
//				IDbCommand command = f.CreateCommand(@"
//					insert into Module_ArticleTypes (
//						type_name
//					) values (
//						@type_name
//					)
//				");
//
//				// input
//				command.Parameters.Add(f.CreateParameter("@type_name", DbType.String, type));
//
//				// send data
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
//
//		public static void AddArticle (string title, int type, string comments, string content, string poster) 
//		{
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbConnection connection = f.CreateConnection();
//				IDbCommand command = f.CreateCommand(@"
//					insert into Module_Articles (
//						article_poster,
//						article_title,
//						article_type,
//						article_comments,
//						article_content,
//						article_date
//					) values (
//						@article_poster,
//						@article_title,
//						@article_type,
//						@article_comments,
//						@article_content,
//						@article_date
//					)
//				");
//
//				// input
//				command.Parameters.Add(f.CreateParameter("@article_poster", DbType.String, poster));
//				command.Parameters.Add(f.CreateParameter("@article_title", DbType.String, title));
//				command.Parameters.Add(f.CreateParameter("@article_type", DbType.Int32, type));
//				command.Parameters.Add(f.CreateParameter("@article_comments", DbType.String, comments));
//				command.Parameters.Add(f.CreateParameter("@article_content", DbType.String, content));
//				command.Parameters.Add(f.CreateParameter("@article_date", DbType.Date, DateTime.Now));
//
//				//send data
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
	}
}