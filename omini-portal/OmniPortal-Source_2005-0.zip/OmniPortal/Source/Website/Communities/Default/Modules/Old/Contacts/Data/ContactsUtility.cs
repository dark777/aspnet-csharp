#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Globalization;

// OmniPortal Classes
using OmniPortal.Data;

namespace OmniPortal.Components.Modules.Contacts.Data
{
	/// <summary>
	/// Summary description for ContactsUtility.
	/// </summary>
	public class ContactsUtility
	{
//		public static DataRow GetContact (Guid id) 
//		{
//			DataSet ds;
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter("Module_ContactsGetContact");
//				adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
//
//				// input
//				adapter.SelectCommand.Parameters.Add(f.CreateParameter("@contact_ID", DbType.Guid, id));
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0].Rows[0];
//		}
//
//		public static DataTable GetContacts () 
//		{
//			return GetContacts('*', "xxxxx");
//		}
//
//		public static DataTable GetContacts (char alpha, string columnName) 
//		{
//			// format the column name for the query
//			columnName = String.Format("{0}.{1}", columnName[0], columnName);
//
//			DataSet ds;
//			string command = @"
//					select	*
//					from	Module_Users u inner join Module_Contacts c
//								on u.user_name = c.contact_id
//				";
//
//			// checks to see if the command should have a where statement
//			if (alpha != '*')
//				command += String.Format(@"
//					where	left({0},1) = '{1}'
//				", columnName, alpha);
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(command);
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0];
//		}
//
//		public static DataTable GetLetterList (string columnName) 
//		{
//			DataSet ds;
//			string command = String.Empty;
//			if (columnName.StartsWith("user"))
//				command = String.Format(@"
//					select	left({0},1) as letter
//					from	Module_Users
//					group by left({0},1)
//				", columnName);
//			else
//				command = String.Format(@"
//					select	left({0},1) as letter
//					from	Module_Contacts
//					group by left({0},1)
//				", columnName);
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(command);
//
//				// read data
//				ds = new DataSet();
//				adapter.Fill(ds);
//			}
//
//			return ds.Tables[0];
//		}
//
//		public static void UpdateContact (
//			Guid id,
//			string firstName,
//			string lastName,
//			string address,
//			string city,
//			string state,
//			string zip,
//			string phone,
//			string email
//			) 
//		{
//			string storedProcedure;
//
//			// checks to see if you need to update or add the item
//			if (id == Guid.Empty)
//				storedProcedure = "Module_ContactsAddContact";
//			else
//				storedProcedure = "Module_ContactsUpdateContacts";
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbConnection connection = f.CreateConnection();
//				IDbCommand command = f.CreateCommand(storedProcedure);
//				command.CommandType = CommandType.StoredProcedure;
//
//				//input
//				command.Parameters.Add(f.CreateParameter("@contact_ID", DbType.Guid, id));
//				command.Parameters.Add(f.CreateParameter("@contact_firstName", DbType.String, firstName));
//				command.Parameters.Add(f.CreateParameter("@contact_lastName", DbType.String, lastName));
//				command.Parameters.Add(f.CreateParameter("@contact_address", DbType.String, address));
//				command.Parameters.Add(f.CreateParameter("@contact_city", DbType.String, city));
//				command.Parameters.Add(f.CreateParameter("@contact_state", DbType.String, state));
//				command.Parameters.Add(f.CreateParameter("@contact_zip", DbType.String, zip));
//				command.Parameters.Add(f.CreateParameter("@contact_phone", DbType.String, phone));
//				command.Parameters.Add(f.CreateParameter("@contact_email", DbType.String, email));
//
//				//send data
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
	}
}