#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Data;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	/// Summary description for Portal.
	/// </summary>
	[ModuleAdmin(
			"Site.aspx", 
			"Site Setup", 
			"This module is used to setup and administrate all portal settings.", 
			Options=Permissions.Modify
			)
	]
	public class Site : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Button sendButton;
		protected System.Web.UI.WebControls.DropDownList sitesList;
		protected System.Web.UI.WebControls.Button goButton;
		protected System.Web.UI.WebControls.Label siteIDLabel;
		protected System.Web.UI.WebControls.Label timePastLabel;
		protected System.Web.UI.WebControls.Label touchedLabel;
		protected System.Web.UI.WebControls.Label associatedLabel;
		protected System.Web.UI.WebControls.TextBox domainText;
		protected System.Web.UI.WebControls.TextBox subDomainText;
		protected System.Web.UI.WebControls.RegularExpressionValidator domainValidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator domainValidator2;
		protected System.Web.UI.WebControls.RegularExpressionValidator subDomainValidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator subDomainValidator2;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
			{
				// data bind
				DataBind();
			}
		}

		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set values
			SiteID = SiteInfo.TempID;

			// setup page id when first entering
			if (Request.QueryString["id"] != null)
				SiteID =  Convert.ToInt32(Request.QueryString["id"]);

			this.Load += new EventHandler(Page_Load);
			this.goButton.Click += new EventHandler(goButton_Click);
			this.sendButton.Click += new EventHandler(sendButton_Click);
		
			base.OnInit (e);
		}

		#region Properties

		protected int SiteID 
		{
			get { return (int)this.ViewState["SiteID"]; }
			set { this.ViewState["SiteID"] = value; } 
		}

		protected SiteInfo SiteObject 
		{
			get { return SiteInfo.Collection[SiteID]; }
		}

		#endregion

		public override void DataBind()
		{
			SiteInfo site = this.SiteObject;

			this.sitesList.DataSource = SiteInfo.Collection;
			this.sitesList.DataTextField = "PrimaryDomain";
			this.sitesList.DataValueField = "ID";
			
			if (site != null) 
			{
				DateTime lastTouched = site.Touched;
				TimeSpan timePast = new TimeSpan((DateTime.Now - lastTouched).Ticks);

				this.siteIDLabel.Text = site.ID.ToString();
				this.touchedLabel.Text = lastTouched.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", timePast.Days, timePast.Hours, timePast.Minutes, timePast.Seconds);

				this.subDomainText.Text = site.SubDomain;
				this.domainText.Text = site.Domain;

//				try 
//				{
//					this.associatedLabel.Text = site.ConnectedPortal.Title;
//					this.associatedLabel.ForeColor = Color.Blue;
//				} 
//				catch (Exception) 
//				{
//					this.associatedLabel.Text = "Not Associated";
//					this.associatedLabel.ForeColor = Color.Red;
//				}
			}

			// data bind
			base.DataBind ();
		}

		#region Events

		private void goButton_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(this.FormatUrl(this.sitesList.SelectedItem.Value));
		}

		private string FormatUrl (string id) 
		{
			return Global.Path.GetPortalUrl(String.Format("Site.aspx?id={0}", id)).ToString();
		}

		private void sendButton_Click(object sender, System.EventArgs e)
		{
			SiteInfo site = this.SiteObject;

			if (site == null)
				site = SiteInfo.CreateNew();

			// change the values
			site.SubDomain = this.subDomainText.Text;
			site.Domain = this.domainText.Text;

			// commit the changes
			site.CommitChanges();
		}

		#endregion
	}
}