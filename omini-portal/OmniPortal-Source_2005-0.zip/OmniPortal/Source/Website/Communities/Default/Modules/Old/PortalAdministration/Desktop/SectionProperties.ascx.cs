#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;

// OmniPortal Classes
using ManagedFusion.Display;
using ManagedFusion.Types;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	///	Summary description for SectionProperties.
	/// </summary>
	public class SectionProperties : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.DataGrid propertyGrid;
		protected System.Web.UI.WebControls.Label sectionNameLabel;
		protected System.Web.UI.WebControls.Button writeButton;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false) 
			{
				// data bind page
				this.DataBind();
			}
		}

		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// enable view state
			this.EnableViewState = true;

			this.SectionID = -1;

			if (Request.QueryString["id"] != null)
				this.SectionID = Convert.ToInt32(Request.QueryString["id"]);

			this.Load += new System.EventHandler(this.Page_Load);
			this.propertyGrid.ItemCreated += new DataGridItemEventHandler(propertyGrid_ItemCreated);
			this.propertyGrid.EditCommand += new DataGridCommandEventHandler(propertyGrid_EditCommand);
			this.propertyGrid.UpdateCommand += new DataGridCommandEventHandler(propertyGrid_UpdateCommand);
			this.propertyGrid.CancelCommand += new DataGridCommandEventHandler(propertyGrid_CancelCommand);
			this.propertyGrid.DeleteCommand += new DataGridCommandEventHandler(propertyGrid_DeleteCommand);
		
			base.OnInit (e);
		}

		#region Properties

		protected int SectionID 
		{
			get { return (int)ViewState["SectionID"]; }
			set { ViewState["SectionID"] = value; }
		}

		protected SectionInfo SectionObject 
		{
			get { return SectionInfo.Collection[this.SectionID]; }
		}

		protected NameValueCollection PropertiesForSection 
		{
			get { return this.SectionObject.ModuleData; }
		}

		#endregion

		public override void DataBind()
		{
			this.sectionNameLabel.Text = SectionInfo.Collection[this.SectionID].Name;

			DataTable table = new DataTable();
			table.Columns.Add("Name", typeof(string));
			table.Columns.Add("Value", typeof(string));

			// add each key/value pair to the table
			foreach(string key in this.PropertiesForSection.Keys)
			{
				table.Rows.Add(new object[] {
						key,
						this.PropertiesForSection[key]
					});
			}

			// set properties to grid
			this.propertyGrid.DataSource = table;

			base.DataBind ();
		}

		private void propertyGrid_ItemCreated (object sender, DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Footer)
			{
				TextBox nameTextBox = new TextBox();
				nameTextBox.ID = "AddName";
				nameTextBox.MaxLength = 64;
				TextBox valueTextBox = new TextBox();
				valueTextBox.ID = "AddValue";
				valueTextBox.Width = new Unit("100%");
				LinkButton addButton = new LinkButton();
				addButton.Text = "Add";
				addButton.Click += new EventHandler(addButton_Click);

				e.Item.Cells[0].Controls.Add(nameTextBox);
				e.Item.Cells[1].Controls.Add(valueTextBox);
				e.Item.Cells[2].Controls.Add(addButton);
			} 
			else if (e.Item.ItemType == ListItemType.EditItem) 
			{
				TextBox valueTextBox = (TextBox)e.Item.Cells[1].Controls[0];

				// set length of text box
				valueTextBox.Width = new Unit("100%");
			}
		}

		private void propertyGrid_EditCommand(object sender, DataGridCommandEventArgs e)
		{
			this.propertyGrid.EditItemIndex = e.Item.ItemIndex;
			this.DataBind();
		}

		private void propertyGrid_UpdateCommand(object sender, DataGridCommandEventArgs e)
		{
			TextBox valueTextBox = (TextBox)e.Item.Cells[1].Controls[0];

			// sets property value
			this.PropertiesForSection.Set(e.Item.Cells[0].Text, valueTextBox.Text);

			// un-edits the grid
			this.propertyGrid.EditItemIndex = -1;
			this.DataBind();
		}

		private void propertyGrid_CancelCommand(object sender, DataGridCommandEventArgs e)
		{
			this.propertyGrid.EditItemIndex = -1;
			this.DataBind();
		}

		private void propertyGrid_DeleteCommand(object sender, DataGridCommandEventArgs e)
		{
			// remove property
			this.PropertiesForSection.Remove(e.Item.Cells[0].Text);
			this.DataBind();
		}

		private void addButton_Click (object sender, EventArgs e) 
		{
			Table table = (Table)this.propertyGrid.Controls[0];

			TextBox nameTextBox = (TextBox)table.Rows[table.Rows.Count -1].FindControl("AddName");
			TextBox valueTextBox = (TextBox)table.Rows[table.Rows.Count -1].FindControl("AddValue");

			this.PropertiesForSection.Add(nameTextBox.Text, valueTextBox.Text);
			this.DataBind();
		}
	}
}