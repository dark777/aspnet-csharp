#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;

// OmniPortal Classes
using OmniPortal.Data;

namespace OmniPortal.Components.Modules.UserProfile.Data
{
	/// <summary>
	/// Summary description for UserUtility.
	/// </summary>
	internal sealed class UserUtility
	{
//		public static DataRow GetUser (string userID) 
//		{
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select	*
//					from	Module_Users
//					where	user_name = @user_name
//				");
//
//				// input
//				adapter.SelectCommand.Parameters.Add(f.CreateParameter("@user_name", DbType.String, userID));
//
//				// output
//				DataSet ds = new DataSet();
//				adapter.Fill(ds);
//
//				// returns the first row of the selected user
//				if(ds.Tables[0].Rows.Count > 0)
//					return ds.Tables[0].Rows[0];
//
//				// user could not be found
//				throw new InformationNotFoundException("The user you selected was not found.");
//			}
//		}
//
//		public static void UpdateUser (
//			bool createUser,
//			string username,
//			string password,
//			string email,
//			string firstName,
//			string lastName,
//			int timeZone,
//			string msn,
//			string yahoo,
//			string aim,
//			string icq,
//			string website,
//			string publicEmail,
//			string occupation,
//			string location,
//			string interests,
//			bool newsLetter,
//			bool notification,
//			DateTime touched,
//			string lastIP
//			) 
//		{
//			#region Command
//			string update = @"
//				update Module_Users
//				set
//					user_email			= @user_email, 
//					user_fname			= @user_fname, 
//					user_lname			= @user_lname, 
//					user_timezone		= @user_timezone, 
//					user_msn			= @user_msn, 
//					user_yahoo			= @user_yahoo, 
//					user_aim			= @user_aim, 
//					user_icq			= @user_icq, 
//					user_website		= @user_website, 
//					user_publicEmail	= @user_publicEmail, 
//					user_occupation		= @user_occupation, 
//					user_location		= @user_location, 
//					user_interests		= @user_interests, 
//					user_newsletter		= @user_newsletter, 
//					user_notification	= @user_notification, 
//					user_touched		= @user_touched, 
//					user_lastIP			= @user_lastIP
//				where
//					user_name = @user_name";
//			#endregion
//
//			// check to see if a new user should be created
//			if (createUser == true) 
//			{
//				#region Forward Values
//				InsertUser (
//					username,
//					password,
//					email,
//					firstName,
//					lastName,
//					timeZone,
//					msn,
//					yahoo,
//					aim,
//					icq,
//					website,
//					publicEmail,
//					occupation,
//					location,
//					interests,
//					newsLetter,
//					notification,
//					touched,
//					lastIP
//					);
//				#endregion
//				return;
//			}
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbConnection connection = f.CreateConnection();
//				IDbCommand command = f.CreateCommand(update);
//
//				// input
//				command.Parameters.Add(f.CreateParameter("@user_email", DbType.String, email));
//				command.Parameters.Add(f.CreateParameter("@user_fname", DbType.String, firstName));
//				command.Parameters.Add(f.CreateParameter("@user_lname", DbType.String, lastName));
//				command.Parameters.Add(f.CreateParameter("@user_timezone", DbType.Int32, timeZone));
//				command.Parameters.Add(f.CreateParameter("@user_msn", DbType.String, msn));
//				command.Parameters.Add(f.CreateParameter("@user_yahoo", DbType.String, yahoo));
//				command.Parameters.Add(f.CreateParameter("@user_aim", DbType.String, aim));
//				command.Parameters.Add(f.CreateParameter("@user_icq", DbType.String, icq));
//				command.Parameters.Add(f.CreateParameter("@user_website", DbType.String, website));
//				command.Parameters.Add(f.CreateParameter("@user_publicEmail", DbType.String, publicEmail));
//				command.Parameters.Add(f.CreateParameter("@user_occupation", DbType.String, occupation));
//				command.Parameters.Add(f.CreateParameter("@user_location", DbType.String, location));
//				command.Parameters.Add(f.CreateParameter("@user_interests", DbType.String, interests));
//				command.Parameters.Add(f.CreateParameter("@user_newsletter", DbType.Boolean, newsLetter));
//				command.Parameters.Add(f.CreateParameter("@user_notification", DbType.Boolean, notification));
//				command.Parameters.Add(f.CreateParameter("@user_touched", DbType.Date, touched));
//				command.Parameters.Add(f.CreateParameter("@user_lastIP", DbType.String, lastIP));
//				command.Parameters.Add(f.CreateParameter("@user_name", DbType.String, username));
//
//				// update database
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
//
//		private static void InsertUser (
//			string username,
//			string password,
//			string email,
//			string firstName,
//			string lastName,
//			int timeZone,
//			string msn,
//			string yahoo,
//			string aim,
//			string icq,
//			string website,
//			string publicEmail,
//			string occupation,
//			string location,
//			string interests,
//			bool newsLetter,
//			bool notification,
//			DateTime touched,
//			string lastIP
//			)
//		{
//			#region Command
//			string insert = @"
//				insert into Module_Users ( 
//					user_name, 
//					user_password, 
//					user_email, 
//					user_fname, 
//					user_lname, 
//					user_timezone, 
//					user_msn, 
//					user_yahoo, 
//					user_aim, 
//					user_icq, 
//					user_website, 
//					user_publicEmail, 
//					user_occupation, 
//					user_location, 
//					user_interests, 
//					user_newsletter, 
//					user_notification, 
//					user_touched, 
//					user_lastIP, 
//					user_regDate, 
//					user_regIP 
//				) values (
//					@user_name, 
//					@user_password, 
//					@user_email, 
//					@user_fname, 
//					@user_lname, 
//					@user_timezone, 
//					@user_msn, 
//					@user_yahoo, 
//					@user_aim, 
//					@user_icq, 
//					@user_website, 
//					@user_publicEmail, 
//					@user_occupation, 
//					@user_location, 
//					@user_interests, 
//					@user_newsletter, 
//					@user_notification, 
//					@user_touched, 
//					@user_lastIP,
//					@user_regDate,
//					@user_regIP
//				)";
//			#endregion
//
//			using (ProviderFactory f = new ProviderFactory()) 
//			{
//				IDbConnection connection = f.CreateConnection();
//				IDbCommand command = f.CreateCommand(insert);
//
//				// input
//				command.Parameters.Add(f.CreateParameter("@user_name", DbType.String, username));
//				command.Parameters.Add(f.CreateParameter("@user_password", DbType.String, password));
//				command.Parameters.Add(f.CreateParameter("@user_email", DbType.String, email));
//				command.Parameters.Add(f.CreateParameter("@user_fname", DbType.String, firstName));
//				command.Parameters.Add(f.CreateParameter("@user_lname", DbType.String, lastName));
//				command.Parameters.Add(f.CreateParameter("@user_timezone", DbType.Int32, timeZone));
//				command.Parameters.Add(f.CreateParameter("@user_msn", DbType.String, msn));
//				command.Parameters.Add(f.CreateParameter("@user_yahoo", DbType.String, yahoo));
//				command.Parameters.Add(f.CreateParameter("@user_aim", DbType.String, aim));
//				command.Parameters.Add(f.CreateParameter("@user_icq", DbType.String, icq));
//				command.Parameters.Add(f.CreateParameter("@user_website", DbType.String, website));
//				command.Parameters.Add(f.CreateParameter("@user_publicEmail", DbType.String, publicEmail));
//				command.Parameters.Add(f.CreateParameter("@user_occupation", DbType.String, occupation));
//				command.Parameters.Add(f.CreateParameter("@user_location", DbType.String, location));
//				command.Parameters.Add(f.CreateParameter("@user_interests", DbType.String, interests));
//				command.Parameters.Add(f.CreateParameter("@user_newsletter", DbType.Boolean, newsLetter));
//				command.Parameters.Add(f.CreateParameter("@user_notification", DbType.Boolean, notification));
//				command.Parameters.Add(f.CreateParameter("@user_touched", DbType.Date, touched));
//				command.Parameters.Add(f.CreateParameter("@user_lastIP", DbType.String, lastIP));
//				command.Parameters.Add(f.CreateParameter("@user_regDate", DbType.Date, touched));
//				command.Parameters.Add(f.CreateParameter("@user_regIP", DbType.String, lastIP));
//
//				// insert user
//				connection.Open();
//				command.ExecuteNonQuery();
//				connection.Close();
//			}
//		}
	}
}

#region $Id: UserUtility.cs,v 1.3 2004/09/01 19:16:12 nberardi Exp $
/*****************************************************************************************
 * 
 * File Information:
 * 
 * $Source: /cvsroot/omniportal/OmniPortal/Source/Website/Modules/UserProfile/Data/UserUtility.cs,v $
 * $Author: nberardi $
 * $Revision: 1.3 $
 * $Date: 2004/09/01 19:16:12 $
 *
 * Revision history:
 * 
 * $Log: UserUtility.cs,v $
 * Revision 1.3  2004/09/01 19:16:12  nberardi
 * OmniPortal 2004.0 (version 1.0 - build 0002)
 *
 * Revision 1.2  2004/08/25 13:00:38  nberardi
 * OmniPortal 2004.0 (version 1.0 - build 0001)
 *   -  Removed all reminance of managing data using SQL commands from the developer perspective
 *   +  No more problems with creating module providers
 *   +  Modules are now fully portable
 *
 * Revision 1.1  2004/03/22 22:23:27  nberardi
 * v0.7 (Build 142)
 *   +  Module.config now supports HttpHandlers and Regular Expressions.
 *   *  Added the option in Web.config to provide multiple configs for different domains.
 *   *  Many minor bug fixes.
 *   +  Added FreeTextBox 2.0 and removed 1.x
 *
 * Revision 1.4  2004/01/09 22:36:54  nberardi
 * v0.6 (Build 136)
 *   *  Minor Release Tweaks
 *
 * Revision 1.8  2004/01/09 19:52:23  nberardi
 * v0.6 (Release of v0.6)
 *   +  Added setup script for both Microsoft SQL database and Access Database.
 *   +  Added three new modules, UserProfile Module for registering users and a Module Administration Module for the admin of modules that have the ModuleAdminAttribute.  In addition to an improved NewsModule which is now called ArticleModule
 *   -  Removed NewsModule because of the change to NewModule.
 *   *  Fixed a couple security problems that were arising when logging in and moving through out the site.
 *   *  Removed the need of the User Role, because any Authenticated user is in actuality a user.  There is now support for a Super User, which is a user that is just below the security level of the Administrator.
 *   -  Removed all Stored Procedures out of database in order to support databases that don’t have support for Stored Procedures.  (i.e. Access, MySQL, etc.)
 *   *  [846079] Fixed Error when logging in.
 *   *  [846081] Fixed Errors for stored procedures that couldn’t be found.
 *   *  Revamped caching procedures and how the database is stored in memory.
 *   *  Portal and Site have been switched because they make more sense.  A site is a URL such as www.omniportal.net and a Portal is an interface for a website.  Plus too many people asked me about this so I switched them around.
 *   +  Added support for bots on each page as well as content rating.
 *
 * 
 *****************************************************************************************/
#endregion