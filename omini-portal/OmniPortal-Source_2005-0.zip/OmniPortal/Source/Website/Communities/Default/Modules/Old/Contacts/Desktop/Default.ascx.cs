#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Display;
using OmniPortal.Components.Modules.Contacts.Common;
using OmniPortal.Components.Modules.Contacts.Data;

namespace OmniPortal.Components.Modules.Contacts.Desktop
{
	/// <summary>
	///	Summary description for _Default.
	/// </summary>
	public class ContactDefault : SkinnedUserControl
	{
		protected PlaceHolder headerPlaceHolder;
		protected ContactDataGrid contactDataGrid;
		protected CheckBox sortCheckBox;

		// list of availiable letters
		private ArrayList alphaList;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if(Page.IsPostBack == false) 
			{
				// bind data to page
				this.DataBind();
			}
		}
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set defaults
			this.Letter = '*';
			this.Column = "user_lname";
			this.Order = "ASC";
			this.SortByName = false;

			// get current letter
			if (Request.QueryString["letter"] != null)
				this.Letter = Convert.ToChar(Request.QueryString["letter"]);

			if (Request.QueryString["column"] != null)
				this.Column = Request.QueryString["column"];

			if (Request.QueryString["order"] != null)
				this.Order = Request.QueryString["order"];

			if (Request.QueryString["byname"] != null)
				this.SortByName = Convert.ToBoolean(Request.QueryString["byname"]);

			// set events
			this.headerPlaceHolder.DataBinding += new EventHandler(headerPlaceHolder_DataBinding);
			this.contactDataGrid.SortCommand += new DataGridSortCommandEventHandler(contactDataGrid_SortCommand);
			this.sortCheckBox.CheckedChanged += new EventHandler(sortCheckBox_CheckedChanged);
			this.contactDataGrid.ItemCommand += new DataGridCommandEventHandler(contactDataGrid_ItemCommand);
			this.Load += new System.EventHandler(this.Page_Load);

			// set check mark
			this.sortCheckBox.Checked = this.SortByName;
		
			base.OnInit (e);
		}

		protected char Letter 
		{
			get { return (char)ViewState["Letter"]; }
			set { ViewState["Letter"] = value; }
		}

		protected string Column 
		{
			get { return (string)ViewState["Column"]; }
			set { ViewState["Column"] = value; }
		}

		protected string Order 
		{
			get { return (string)ViewState["Order"]; }
			set { ViewState["Order"] = value; }
		}

		protected bool SortByName
		{
			get { return (bool)ViewState["SortByName"]; }
			set { ViewState["SortByName"] = value; }
		}

		public override void DataBind()
		{
			this.alphaList = new ArrayList();

			// add all letters to temp character array
			foreach(DataRow row in ContactsUtility.GetLetterList(this.Column).Rows) 
				this.alphaList.Add(((string)row["letter"]).ToCharArray()[0]);

			// set contact data grid parameters
			this.contactDataGrid.DividerDisplayColumn = this.Column;
			this.contactDataGrid.SortOrder = this.Order;
			this.contactDataGrid.SortWithFullColumnName = this.SortByName;
			this.contactDataGrid.DataSource = this.GetContacts(this.Letter, this.Column);
			this.contactDataGrid.DataKeyField = "contact_ID";

			base.DataBind ();
		}

		private void sortCheckBox_CheckedChanged(object sender, EventArgs e) 
		{
			this.SortByName = !this.SortByName;
			this.Response.Redirect(this.WriteUrl());
		}

		private void contactDataGrid_ItemCommand (object sender, DataGridCommandEventArgs e) 
		{
			if (e.CommandName == "View") 
			{
				Response.Redirect(Global.GetRelativeUrl(
					String.Format("{0:B}.aspx", (Guid)this.contactDataGrid.DataKeys[e.Item.ItemIndex])
					));
			}
		}

		private void contactDataGrid_SortCommand(object sender, DataGridSortCommandEventArgs e) 
		{
			// set sort expression
			if (e.SortExpression == this.Column) 
			{
				if (this.Order == "ASC")
					this.Order = "DESC";
				else 
					this.Order = "ASC";
			} 
			else 
			{
				this.Letter = '*';	// this is the correct the problem with fields disapearing
				this.Column = e.SortExpression;
				this.Order = "ASC";
			}

			// redirect URL to the correct order
			Response.Redirect(this.WriteUrl());
		}

		private void headerPlaceHolder_DataBinding(object sender, System.EventArgs e)
		{
			PlaceHolder headerPlaceHolder = (PlaceHolder)sender;

			// gets characters A - Z
			for (int i = (int)'A'; i <= (int)'Z'; i++) 
			{
				// check to see if letter is in table of availiable letters
				if (alphaList.Contains((char)i)) 
				{
					// create new hyperlink
					HyperLink link = new HyperLink();
					link.Text = ((char)i).ToString();
					link.ForeColor = Color.White;
					link.NavigateUrl = this.WriteUrl((char)i);

					// add hyperlink to place holder
					headerPlaceHolder.Controls.Add(link);
				} 
				else 
					headerPlaceHolder.Controls.Add(new LiteralControl(Convert.ToString((char)i)));

				// write space
				headerPlaceHolder.Controls.Add(new LiteralControl("&nbsp;"));
			}

			// write break
			headerPlaceHolder.Controls.Add(new LiteralControl("|&nbsp;"));

			// create new hyperlink
			HyperLink allLink = new HyperLink();
			allLink.Text = "All";
			allLink.ForeColor = Color.White;
			allLink.NavigateUrl = this.WriteUrl('*');

			// add hyperlink to place holder
			headerPlaceHolder.Controls.Add(allLink);
		}

		private string WriteUrl () 
		{
			return this.WriteUrl(this.Letter);
		}

		private string WriteUrl (char letter)
		{
			// redirect URL to the correct order
			return Global.GetAbsoluteUrl(
				String.Format("Default.aspx?letter={0}&column={1}&order={2}&byname={3}",
				letter,
				this.Column,
				this.Order,
				this.SortByName)
				);
		}

		private DataTable GetContacts (char letter, string columnName) 
		{
			DataTable contactTable = null;

			if (letter == '*')
				contactTable = ContactsUtility.GetContacts();
			else
				contactTable = ContactsUtility.GetContacts(letter, columnName);

			// create new columns for use Int64 formatting
			contactTable.Columns["contact_phone"].ColumnName = "contact_phone_alt";
			contactTable.Columns.Add("contact_phone", typeof(long));

			// go through each row and convert the string to a number for phone
			foreach(DataRow row in contactTable.Rows)
				row["contact_phone"] = Convert.ToInt64((string)row["contact_phone_alt"]);

			return contactTable;
		}
	}
}