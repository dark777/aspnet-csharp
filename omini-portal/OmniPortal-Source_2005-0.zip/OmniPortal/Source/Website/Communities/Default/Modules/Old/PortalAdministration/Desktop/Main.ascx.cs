#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Collections;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	/// Summary description for AdminDefault.
	/// </summary>
	public class Main : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.Repeater moduleRepeater;
		protected System.Web.UI.WebControls.Repeater compactRepeater;
		protected System.Web.UI.WebControls.Label titleLabel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.QueryString["type"] == "compact") 
			{
				this.FindControl("full").Visible = false;
				this.FindControl("compact").Visible = true;
			}

			// set header if there is no theme
			if (SectionInformation.NoTheme)
				titleLabel.Text = SectionInformation.Title;
			else
				titleLabel.Visible = false;

			// get a collection of admin modules
			ModuleAdminAttribute[] collection = this.ScourAssembly();

			// sets module collection as datasource
			if (Request.QueryString["type"] == "compact") 
				compactRepeater.DataSource = collection;
			else
				moduleRepeater.DataSource = collection;

			// databind page
			DataBind();
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.moduleRepeater.ItemDataBound += new RepeaterItemEventHandler(moduleRepeater_ItemDataBound);
			this.compactRepeater.ItemDataBound += new RepeaterItemEventHandler(moduleRepeater_ItemDataBound);
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		private ModuleAdminAttribute[] ScourAssembly () 
		{
			ArrayList al = new ArrayList();

			// searches each array for AdminModuleAttribute
			foreach (string assembly in Global.GetUniqueAssemblies()) 
			{
				Assembly a = Assembly.Load(assembly);
				ArrayList attribs = new ArrayList();

				// checks each type to see if AdminModuleAttribute is in it
				foreach (Type t in a.GetTypes()) 
				{
					// checks to see if it is portal admin stuff
					if (t.FullName.StartsWith("OmniPortal.Components.Modules.PortalAdministration.Desktop"))
					{
						// gets all attributes of AdminModuleAttribute
						object[] o = t.GetCustomAttributes(typeof(ModuleAdminAttribute), false);

						// if attributes are found add to array list
						if (o.Length > 0) 
							attribs.Add(o[0]);
					}
				}

#if DEBUG
				Context.Trace.Write("AdminDefault", String.Format("Found {0} in {1} of {2} Types", attribs.Count, assembly, a.GetTypes().Length));
#endif
				al.AddRange(attribs.ToArray());
			}

			// returns all objects of AdminModuleAttribute that were found in all arrays
			return (ModuleAdminAttribute[])al.ToArray(typeof(ModuleAdminAttribute));
		}

		private void moduleRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			// checks to see if the item to be bound is item or alternating item
			if (e.Item.ItemType == ListItemType.Item  || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				ModuleAdminAttribute attr = (ModuleAdminAttribute)e.Item.DataItem;
#if DEBUG
				Context.Trace.Write("Module Bound", attr.Title);
#endif
				if (Request.QueryString["type"] == "compact") 
				{
					// create controls
					HyperLink compactLink = (HyperLink)e.Item.FindControl("compactLink");

					// set controls data
					compactLink.Text = attr.Title;
					compactLink.ToolTip = attr.Description;
					compactLink.NavigateUrl = Global.Path.GetPortalUrl(attr.Location).ToString();
				} 
				else 
				{
					// create controls
					HyperLink titleLink = (HyperLink)e.Item.FindControl("titleLink");
					Label descriptionLabel = (Label)e.Item.FindControl("descriptionLabel");

					// set controls data
					titleLink.Text = attr.Title;
					titleLink.NavigateUrl = Global.Path.GetPortalUrl(attr.Location).ToString();
					descriptionLabel.Text = attr.Description;
				}
			}
		}
	}
}