#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;

// OmniPortal Classes
using OmniPortal;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Common;

namespace OmniPortal.Components.Modules.UsersAdministration
{
	/// <summary>
	/// Summary description for PortalAdministrationModule.
	/// </summary>
	[Module("Module Administration Module", 
			"Used to administrate many of the functions that are associated with setting up OmniPortal", 
			"{14E10088-47C4-4a55-B079-FCCF512A0D94}")]
	public class ModuleAdministrationModule : ModuleBase
	{
		public ModuleAdministrationModule() : base("ModuleAdministration") { }
	}
}