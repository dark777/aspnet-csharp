#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

// OmniPortal Classes
using OmniPortal.Components.Common;
using OmniPortal.Components.Modules.Contacts.Data;

namespace OmniPortal.Components.Modules.Contacts.Common
{
	/// <summary>
	/// DataGrid that enables the creation of Master/Detail grids
	/// </summary>
	[ToolboxData("<{0}:ContactDataGrid runat=server></{0}:ContactDataGrid>")]
	public class ContactDataGrid : OmniPortal.Components.Common.MasterDataGrid
	{
		[Browsable(true)]
		[Bindable(true)]
		[Description("The CSS class that is used in defining the style of the divider.")]
		[Category("Appearance")]
		public string DividerCssClass 
		{
			get 
			{ 
				if (ViewState["DividerCssClass"] == null)
					DividerCssClass = String.Empty;
				return (string)ViewState["DividerCssClass"]; 
			}
			set { ViewState["DividerCssClass"] = value; }
		}

		[Browsable(true)]
		[Bindable(true)]
		[Description("The order of sorting that will be used in this data grid.  Same procedure as DataView.Sort.")]
		[Category("Misc")]
		public string SortOrder 
		{
			get 
			{ 
				if (ViewState["SortOrder"] == null)
					SortOrder = "ASC";
				return (string)ViewState["SortOrder"]; 
			}
			set { ViewState["SortOrder"] = value; }
		}

		[Browsable(true)]
		[Bindable(true)]
		[Description("The column that will be used in the sorting of this DataGrid.")]
		[Category("Misc")]
		public string DividerDisplayColumn 
		{
			get 
			{ 
				if (ViewState["DividerDisplayColumn"] == null)
					DividerDisplayColumn = "contact_lastName";
				return (string)ViewState["DividerDisplayColumn"]; 
			}
			set { ViewState["DividerDisplayColumn"] = value; }
		}

		[Browsable(true)]
		[Bindable(true)]
		[Description("The appearance of the divider name, if it should be the full next or only the first letter.")]
		[Category("Appearance")]
		public bool SortWithFullColumnName 
		{
			get 
			{ 
				if (ViewState["SortWithFullColumnName"] == null)
					SortWithFullColumnName = false;
				return (bool)ViewState["SortWithFullColumnName"]; 
			}
			set { ViewState["SortWithFullColumnName"] = value; }
		}

		public override void DataBind()
		{
			// set column direction arrow
			SetColumnDirectionArrow();

            // setup data source
			DataView view = this.GetView(this.DataSource);
			view.Sort = String.Format("{0} {1}", this.DividerDisplayColumn, this.SortOrder);

			// set data source
			this.DataSource = view;

			base.DataBind ();
		}

		protected override void OnInit(EventArgs e)
		{
			// set parameters
			this.EnableViewState = true;

			// set events
			this.DataGridItemRender += new DataGridItemRenderEventHandler(ContactDataGrid_DataGridItemRender);

			base.OnInit (e);
		}

		private void SetColumnDirectionArrow () 
		{
			// the following code is used to add arrows to the header column
			foreach(DataGridColumn column in this.Columns) 
			{
				// checks to see if the column is of type BoundColumn
				if (column.GetType() == typeof(BoundColumn)) 
				{
					BoundColumn b = (BoundColumn)column;

					// checks to see if the data field matches the current display column
					if (b.DataField == this.DividerDisplayColumn) 
					{
						// checks to see which way the arror should be pointing
						if (this.SortOrder == "ASC")
							b.HeaderText += "&nbsp;▼";
						else
							b.HeaderText += "&nbsp;▲";
					}
				}
			}
		}

		private DataView GetView (object o) 
		{
			Type t = o.GetType();
			
			// checks to see if the datasource is of any of these types
			if(t == typeof(DataView))
				return (DataView)o;
			else if(t == typeof(DataTable))
				return new DataView((DataTable)o);
			else if(t == typeof(DataSet))
				return new DataView(((DataSet)o).Tables[0]);
			else
				throw new NotSupportedInCodeException();
		}

		private void ContactDataGrid_DataGridItemRender(object sender, DataGridItemRenderEventArgs e)
		{
			DataView view = (DataView)this.DataSource;

			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem) 
			{
				bool insertHeader = false;
				string currentName = (string)view[e.Item.DataSetIndex][DividerDisplayColumn];
				string previousName = String.Empty;

				// if first item then create header
				if (e.Item.ItemIndex == 0) 
					insertHeader = true;
				else
					previousName = (string)view[e.Item.DataSetIndex -1][DividerDisplayColumn];

				// check to see if it should be the full name or only first letter
				if (SortWithFullColumnName == false) 
				{
					currentName = currentName[0].ToString();

					if (e.Item.ItemIndex > 0)
						previousName = previousName[0].ToString();
				}

				// if item is greater than 0
				if (e.Item.ItemIndex > 0) 
				{
					// create header if current and previous first letters are not equal
					insertHeader = (currentName != previousName);
				}

				if (currentName == String.Empty || currentName == " ") 
					currentName = "None";

				// insert header
				if (insertHeader)
				{
					// create cell
					TableCell headerCell = new TableCell();
					headerCell.ColumnSpan = this.Columns.Count;
					headerCell.Text = currentName;

					// create row
					TableRow headerRow = new TableRow();
					headerRow.CssClass = DividerCssClass;
					headerRow.Cells.Add(headerCell);
			
					// add new row
					e.NewRows.Add(headerRow);
				}
			}
		}
	}
}