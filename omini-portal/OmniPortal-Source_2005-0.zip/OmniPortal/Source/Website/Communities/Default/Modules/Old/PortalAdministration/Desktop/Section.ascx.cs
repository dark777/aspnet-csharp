#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Drawing;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Data;
using ManagedFusion.Types;
using ManagedFusion.Display;
using ManagedFusion.Display.Containers;
using ManagedFusion.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	/// Summary description for Section.
	/// </summary>
	[ModuleAdmin("Section.aspx", "Section Setup", "This module is used to setup and administrate section settings and to link Communities to sites.", Options=Permissions.Modify)]
	public class Section : SkinnedUserControl
	{
		#region Fields

		protected System.Web.UI.WebControls.Label touchedLabel;
		protected System.Web.UI.WebControls.Label timePastLabel;
		protected System.Web.UI.WebControls.TextBox nameTextbox;
		protected System.Web.UI.WebControls.RequiredFieldValidator nameValidator;
		protected System.Web.UI.WebControls.TextBox titleTextbox;
		protected System.Web.UI.WebControls.RequiredFieldValidator titleValidator;
		protected System.Web.UI.WebControls.TextBox descriptionTextbox;
		protected System.Web.UI.WebControls.RequiredFieldValidator descriptionValidator;
		protected System.Web.UI.WebControls.TextBox keywordsTextbox;
		protected System.Web.UI.WebControls.RequiredFieldValidator keywordsValidator;
		protected System.Web.UI.WebControls.Button sendButton;
		protected System.Web.UI.WebControls.DataGrid childrenDataGrid;
		protected System.Web.UI.WebControls.CheckBox enableCheckBox;
		protected System.Web.UI.WebControls.DropDownList skinList;
		protected System.Web.UI.WebControls.DropDownList styleList;
		protected System.Web.UI.WebControls.DropDownList sectionOwnerList;
		protected System.Web.UI.WebControls.LinkButton addSectionButton;
		protected System.Web.UI.WebControls.Label sectionIDLabel;
		protected System.Web.UI.WebControls.Label associatedLabel;
		protected System.Web.UI.WebControls.HyperLink backToParentLink;
		protected System.Web.UI.WebControls.HyperLink backToPrimaryParentLink;
		protected System.Web.UI.WebControls.HyperLink propertiesHyperLink;
		protected System.Web.UI.HtmlControls.HtmlTableRow formRow;
		protected System.Web.UI.HtmlControls.HtmlTableRow childrenRow;
		protected System.Web.UI.WebControls.DropDownList pageTypeList;
		protected System.Web.UI.WebControls.TextBox additionalTextTextbox;
		protected System.Web.UI.WebControls.LinkButton refreshButton;
		protected OmniPortal.Components.Common.RolesGrid rolesGrid;
		protected OmniPortal.Components.Common.SelectionList containerList;

		#endregion
	
		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
			{
				// data bind
				DataBind();
			}
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			// page setup
			this.EnableViewState = true;

			// set values
			SectionID = -1;
			ParentID = -1;
			PrimaryParentID = -1;

			// setup page id when first entering
			if (Request.QueryString["id"] != null)
				SectionID = Convert.ToInt32(Request.QueryString["id"]);

			if (Request.QueryString["parentID"] != null)
				ParentID = Convert.ToInt32(Request.QueryString["parentID"]);

			if (Request.QueryString["primaryParentID"] != null)
				PrimaryParentID = Convert.ToInt32(Request.QueryString["primaryParentID"]);

			// get parent id and primary parent id
			if (SectionID != -1 && (ParentID == -1 || PrimaryParentID == -1)) 
			{
				SectionInfo info = SectionInfo.Collection[SectionID];
				
				if (ParentID == -1 && info.Parent != null)
					ParentID = info.Parent.ID;
				
				if (PrimaryParentID == -1 && info.PrimaryParent != null)
					PrimaryParentID = info.PrimaryParent.ID;
			}

			// if all ID's are -1 then hide the form table because we are at the root level
			if (SectionID == -1 && ParentID == -1 && PrimaryParentID == -1)
				formRow.Visible = false;

				// hides the children row if a new section is getting inserted
			else if (SectionID == -1 && ParentID != -1 && PrimaryParentID != -1)
				childrenRow.Visible = false;

			// set edit properties hyper link
			this.propertiesHyperLink.NavigateUrl = Global.Path.GetPortalUrl(String.Format("SectionProperties.aspx?id={0}", this.SectionID)).ToString();

			string formatMap = "Section.aspx?id={0}";

			// sets navigation URL
			this.backToParentLink.NavigateUrl = Global.Path.GetPortalUrl(String.Format(formatMap, ParentID)).ToString();
			this.backToPrimaryParentLink.NavigateUrl = Global.Path.GetPortalUrl(String.Format(formatMap, PrimaryParentID)).ToString();

			// setup container
			this.containerList.AddItemClick += new EventHandler(containerList_AddItemClick);
			this.containerList.RemoveItemClick += new EventHandler(containerList_RemoveItemClick);

			// define variables
			this.skinList.SelectedIndexChanged += new System.EventHandler(this.skinList_SelectedIndexChanged);
			this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
			this.childrenDataGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.childrenDataGrid_ItemCommand);
			this.addSectionButton.Click += new System.EventHandler(this.addSectionButton_Click);

			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		#region Properties

		protected int SectionID 
		{
			get { return (int)ViewState["SectionID"]; }
			set { ViewState["SectionID"] = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		protected int ParentID 
		{
			get { return (int)ViewState["ParentID"]; }
			set { ViewState["ParentID"] = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		protected int PrimaryParentID 
		{
			get { return (int)ViewState["PrimaryParentID"]; }
			set { ViewState["PrimaryParentID"] = value; }
		}

		protected SectionInfo SectionObject 
		{
			get { return SectionInfo.Collection[this.SectionID]; }
		}

		#endregion

		public override void DataBind()
		{
			DataTable table = new DataTable();
			table.Columns.AddRange( new DataColumn[]
				 {
					 new DataColumn("section_id", typeof(int)),
					 new DataColumn("section_name", typeof(string)),
					 new DataColumn("section_visible", typeof(string)),
					 new DataColumn("section_module_name", typeof(string))
				 });

			foreach(SectionInfo child in GetChildren(SectionID)) 
			{
				DataRow row = table.NewRow();

				row["section_id"] = child.ID;
				row["section_name"] = child.Name;
				row["section_visible"] = child.Visible;
				row["section_module_name"] = child.Module.Title;
				
				table.Rows.Add(row);
			}

			// set dataset for children
			this.childrenDataGrid.DataSource = table;
			this.childrenDataGrid.DataKeyField = "section_id";

			// set page type data sets
			this.pageTypeList.DataSource = SectionModule.Collection;
			this.pageTypeList.DataValueField = "ID";
			this.pageTypeList.DataTextField = "Title";

			SectionInfo section = this.SectionObject;

			// set roles that are available
			this.sectionOwnerList.DataSource = Global.User.SystemRoles;

			// set skin list
			this.skinList.DataSource = this.CommunityInformation.AvailableSkins;

			// set style list
			this.styleList.DataSource = new StyleInfo[0];

			this.containerList.LeftListDataSource = section.Containers;
			this.containerList.LeftListTextField = "Name";
			this.containerList.LeftListValueField = "ID";

			// get a delta list of the containers that are not in this section
			ArrayList list = new ArrayList(ContainerInfo.Collection.Count);
			foreach(ContainerInfo container in ContainerInfo.Collection) 
				if (section.Containers.Contains(container) == false)
					list.Add(container);
			ContainerCollection deltaContainerCollection = new ContainerCollection((ContainerInfo[])list.ToArray(typeof(ContainerInfo)));

			this.containerList.RightListDataSource = deltaContainerCollection;
			this.containerList.RightListTextField = "Name";
			this.containerList.RightListValueField = "ID";

			this.rolesGrid.Roles.AddRange(Global.User.SystemRoles);
			this.rolesGrid.Roles.AddRange(Enum.GetNames(typeof(PortalRoles)));

			// data bind
			base.DataBind();

			if (section != null) 
			{
				// enable these controls on update of section
				this.rolesGrid.Enabled = true;
				this.propertiesHyperLink.Enabled = true;
				this.containerList.Enabled = true;

				DateTime lastTouched = section.Touched;
				TimeSpan timePast = new TimeSpan((DateTime.Now - lastTouched).Ticks);

				this.sectionIDLabel.Text = section.ID.ToString();
				this.touchedLabel.Text = lastTouched.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", timePast.Days, timePast.Hours, timePast.Minutes, timePast.Seconds);
				this.nameTextbox.Text = section.Name;
				this.titleTextbox.Text = section.Title;
				this.enableCheckBox.Checked = section.Visible;
				this.skinList.SelectedIndex = this.skinList.Items.IndexOf(this.skinList.Items.FindByValue(section.OriginalTheme));
				
				// set style list
				this.styleList.DataSource = Styles.GetStyles(section.OriginalSkin);
				this.styleList.DataBind();
				this.styleList.SelectedIndex = this.styleList.Items.IndexOf(this.styleList.Items.FindByValue(section.OriginalStyle));

				this.pageTypeList.SelectedIndex = this.pageTypeList.Items.IndexOf(this.pageTypeList.Items.FindByValue(section.Module.ID.ToString("D")));
				this.sectionOwnerList.SelectedIndex = this.sectionOwnerList.Items.IndexOf(this.sectionOwnerList.Items.FindByValue(section.OriginalOwner));

				// get roles and permissions for this current section
				foreach(string role in section.Roles.Keys)
					this.rolesGrid.RolesInUse.Add(role, section.Roles[role]);

				// data bind roles grid
				this.rolesGrid.DataBind();
			} 
			else 
			{
				this.sectionIDLabel.Text = "{Adding Section}";
				this.touchedLabel.Text = DateTime.Today.ToString();
				this.timePastLabel.Text = String.Format("{0}, {1}:{2:00}:{3:00}", 0, 0, 0, 0);

				// disable the following controls on adding new section
				this.rolesGrid.Enabled = false;
				this.propertiesHyperLink.Enabled = false;
				this.containerList.Enabled = false;
			}

//			// set portal for this section
//			try 
//			{
//				string associatedCommunities = String.Empty;
//				foreach(CommunityInfo portal in section.ConnectedCommunities)
//					associatedCommunities += String.Concat(portal.Title, ", ");
//				this.associatedLabel.Text = associatedCommunities;
//				this.associatedLabel.ForeColor = Color.Blue;
//			} 
//			catch (InformationNotFoundException) 
//			{
//				this.associatedLabel.Text = "Not Associated";
//				this.associatedLabel.ForeColor = Color.Red;
//			}
		}

		#region Events

		private void skinList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// gets styles for selected skin
			this.styleList.DataSource = Styles.GetStyles(this.skinList.SelectedItem.Text);
			this.styleList.DataBind();
		}

		private void childrenDataGrid_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// check to see if the command name was "Edit" was clicked
			switch (e.CommandName) 
			{
				case "Edit":
					Response.Redirect(Global.Path.GetPortalUrl(
						String.Format("Section.aspx?id={0}", (int)childrenDataGrid.DataKeys[e.Item.ItemIndex])).ToString());
					break;
				case "Move":
					SectionInfo oldPosition = SectionInfo.Collection[this.SectionID].Children.GetByIndex(e.Item.DataSetIndex);
					SectionInfo newPosition = null;

					if ((string)e.CommandArgument == "Up")
						newPosition = oldPosition.Parent.Children.GetByIndex(oldPosition.Order -1);
					else if ((string)e.CommandArgument == "Down")
						newPosition = oldPosition.Parent.Children.GetByIndex(oldPosition.Order +1);

					// checks to see if the new position is in the database and if it is
					// the sections will be swapped
					if (newPosition != null)
					{
						int old = oldPosition.Order;
						oldPosition.Order = newPosition.Order;
						newPosition.Order = old;

						// commit the changes to the database
						oldPosition.CommitChanges();
						newPosition.CommitChanges();
					}

					break;
			}

			this.DataBind();
		}

		private void sendButton_Click(object sender, System.EventArgs e)
		{
			this.rolesGrid.EnsureData();

			SectionInfo section = this.SectionObject;

			section.Name = this.nameTextbox.Text;
			section.Title = this.titleTextbox.Text;
			section.Visible = this.enableCheckBox.Checked;
			section.Skin = this.skinList.SelectedItem.Value;
			section.Style = this.styleList.SelectedItem.Value;
			section.OriginalOwner = this.sectionOwnerList.SelectedItem.Value;
			section.Module = (SectionModule)SectionModule.Collection[new Guid(this.pageTypeList.SelectedItem.Value)];
			
			// TODO: Add support for roles
		}

		private void addSectionButton_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(Global.Path.GetPortalUrl(
				String.Format("Section.aspx?id=-1&parentID={0}&primaryParentID={1}", SectionID, PrimaryParentID)).ToString());
		}

		private void containerList_AddItemClick(object sender, EventArgs e)
		{
			this.SectionObject.AddContainer(
				ContainerInfo.Collection[Convert.ToInt32(this.containerList.RightListSelectedItem.Value)]
				);

			this.DataBind();
		}

		private void containerList_RemoveItemClick(object sender, EventArgs e)
		{
			this.SectionObject.RemoveContainer(
				ContainerInfo.Collection[Convert.ToInt32(this.containerList.LeftListSelectedItem.Value)]
				);
			
			this.DataBind();
		}

		#endregion

		private SectionCollection GetChildren(int id) 
		{
			SectionCollection c;

			if(id == RootSection.ID) 
				c = SectionInfo.Root.Children;
			else
				c = SectionInfo.Collection[id].Children;
				
			return c;
		}

		protected override void WriteTrace()
		{
			Context.Trace.Write("Section", "SectionID = " + this.SectionID);
			Context.Trace.Write("Section", "ParentID = " + this.ParentID);
			Context.Trace.Write("Section", "PrimaryParentID = " + this.PrimaryParentID);
		}
	}
}