#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Web.UI;
using System.Collections;
using System.Collections.Specialized;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Data
{
	/// <summary>
	/// Summary description for AdminUtility.
	/// </summary>
	public class AdminUtility
	{
//		public sealed class StatisticsUtility
//		{
//			public static DataTable GetPathInfoHits () 
//			{
//				DataSet ds;
//
//				using (ProviderFactory f = new ProviderFactory()) 
//				{
//					IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select request_pathInfo, count(request_pathInfo) AS request_hits, max(request_timestamp) AS request_timestamp
//					from OmniPortal_ClientRequests
//					group by request_pathInfo
//					order by count(request_pathInfo) desc;
//				");
//
//					// read data
//					ds = new DataSet();
//					adapter.Fill(ds);
//				}
//
//				return ds.Tables[0];
//			}
//
//			public static int GetTotalPathInfoHits () 
//			{
//				DataSet ds;
//
//				using (ProviderFactory f = new ProviderFactory()) 
//				{
//					IDbDataAdapter adapter = f.CreateDataAdapter(@"
//					select count(request_pathInfo)
//					from OmniPortal_ClientRequests
//				");
//
//					// read data
//					ds = new DataSet();
//					adapter.Fill(ds);
//				}
//
//				return Convert.ToInt32(ds.Tables[0].Rows[0][0]);
//			}
//		}
//
//		public sealed class SiteUtility 
//		{
//			/// <summary>
//			/// Gets the portal that is associated with the provided site ID.
//			/// </summary>
//			/// <param name="siteID">Site ID.</param>
//			/// <returns>Returns the site of <paramref name="siteID">siteID</paramref>.</returns>
//			public static OmniPortalDataSet.CommunitiesRow GetPortalForSite (int siteID)
//			{
//				try 
//				{
//					OmniPortalDataSet.SitesRow siteRow = Global.Database.Sites.FindBysite_id(siteID);
//					OmniPortalDataSet.CommunitiesRow portalRow = (OmniPortalDataSet.CommunitiesRow)Global.Database.Communities.FindByportal_id((Guid)siteRow["portal_id"]);
//			
//					return portalRow;
//				} 
//				catch (InvalidCastException exc) 
//				{
//					throw new InformationNotFoundException(String.Concat("Portal could not be found for Site ", siteID), exc);
//				}
//			}
//
//			/// <summary>
//			/// Adds or Updates a portal in the database.
//			/// </summary>
//			/// <remarks>
//			/// Adds or Updates a portal in the database according to the <paramref name="portalID">portalID</paramref>:
//			/// <list type="table">
//			/// <listheader>
//			///		<term><see cref="System.Guid">Guid</see> Value</term>
//			///		<description>Add or Update</description>
//			/// </listheader>
//			/// <item>
//			///		<term><see cref="System.Guid.Empty">Guid.Empty</see></term>
//			///		<description>Add</description>
//			/// </item>
//			/// <item>
//			///		<term>Any other <see cref="System.Guid">Guid</see>.</term>
//			///		<description>Update</description>
//			/// </item>
//			/// </list>
//			/// </remarks>
//			/// <param name="siteID">The site ID.</param>
//			/// <param name="domain">The domain.</param>
//			/// <param name="subDomain">The sub domain.</param>
//			public static void UpdateSite (
//				int siteID,
//				string domain,
//				string subDomain)
//			{
//				OmniPortalDataSet.SitesRow row = Global.Database.Sites.NewSitesRow();
//
//				// checks to see if the row already exisits in the database;
//				if(siteID != -1)
//					row = Global.Database.Sites.FindBysite_id(siteID);
//
//				// input
//				row.site_domain = domain;
//				row.site_subDomain = subDomain;
//				row.site_touched = DateTime.Now;
//
//				// adds the row if the entry doesn't exisit already
//				if(siteID == -1)
//					Global.Database.Sites.AddSitesRow(row);
//
//				// commits changes to database
//				Database.CommitChangesToSites();
//			}
//
//			/// <summary>
//			/// Gets all available sites that have been set that haven't been used in for a site yet.
//			/// </summary>
//			/// <returns>Returns all available sites.</returns>
//			public static OmniPortalDataSet.SitesDataTable GetAllAvailableSites () 
//			{
//				OmniPortalDataSet ds = new OmniPortalDataSet();
//				ProviderHelper.FillDataset(@"
//						select	*
//						from	OmniPortal_Sites
//						where	site_id not in (select site_id from OmniPortal_CommunitiesiteLink)
//					", ds, new string[] { Database.Sites });
//
//				OmniPortalDataSet.SitesDataTable table = ds.Sites;
//
//				try 
//				{
//					table.Columns.Add("site_primaryDomain", typeof(string));
//
//					// creates full domain name
//					foreach (OmniPortalDataSet.SitesRow srow in table.Rows) 
//						srow["site_primaryDomain"] = String.Concat(srow.site_subDomain, ".", srow.site_domain);
//				} 
//				catch (DuplicateNameException) { /* Do Nothing */ }
//
//				return table;
//			}
//		}
//
//		public sealed class PortalUtility 
//		{
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="portalID"></param>
//			/// <param name="siteID"></param>
//			public static void AddSite (Guid portalID, int siteID) 
//			{
//				if (Global.Database.CommunitiesiteLink.FindBysite_id(siteID) == null) 
//				{
//					// add a new link
//					Global.Database.CommunitiesiteLink.AddCommunitiesiteLinkRow(
//						Global.Database.Communities.FindByportal_id(portalID),
//						Global.Database.Sites.FindBysite_id(siteID)
//						);
//
//					// commit changes to database
//					Database.CommitChangesToCommunitiesiteLinks();
//				}
//			}
//
//			/// <summary>
//			/// Update the portal.
//			/// </summary>
//			/// <param name="portalID">The site id.</param>
//			/// <param name="name">The name.</param>
//			/// <param name="title">The title.</param>
//			/// <param name="additionalText">Additional text.</param>
//			public static void UpdatePortal (
//				Guid portalID,
//				string name,
//				string title,
//				string additionalText)
//			{
//				OmniPortalDataSet.CommunitiesRow row = Global.Database.Communities.NewCommunitiesRow();
//
//				// check to see if the row exists
//				if(portalID != Guid.Empty)
//					row = Global.Database.Communities.FindByportal_id(portalID);
//
//				// input
//				row.portal_name = name;
//				row.portal_title = title;
//				row.portal_additionalText = additionalText;
//				row.portal_touched = DateTime.Now;
//
//				// check to see if the row should be added to the database
//				if(portalID == Guid.Empty) 
//				{
//					row.portal_id = Guid.NewGuid();
//					Global.Database.Communities.AddCommunitiesRow(row);
//				}
//
//				// commite changes to database
//				Database.CommitChangesToCommunities();
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="siteID"></param>
//			public static void RemoveSite (int siteID) 
//			{
//				if (Global.Database.CommunitiesiteLink.FindBysite_id(siteID) != null) 
//				{
//					// delete link
//					Global.Database.CommunitiesiteLink.FindBysite_id(siteID).Delete();
//
//					// commit changes to database
//					Database.CommitChangesToCommunitiesiteLinks();
//				}
//			}
//
//			/// <summary>
//			/// Gets all the sites related to a portal.
//			/// </summary>
//			/// <param name="portalID">The portal id.</param>
//			/// <returns>Returns the sites related to a portal.</returns>
//			public static DataTable GetSiteForPortal (Guid portalID)
//			{
//				OmniPortalDataSet.SitesDataTable table = (OmniPortalDataSet.SitesDataTable)Global.Database.Sites.Clone();
//				
//				try 
//				{
//					table.Columns.Add("site_primaryDomain", typeof(string));
//
//					// creates full domain name
//					foreach (OmniPortalDataSet.SitesRow srow in Global.Database.Communities.FindByportal_id(portalID).GetSitesRows()) 
//					{
//						OmniPortalDataSet.SitesRow row = table.NewSitesRow();
//						row.site_domain = srow.site_domain;
//						row.site_subDomain = srow.site_subDomain;
//						row.site_touched = srow.site_touched;
//						row["site_primaryDomain"] = String.Concat(srow.site_subDomain, ".", srow.site_domain);
//						table.AddSitesRow(row);
//					}
//				}
//				catch (DuplicateNameException) { /* Do Nothing */ } 
//				catch (System.NullReferenceException) { /* Do Nothing */ }
//
//				return table;
//			}
//
//			/// <summary>
//			/// Sets the section for the the portal.
//			/// </summary>
//			/// <param name="portalID">The portal id.</param>
//			/// <param name="sectionID">The section id.</param>
//			public static void SetSection (Guid portalID, int sectionID) 
//			{
//				OmniPortalDataSet.CommunitiesectionLinkRow row = Global.Database.CommunitiesectionLink.FindByportal_id(portalID);
//
//				if (row == null)
//					// add a new link
//					Global.Database.CommunitiesectionLink.AddCommunitiesectionLinkRow(
//						Global.Database.Communities.FindByportal_id(portalID),
//						Global.Database.Sections.FindBysection_id(sectionID)
//						);
//				else
//					// edit a link
//					row.section_id = sectionID;
//
//				// commit changes to database
//				Database.CommitChangesToCommunitiesectionLinks();
//			}
//
//			/// <summary>
//			/// Gets the section for a passed portal.
//			/// </summary>
//			/// <param name="portalID">The portal id.</param>
//			/// <returns>Returns the section information for the passed site.</returns>
//			public static SectionInfo GetSectionForPortal (Guid portalID) 
//			{
//				SectionInfo info;
//
//				try 
//				{
//					info = CommunityInfo.GetCommunityInfo(portalID).ConnectedSection;
//				}
//				catch (ArgumentNullException exc) 
//				{
//					throw new InformationNotFoundException(String.Format("Could not find a section associated with Portal {0}.", portalID), exc);
//				}
//
//				// returns the linked section
//				return info;
//			}
//		}
//
//		public sealed class ErrorUtility 
//		{
//			/// <summary>
//			/// Get all errors in the database.
//			/// </summary>
//			/// <returns>Returns a table of all errors in database.</returns>
//			public static DataTable GetAllErrors () 
//			{
//				DataSet ds;
//
//				using (ProviderFactory f = new ProviderFactory()) 
//				{
//					IDbDataAdapter adapter = f.CreateDataAdapter(@"
//						select	error_message, Count(error_id) AS error_count, Max(error_occurrence) AS error_occurrence
//						from	OmniPortal_Errors
//						group by error_message
//						order by Max(error_occurrence) desc
//					");
//
//					// read data
//					ds = new DataSet();
//					adapter.Fill(ds);
//				}
//
//				return ds.Tables[0];
//			}
//		}
//
//		public sealed class ContainerUtility 
//		{
//			/// <summary></summary>
//			/// <returns></returns>
//			public static DataRow[] GetContainersForSection (int sectionID) 
//			{
//				return Global.Database.SectionContainerLink.Select(String.Concat("section_id = ", sectionID.ToString()));
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <returns></returns>
//			public static DataTable GetAllContainers () 
//			{
//				return Global.Database.Containers;
//			}
//
//			/// <summary></summary>
//			/// <param name="containerID"></param>
//			/// <returns></returns>
//			public static DataRow GetContainerInfo (int containerID) 
//			{
//				return Global.Database.Containers.Select(String.Concat("container_id = ", containerID))[0];
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <returns></returns>
//			public static DataRow[] GetContainersNotInSection (int sectionID) 
//			{
//				ArrayList list = new ArrayList();
//				int[] containers;
//
//				// get portlet id's associated with the container id
//				foreach (DataRow row in Global.Database.SectionContainerLink.Select(String.Concat("section_id = ", sectionID.ToString()))) 
//					list.Add(row["container_id"]);
//
//				// set the portlets that are linked to the container id
//				containers = (int[])list.ToArray(typeof(int));
//				list = new ArrayList();
//
//				// get portlets not associated with the container id
//				foreach (DataRow row in Global.Database.Containers.Rows) 
//					if (Array.BinarySearch(containers, row["container_id"]) < 0)
//						list.Add(row);
//
//				// returns a list of DataRow[] that aren't linked to the container id
//				return (DataRow[])list.ToArray(typeof(DataRow));
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="containerID"></param>
//			/// <returns></returns>
//			public static DataRow[] GetAllLinkedPortlets(int containerID) 
//			{
//				ArrayList list = new ArrayList();
//				int[] portlets;
//
//				// get portlet id's associated with the container id
//				foreach (DataRow row in Global.Database.ContainerPortletLink.Select(String.Concat("container_id = ", containerID))) 
//					list.Add(row["portlet_id"]);
//
//				// set the portlets that are linked to the container id
//				portlets = (int[])list.ToArray(typeof(int));
//				list = new ArrayList();
//
//				// get portlets not associated with the container id
//				foreach (DataRow row in Global.Database.Portlets.Rows) 
//					if (Array.BinarySearch(portlets, row["portlet_id"]) >= 0)
//						list.Add(row);
//
//				// returns a list of DataRow[] that aren't linked to the container id
//				return (DataRow[])list.ToArray(typeof(DataRow));
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="containerID"></param>
//			/// <returns></returns>
//			public static DataRow[] GetAllAvailablePortlets (int containerID) 
//			{
//				ArrayList list = new ArrayList();
//				int[] portlets;
//
//				// get portlet id's associated with the container id
//				foreach (DataRow row in Global.Database.ContainerPortletLink.Select(String.Concat("container_id = ", containerID))) 
//					list.Add(row["portlet_id"]);
//
//				// set the portlets that are linked to the container id
//				portlets = (int[])list.ToArray(typeof(int));
//				list = new ArrayList();
//
//				// get portlets not associated with the container id
//				foreach (DataRow row in Global.Database.Portlets.Rows) 
//					if (Array.BinarySearch(portlets, row["portlet_id"]) < 0)
//						list.Add(row);
//
//				// returns a list of DataRow[] that aren't linked to the container id
//				return (DataRow[])list.ToArray(typeof(DataRow));
//			}
//
//			/// <summary>
//			/// Adds a portlet to a container.
//			/// </summary>
//			/// <param name="containerID">The containers id.</param>
//			/// <param name="portletID">The portlets id.</param>
//			public static void AddPortlet (int containerID, int portletID) 
//			{
//				// check to see if link already exisits
//				if(Global.Database.ContainerPortletLink.FindBycontainer_idportlet_id(containerID, portletID) == null) 
//				{
//					// add link to database
//					Global.Database.ContainerPortletLink.AddContainerPortletLinkRow(
//						Global.Database.Containers.FindBycontainer_id(containerID),
//						Global.Database.Portlets.FindByportlet_id(portletID)
//						);
//
//					// commit to database
//					Database.CommitChangesToContainerPortletLinks();
//				}
//			}
//
//			/// <summary>
//			/// Removes the portlet from the container.
//			/// </summary>
//			/// <param name="containerID">The containers id.</param>
//			/// <param name="portletID">The portlets id.</param>
//			public static void RemovePortlet (int containerID, int portletID)
//			{
//				// check to see if link exisits
//				if(Global.Database.ContainerPortletLink.FindBycontainer_idportlet_id(containerID, portletID) != null) 
//				{
//					// delete link in database
//					Global.Database.ContainerPortletLink.FindBycontainer_idportlet_id(containerID, portletID).Delete();
//
//					// commit to database
//					Database.CommitChangesToContainerPortletLinks();
//				}
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="containerID"></param>
//			/// <param name="name"></param>
//			/// <param name="position"></param>
//			public static void UpdateContainer (int containerID, string name, string position) 
//			{
//				OmniPortalDataSet.ContainersRow row = Global.Database.Containers.NewContainersRow();
//
//				// get container if it exisits
//				if (containerID != -1)
//					row = Global.Database.Containers.FindBycontainer_id(containerID);
//
//				row.container_name = name;
//				row.container_position = position;
//				row.container_touched = DateTime.Now;
//				
//				// add container if it doesn't exisit already
//				if (containerID == -1)
//					Global.Database.Containers.AddContainersRow(row);
//
//				// commit changes to database
//				Database.CommitChangesToContainers();
//			}
//		}
//		public sealed class PortletUtility 
//		{
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <returns></returns>
//			public static DataRow[] GetAllPortlets () 
//			{
//				return Global.Database.Portlets.Select();
//			}
//
//			/// <summary>
//			/// Gets all portlet types.
//			/// </summary>
//			/// <returns>Returns a list of all portlet types.</returns>
//			public static DataRow[] GetAllPortletTypes () 
//			{
//				return Global.Database.PortletTypes.Select();
//			}
//
//			/// <summary>
//			/// Gets the information for the portlet.
//			/// </summary>
//			/// <param name="portletID">The portlet id.</param>
//			/// <returns>Returns the information of the portlet.</returns>
//			public static DataRow GetPortletInfo (int portletID) 
//			{
//				return Global.Database.Portlets.Select(String.Concat("portlet_id = ", portletID.ToString()))[0];
//			}
//
//			/// <summary>
//			/// Update the portlet.
//			/// </summary>
//			/// <param name="portletID">The portlet id.</param>
//			/// <param name="title">The title of the portlet.</param>
//			/// <param name="type">The portlet type.</param>
//			public static void UpdatePortlet (int portletID, string title, Guid type) 
//			{
//				OmniPortalDataSet.PortletsRow row = Global.Database.Portlets.NewPortletsRow();
//
//				// checks to see if the portlet exisits
//				if(portletID != -1)
//					row = Global.Database.Portlets.FindByportlet_id(portletID);
//
//				// input
//				row.portlet_title = title;
//				row.portlet_type = type;
//				row.portlet_touched = DateTime.Now;
//
//				// checks to see if the portlet should be added
//				if(portletID == -1)
//					Global.Database.Portlets.AddPortletsRow(row);
//
//				// commit changes to database
//				Database.CommitChangesToPortlets();
//			}
//		}
//		public sealed class SectionUtility 
//		{
//			/// <summary>
//			/// Gets the sections that have a specific page type.
//			/// </summary>
//			/// <param name="pageType">The page type to check.</param>
//			/// <returns>Returns the sections for the page type.</returns>
//			public static DataRow[] GetSectionsRowPageType (Guid pageType) 
//			{
//				return Global.Database.Sections.Select(String.Format("section_pageType = '{0:D}'", pageType));
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="sectionID"></param>
//			/// <returns></returns>
//			public static OmniPortalDataSet.CommunitiesRow GetPortalForSection (int sectionID) 
//			{
//				OmniPortalDataSet.CommunitiesRow row;
//
//				try 
//				{
//					OmniPortalDataSet.SectionsRow sectionRow = Global.Database.Sections.FindBysection_id(sectionID);
//					row = Global.Database.Communities.FindByportal_id((Guid)sectionRow["portal_id"]);
//
//					// check to see if the row was found
//					if (row == null)
//						throw new NullReferenceException();
//				} 
//				catch (InvalidCastException)
//				{
//					throw new InformationNotFoundException(String.Format("Could not find a portal associated with Section {0}.", sectionID));
//				}
//				catch (NullReferenceException) 
//				{
//					throw new SectionNotFoundException(sectionID);
//				}
//
//				return row;
//			}
//
//			/// <summary>
//			/// Gets all available sections that have been set that haven't been used in for a site yet.
//			/// </summary>
//			/// <returns>Returns all available sections.</returns>
//			public static DataTable GetAllAvailableSections () 
//			{
//				DataSet ds;
//
//				using (ProviderFactory f = new ProviderFactory()) 
//				{
//					IDbDataAdapter adapter = f.CreateDataAdapter(@"
//						select	*
//						from	OmniPortal_Sections
//						where	section_id not in (select section_id from OmniPortal_CommunitiesectionLink);
//
//					");
//
//					// read data
//					ds = new DataSet();
//					adapter.Fill(ds);
//				}
//
//				return ds.Tables[0];
//			}
//
//			/// <summary>
//			/// Adds a container to a section.
//			/// </summary>
//			/// <param name="sectionID">The section id.</param>
//			/// <param name="containerID">The container id.</param>
//			public static void AddContainer (int sectionID, int containerID) 
//			{
//				// check to see if link already exisits
//				if(Global.Database.SectionContainerLink.FindBysection_idcontainer_id(sectionID, containerID) == null) 
//				{
//					// add link to database
//					Global.Database.SectionContainerLink.AddSectionContainerLinkRow(
//						Global.Database.Sections.FindBysection_id(sectionID),
//						Global.Database.Containers.FindBycontainer_id(containerID)
//						);
//
//					// commit to database
//					Database.CommitChangesToSectionContainerLinks();
//				}
//			}
//
//			/// <summary>
//			/// Removes the contianer from the section.
//			/// </summary>
//			/// <param name="sectionID">The section id.</param>
//			/// <param name="containerID">The container id.</param>
//			public static void RemoveContainer (int sectionID, int containerID)
//			{
//				// check to see if link exisits
//				if(Global.Database.SectionContainerLink.FindBysection_idcontainer_id(sectionID, containerID) != null) 
//				{
//					// delete link from database
//					Global.Database.SectionContainerLink.FindBysection_idcontainer_id(sectionID, containerID).Delete();
//
//					// commit to database
//					Database.CommitChangesToSectionContainerLinks();
//				}
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="sectionID"></param>
//			/// <param name="name"></param>
//			/// <param name="title"></param>
//			/// <param name="description"></param>
//			/// <param name="keywords"></param>
//			/// <param name="primaryParentID"></param>
//			/// <param name="parentID"></param>
//			/// <param name="enabled"></param>
//			/// <param name="skin"></param>
//			/// <param name="style"></param>
//			/// <param name="owner"></param>
//			/// <param name="pageType"></param>
//			/// <param name="viewRoles"></param>
//			/// <param name="addRoles"></param>
//			/// <param name="editRoles"></param>
//			/// <param name="deleteRoles"></param>
//			public static void UpdateSection (
//				int sectionID,
//				string name,
//				string title,
//				string description,
//				string keywords,
//				int primaryParentID,
//				int parentID,
//				bool enabled,
//				string skin,
//				string style,
//				string owner,
//				Guid pageType,
//				Hashtable roles) 
//			{
//				int order = 0;
//				OmniPortalDataSet.SectionsRow row = Global.Database.Sections.NewSectionsRow();
//
//				// checks to see if this is going to be a primary section if it is the
//				// the primary parent id will also equal the section id
//				if (primaryParentID == -1)
//					primaryParentID = sectionID;
//
//				// checks to see if this section should be updated
//				if (sectionID != -1) 
//				{
//					row = Global.Database.Sections.FindBysection_id(sectionID);
//
//					// sets the order of the current section
//					order = row.section_order;
//				}
//				else // (sectionID == -1)
//				{
//					// gets the next order value by selecting all the sections with a parent id equal to the parentID
//					// this is possible to do because the section_order is zero based so the number of sections currently
//					// in the parent id will be the next section_order number.
//					order = Global.Database.Sections.Select(String.Concat("section_parentID = ", parentID.ToString())).Length; 
//				}
//
//				// input
//				row.section_name = name;
//				row.section_title = title;
//				row.section_description = description;
//				row.section_keywords = keywords;
//				row.section_robots = "index,follow";
//				row.section_rating = "general";
//				row.section_revisitAfter = 1;
//				row.section_primaryParentID = primaryParentID;
//				row.section_parentID = parentID;
//				row.section_order = order;
//				row.section_visible = enabled;
//				row.section_originalSkin = skin;
//				row.section_originalStyle = style;
//				row.section_originalOwner = owner;
//				row.section_pageType = pageType;
//				row.section_touched = DateTime.Now;
//
//				// adds the row if it is a new row
//				if (sectionID == -1)
//					Global.Database.Sections.AddSectionsRow(row);
//				else 
//					// else it updates the roles because the section_id is needed
//					foreach(DictionaryEntry entry in roles) 
//						UpdateSectionRoles(row.section_id, (string)entry.Key, (string)entry.Value);
//
//				// commits the changes to the database
//				Database.CommitAllChangesToDatabase();
//			}
//
//			private static void UpdateSectionRoles (int sectionID, string role, string permissions) 
//			{
//				OmniPortalDataSet.SectionRolesRow row = Global.Database.SectionRoles.FindBysection_idrole_id(sectionID, role);
//				bool newRow = (row == null);
//
//				if (newRow)
//					row = Global.Database.SectionRoles.NewSectionRolesRow();
//
//				// input
//				row.section_id = sectionID;
//				row.role_id = role;
//				row.role_permissions = permissions;
//
//				if (newRow)
//					Global.Database.SectionRoles.AddSectionRolesRow(row);
//			}
//
//			/// <summary>
//			/// 
//			/// </summary>
//			/// <param name="id"></param>
//			/// <param name="order"></param>
//			public static void SwapSectionOrders (int oldPosition, int newPosition) 
//			{
//				OmniPortalDataSet.SectionsRow oldRow = Global.Database.Sections.FindBysection_id(oldPosition);
//				OmniPortalDataSet.SectionsRow newRow = Global.Database.Sections.FindBysection_id(newPosition);
//				int oldOrder = oldRow.section_order;
//
//				// swaps the order of the secions
//				oldRow.section_order = newRow.section_order;
//				newRow.section_order = oldOrder;
//
//				// commit changes to database
//				Database.CommitChangesToSections();
//			}
//		}
	}
}