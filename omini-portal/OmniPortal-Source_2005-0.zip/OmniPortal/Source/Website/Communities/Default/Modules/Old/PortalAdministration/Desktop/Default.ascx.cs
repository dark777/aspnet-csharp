#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// ManagedFusion Classes
using ManagedFusion;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	public class Default : System.Web.UI.UserControl
	{
		private void Page_Load (Object sender, EventArgs e)
		{
			Global.PageBuilder.FramesetMode = true;
		}
	
		private void Page_UnLoad (Object sender, EventArgs e)
		{
			Global.PageBuilder.FramesetMode = false;
		}

		override protected void OnInit(EventArgs e)
		{
			this.Load += new EventHandler(Page_Load);
			this.Unload += new EventHandler(Page_UnLoad);
			base.OnInit(e);
		}
	}
}