#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

// OmniPortal Classes
using OmniPortal.Authentication;
using OmniPortal.Display;
using OmniPortal.Display.Modules;
using OmniPortal.Components.Modules.PortalAdministration.Data;

namespace OmniPortal.Components.Modules.PortalAdministration.Desktop
{
	/// <summary>
	///	Summary description for Statistics.
	/// </summary>
//	[ModuleAdmin("Statistics.aspx", "Site Statistics", "This page contains all the statistics about the site that are cataloged for every client browser that accesses the site.", Options=Permissions.Modify)]
	public class Statistics : SkinnedUserControl
	{
		protected System.Web.UI.WebControls.DataGrid pageHitGrid;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Page.IsPostBack == false)
				this.DataBind();
		}
		
		/// <summary>
		///	Required method for Designer support - do not modify
		///	the contents of this method with the code editor.
		/// </summary>
		protected override void OnInit(EventArgs e)
		{
			this.Load += new System.EventHandler(this.Page_Load);
		
			base.OnInit (e);
		}

		public override void DataBind()
		{
			this.pageHitGrid.DataSource = CreatePageHitDataSource();

			base.DataBind ();
		}

		private DataTable CreatePageHitDataSource () 
		{
			DataTable table = AdminUtility.StatisticsUtility.GetPathInfoHits();

			int total = AdminUtility.StatisticsUtility.GetTotalPathInfoHits();

			table.Columns[0].ColumnName = "Page";
			table.Columns[1].ColumnName = "Hits";
			table.Columns.Add("Percentage", typeof(string));

			double percentage = 0;

			// get percentage for each page hit
			foreach(DataRow row in table.Rows) 
			{
				row["Page"] = String.Format("<a href=\"{0}\" target=\"_blank\">{0}</a>", Global.GetRelativeUrl((string)row["Page"]));

				percentage = Convert.ToDouble((int)row["Hits"])/Convert.ToDouble(total);
				row["Percentage"] = percentage.ToString("P");
			}
		
			return table;
		}
	}
}