-- //// Select All Stored procedure.
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Authenticate]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[User_Authenticate]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select an existing row from the table 'User_Users'
-- based on the Primary Key.
-- Gets: @user_id int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[User_Authenticate]
	@Email nvarchar(64),
	@Password nvarchar(32),
	@ErrorCode int OUTPUT,
	@Authenticated bit OUTPUT
AS
SET NOCOUNT ON
-- SELECT an existing row from the table.
if exists (SELECT * FROM [dbo].[User_Users] WHERE [Email] = @Email and [Password] = @Password)
	-- User has been authenticated
	select @Authenticated = 1
else
	-- User has not been authenticated
	select @Authenticated = 0

-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO

-- //// Select All Stored procedure.
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[User_Roles_GetAllForEmail]') and OBJECTPROPERTY(id, N'IsProcedure') = 1) drop procedure [dbo].[User_Roles_GetAllForEmail]
GO

---------------------------------------------------------------------------------
-- Stored procedure that will select an existing row from the table 'Module_Users'
-- based on the Primary Key.
-- Gets: @user_id int
-- Returns: @ErrorCode int
---------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[User_Roles_GetAllForEmail]
	@Email nvarchar(64),
	@ErrorCode int OUTPUT
AS
SET NOCOUNT ON
-- SELECT an existing row from the table.
SELECT 
	[roles].[Name]
FROM ([dbo].[User_Users] users left join [dbo].[User_UsersInRoles] uir
	on [users].[ID] = [uir].[User_ID]) left join [dbo].[User_Roles] roles
	on [uir].[Role_ID] = [roles].[ID]
WHERE [users].[Email] = @Email

-- Get the Error Code for the statement just executed.
SELECT @ErrorCode=@@ERROR
GO