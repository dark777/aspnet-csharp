#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Collections;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Providers;
using OmniPortal.Components.Authentication.Form;

namespace OmniPortal.Components.Data.SqlServer
{
	[Provider("OmniPortalSqlServer")]
	public class FormAuthenticationSqlServerProvider : FormAuthenticationProvider
	{
		public override string[] AllRoles
		{
			get 
			{
				if (Global.Cache.IsCached(AllRolesCacheKey, String.Empty) == false) 
				{
					User_Roles dbroles = new User_Roles();
					DataTable table = dbroles.SelectAll();

					// add all roles into string collection
					ArrayList roles = new ArrayList(table.Rows.Count);
					foreach(DataRow row in table.Rows) 
						roles.Add((string)row["Name"]);

					Global.Cache.Add(AllRolesCacheKey, String.Empty, roles.ToArray(typeof(string)));
				}

				// return cached roles
				return (string[])Global.Cache[AllRolesCacheKey, String.Empty];
			}
		}

		public override bool ValidateUser(string email, string password)
		{
			#region Code in Module_Users
/* This is to protect the code incase the file gets automatically overwritten
			SqlCommand	cmdToExecute = new SqlCommand();
			cmdToExecute.CommandText = "dbo.[Module_Users_Authenticate]";
			cmdToExecute.CommandType = CommandType.StoredProcedure;
			bool toReturn = false;
			SqlDataAdapter adapter = new SqlDataAdapter(cmdToExecute);

			// Use base class' connection object
			cmdToExecute.Connection = new SqlConnection(Global.Config.Provider.ConnectionString);

			try
			{
				cmdToExecute.Parameters.Add(new SqlParameter("@user_name", SqlDbType.NVarChar, 16, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Proposed, _user_name));
				cmdToExecute.Parameters.Add(new SqlParameter("@user_password", SqlDbType.NVarChar, 32, ParameterDirection.Input, false, 0, 0, "", DataRowVersion.Proposed, _user_password));

				if(_mainConnectionIsCreatedLocal)
				{
					// Open connection.
					_mainConnection.Open();
				}
				else
				{
					if(_mainConnectionProvider.IsTransactionPending)
					{
						cmdToExecute.Transaction = _mainConnectionProvider.CurrentTransaction;
					}
				}

				// Execute query.
				adapter.Fill(toReturn);
				_errorCode = (Int32)cmdToExecute.Parameters["@ErrorCode"].Value;
				toReturn = (bool)cmdToExecute.Parameters["@Authenticated"].Value;

				if(_errorCode != (int)LLBLError.AllOk)
				{
					// Throw error.
					throw new Exception("Stored Procedure 'Module_Users_Authenticate' reported the ErrorCode: " + _errorCode);
				}

				return toReturn;
			}
			catch(Exception ex)
			{
				// some error occured. Bubble it to caller and encapsulate Exception object
				throw new Exception("Module_Users::SelectOne::Error occured.", ex);
			}
			finally
			{
				if(_mainConnectionIsCreatedLocal)
				{
					// Close connection.
					_mainConnection.Close();
				}
				cmdToExecute.Dispose();
				adapter.Dispose();
			}
*/
			#endregion

			Users user = new Users();
			user.Email = email;
			user.Password = password;

			try 
			{
				return user.Authenticate();
			} 
			catch (Exception) 
			{
				return false;
			}
		}

		protected override string[] GetUsersRolesFromDB(string email)
		{
			ArrayList roles = new ArrayList();
			Users user = new Users();
			user.Email = email;

			try 
			{
				DataTable table = user.GetRolesForUser();
			
				foreach(DataRow row in table.Rows)
					roles.Add((string)row["Name"]);

				return (string[])roles.ToArray(typeof(string));
			} 
			catch (Exception) 
			{
				return new string[0];
			}
		}
	}
}