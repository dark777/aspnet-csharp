#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Display.Modules;
using OmniPortal.Components.Common;

using Atom.Core;

namespace OmniPortal.Components.Modules.Static
{
	[Module("Static Page", 
			"The static module is used inorder to display static content to the page.", 
			"{8B61FD65-C060-46f2-AC29-5A4669D010AC}",
			false,
			"OmniPortal.Components.Modules.Static.Module.config")]
	public class StaticModule : ModuleBase
	{
		protected override void OnLoadSyndication(LoadSyndicationEventArgs e)
		{
			// add the item
			AtomEntry entry = new AtomEntry();
			entry.Author = new AtomPersonConstruct("author", "Unknown");
			entry.Title = new AtomContentConstruct("title", this.SectionInformation.Title);
			entry.Links.Add(new AtomLink(this.SectionInformation.UrlPath, Relationship.Alternate, MediaType.TextHtml));
			entry.Id = this.SectionInformation.UrlPath;
			entry.Modified = new AtomDateConstruct("modified", this.SectionInformation.Touched);
			entry.Issued = new AtomDateConstruct("issued", DateTime.Now);
			entry.Contents.Add(new AtomContent(this.Properties["Content"], MediaType.TextHtml, Mode.Escaped));

			// add entry to the feed
			e.Feed.Entries.Add(entry);
		}

		protected override void OnLoad(LoadModuleEventArgs e)
		{
#if DEEP
			Context.Trace.Write("StaticModule", "QueryString Edit Present: " + (Context.Request.QueryString["edit"] != null));
#endif
			// checks to see if user is an administrator and is in edit mode
			if (Context.Request.QueryString["edit"] != null && IsInTasks("Editor"))
				e.Center.Controls.Add(new Edit());
			else 
			{
				// add edit button for users with access to edit
				if (IsInTasks("Editor"))
				{
					HyperLink editLink = new HyperLink();
					editLink.Text = "Edit This Page's Content";
					editLink.NavigateUrl = Global.Path.GetPortalUrl("Edit.aspx").ToString();

					// add link to page
					e.Center.Controls.AddAt(0, editLink);
				}

				// add body of page
				e.Center.Controls.Add(new LiteralControl(this.Properties["Content"]));
			}
		}
	}
}