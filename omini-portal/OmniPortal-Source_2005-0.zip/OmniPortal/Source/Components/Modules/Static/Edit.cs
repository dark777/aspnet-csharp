#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;
using ManagedFusion.Display;
using ManagedFusion.Display.Modules;

using OmniPortal.Components.Controls;

namespace OmniPortal.Components.Modules.Static
{
	/// <summary>
	/// Summary description for Edit.
	/// </summary>
	[ModuleAdmin("Edit.aspx", "Static Page", "Used to change the content of a static page with a WYSIWYG Editor")]
	public class Edit : SkinnedUserControl
	{
		protected FCKeditor contentTextBox;
		protected Button saveButton;

		protected override void OnInit(EventArgs e)
		{
			contentTextBox = new FCKeditor();
			contentTextBox.ID = "contentTextBox";
			saveButton = new Button();
			saveButton.ID = "saveButton";

			// set styles
			contentTextBox.Width = Unit.Percentage(100D);
			contentTextBox.Height = Unit.Pixel(600);
			contentTextBox.BasePath = "/aspnet_client/FCKeditor/";

			// check to see if content has been defined
			if (Properties["Content"] != null)
				contentTextBox.Text = Properties["Content"];

			// setup save button
			saveButton.Text = "Save Page Contents";
			saveButton.Click += new EventHandler(contentTextBox_SaveClick);			

			// add to page
			this.Controls.Add(saveButton);
			this.Controls.Add(contentTextBox);

			base.OnInit (e);
		}

		private void contentTextBox_SaveClick (object sender, EventArgs e) 
		{
			Properties.Add("Content", contentTextBox.Text);
			
			// go back to original page
			Response.Redirect(Global.Path.GetPortalUrl("Default.aspx").ToString());
		}
	}
}