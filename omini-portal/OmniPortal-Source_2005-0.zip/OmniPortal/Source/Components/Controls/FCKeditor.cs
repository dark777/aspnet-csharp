/*
 * FCKeditor - The text editor for internet
 * Copyright (C) 2003-2004 Frederico Caldeira Knabben
 * 
 * Licensed under the terms of the GNU Lesser General Public License:
 * 		http://www.opensource.org/licenses/lgpl-license.php
 * 
 * For further information visit:
 * 		http://www.fckeditor.net/
 * 
 * File Name: FCKeditor.cs
 * 	This is the FCKeditor Asp.Net control.
 * 
 * Version:  2.0 RC1
 * Modified: 2004-11-26 18:07:22
 * 
 * File Authors:
 * 		Frederico Caldeira Knabben (fredck@fckeditor.net)
 */

using System ;
using System.Web.UI ;
using System.Web.UI.WebControls ;
using System.ComponentModel ;
using System.Text.RegularExpressions ;
using System.Globalization ;
using System.Security.Permissions ;

namespace OmniPortal.Components.Controls
{
	public enum LanguageDirection
	{
		LeftToRight,
		RightToLeft
	}
	
	[ DefaultProperty("Text") ]
	[ ValidationProperty("Text") ]
	[ ToolboxData("<{0}:FCKeditor runat=server></{0}:FCKeditor>") ]
	[ Designer(typeof(OmniPortal.Components.Controls.Designers.FCKeditorDesigner)) ]
	[ ParseChildren(false) ]
	[ PermissionSet(SecurityAction.Demand, Name="FullTrust") ]
	public class FCKeditor : WebControl, IPostBackDataHandler, IPostBackEventHandler, INamingContainer
	{
		private FCKeditorConfigurations oConfig ;

		#region Events

		public event EventHandler SaveClick;

		protected void OnSaveClick (EventArgs e) 
		{
			if (SaveClick != null)
				SaveClick(this, e);
		}

		public event EventHandler TextChanged;

		protected virtual void OnTextChanged(EventArgs e) 
		{
			if (TextChanged != null)
				TextChanged(this,e);
		}

		#endregion

		public FCKeditor()
		{
			oConfig = new FCKeditorConfigurations() ;
			this.Width = Unit.Percentage(100D);
			this.Height = Unit.Pixel(200);
		}

		#region Base Configurations Properties
		
		[ Browsable( false ) ]
		public FCKeditorConfigurations Config
		{
			get { return oConfig ; }
		}

		[ DefaultValue( "" ) ]
		public string Text
		{
			get { return (string)IsNull( ViewState["Text"], "" ) ; }
			set { ViewState["Text"] = value ; }
		}

		/// <summary>
		/// <p>
		///		Sets or gets the virtual path to the editor's directory. It is
		///		relative to the current page.
		/// </p>
		/// <p>
		///		The default value is "/FCKeditor/".
		/// </p>
		/// <p>
		///		The base path can be also set in the Web.config file using the 
		///		appSettings section. Just set the "FCKeditor:BasePath" for that. 
		///		For example:
		///		<code>
		///		&lt;configuration&gt;
		///			&lt;appSettings&gt;
		///				&lt;add key="FCKeditor:BasePath" value="/scripts/FCKeditor/" /&gt;
		///			&lt;/appSettings&gt;
		///		&lt;/configuration&gt;
		///		</code>
		/// </p>
		/// </summary>
		[ DefaultValue( "/aspnet_client/FCKeditor/" ) ]
		public string BasePath
		{
			get 
			{ 
				if ( ViewState["BasePath"] == null )
				{
					return (string)IsNull(
						System.Configuration.ConfigurationSettings.AppSettings["FCKeditor:BasePath"],
						"/aspnet_client/FCKeditor/" ) ;
				}
				else
					return (string)ViewState["BasePath"] ; 
			}
			set { ViewState["BasePath"] = value ; }
		}

		[ DefaultValue( "Default" ) ]
		public string ToolbarSet
		{
			get { return (string)IsNull( ViewState["ToolbarSet"], "Default" ) ; }
			set { ViewState["ToolbarSet"] = value ; }
		}

		#endregion

		#region Configurations Properties

		[ Category("Configurations") ]
		public string CustomConfigurationsPath
		{
			set { this.Config["CustomConfigurationsPath"] = value ; }
		}

		[ Category("Configurations") ]
		public string EditorAreaCSS
		{
			set { this.Config["EditorAreaCSS"] = value ; }
		}

		[ Category("Configurations") ]
		public string BaseHref
		{
			set { this.Config["BaseHref"] = value ; }
		}

		[ Category("Configurations") ]
		public string SkinPath
		{
			set { this.Config["SkinPath"] = value ; }
		}

		[ Category("Configurations") ]
		public string PluginsPath
		{
			set { this.Config["PluginsPath"] = value ; }
		}

		[ Category("Configurations") ]
		public bool FullPage
		{
			set { this.Config["FullPage"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool Debug
		{
			set { this.Config["Debug"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool AutoDetectLanguage
		{
			set { this.Config["AutoDetectLanguage"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public string DefaultLanguage
		{
			set { this.Config["DefaultLanguage"] = value ; }
		}

		[ Category("Configurations") ]
		public LanguageDirection ContentLangDirection
		{
			set { this.Config["ContentLangDirection"] = ( value == LanguageDirection.LeftToRight ? "ltr" : "rtl" )  ; }
		}

		[ Category("Configurations") ]
		public bool EnableXHTML
		{
			set { this.Config["EnableXHTML"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool EnableSourceXHTML
		{
			set { this.Config["EnableSourceXHTML"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool FillEmptyBlocks
		{
			set { this.Config["FillEmptyBlocks"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool FormatSource
		{
			set { this.Config["FormatSource"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool FormatOutput
		{
			set { this.Config["FormatOutput"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public string FormatIndentator
		{
			set { this.Config["FormatIndentator"] = value ; }
		}

		[ Category("Configurations") ]
		public bool GeckoUseSPAN
		{
			set { this.Config["GeckoUseSPAN"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool StartupFocus
		{
			set { this.Config["StartupFocus"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool ForcePasteAsPlainText
		{
			set { this.Config["ForcePasteAsPlainText"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool ForceSimpleAmpersand
		{
			set { this.Config["ForceSimpleAmpersand"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public int TabSpaces
		{
			set { this.Config["TabSpaces"] = value.ToString() ; }
		}

		[ Category("Configurations") ]
		public bool UseBROnCarriageReturn
		{
			set { this.Config["UseBROnCarriageReturn"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool ToolbarStartExpanded
		{
			set { this.Config["ToolbarStartExpanded"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public bool ToolbarCanCollapse
		{
			set { this.Config["ToolbarCanCollapse"] = ( value ? "true" : "false" ) ; }
		}

		[ Category("Configurations") ]
		public string FontColors
		{
			set { this.Config["FontColors"] = value ; }
		}

		[ Category("Configurations") ]
		public string FontNames
		{
			set { this.Config["FontNames"] = value ; }
		}

		[ Category("Configurations") ]
		public string FontSizes
		{
			set { this.Config["FontSizes"] = value ; }
		}

		[ Category("Configurations") ]
		public string FontFormats
		{
			set { this.Config["FontFormats"] = value ; }
		}

		[ Category("Configurations") ]
		public string StylesXmlPath
		{
			set { this.Config["StylesXmlPath"] = value ; }
		}

		[ Category("Configurations") ]
		public string LinkBrowserURL
		{
			set { this.Config["LinkBrowserURL"] = value ; }
		}

		[ Category("Configurations") ]
		public string ImageBrowserURL
		{
			set { this.Config["ImageBrowserURL"] = value ; }
		}

		#endregion

		#region Rendering

		protected override void Render(HtmlTextWriter writer)
		{
			writer.WriteFullBeginTag("div");
			writer.WriteLine();
			writer.Indent++;

			if ( this.CheckBrowserCompatibility() )
			{
				string sLink = this.BasePath ;
				if ( sLink.StartsWith( "~" ) )
					sLink = this.ResolveUrl( sLink ) ;

				sLink = this.BasePath + "editor/fckeditor.html?InstanceName=" + this.ClientID ;
				if ( this.ToolbarSet.Length > 0 ) sLink += "&Toolbar=" + this.ToolbarSet ;

				// Render the linked hidden field.
				writer.Write( 
					"<input type=\"hidden\" id=\"{0}\" name=\"{1}\" value=\"{2}\">",
						this.ClientID,
						this.UniqueID,
					System.Web.HttpUtility.HtmlEncode( this.Text ) ) ;
				writer.WriteLine();

				// Render the configurations hidden field.
				writer.Write( 
					"<input type=\"hidden\" id=\"{0}___Config\" value=\"{1}\">",
						this.ClientID,
						this.Config.GetHiddenFieldString() ) ;
				writer.WriteLine();

				// Render the editor IFRAME.
				writer.Write(
					"<iframe id=\"{0}___Frame\" src=\"{1}\" width=\"{2}\" height=\"{3}\" frameborder=\"no\" scrolling=\"no\"></iframe>",
						this.ClientID,
						sLink,
						this.Width,
						this.Height ) ;
				writer.WriteLine();
			}
			else
			{
				writer.Write(
					"<textarea name=\"{0}\" rows=\"4\" cols=\"40\" style=\"width: {1}; height: {2}\" wrap=\"virtual\">{3}</textarea>",
						this.UniqueID,
						this.Width,
						this.Height,
					System.Web.HttpUtility.HtmlEncode( this.Text ) ) ;
				writer.WriteLine();
			}

			writer.Indent--;
			writer.WriteEndTag("div");
		}

		public bool CheckBrowserCompatibility()
		{
			System.Web.HttpBrowserCapabilities oBrowser = Page.Request.Browser ;

			// Internet Explorer 5.5+ for Windows
			if (oBrowser.Browser == "IE" && ( oBrowser.MajorVersion >= 6 || ( oBrowser.MajorVersion == 5 && oBrowser.MinorVersion >= 0.5 ) ) && oBrowser.Win32)
				return true ;
			else
			{
				Match oMatch = Regex.Match( this.Page.Request.UserAgent, @"(?<=Gecko/)\d{8}" ) ;
				return ( oMatch.Success && int.Parse( oMatch.Value, CultureInfo.InvariantCulture ) >= 20030210 ) ;
			}
		}

		protected override void OnPreRender(EventArgs e)
		{
			if ((this.Page != null) && this.Enabled)
			{
				this.Page.RegisterRequiresPostBack(this);
				this.Page.GetPostBackEventReference(this);
			}
		}

		#endregion

		#region IPostBackDataHandler Members

		void IPostBackDataHandler.RaisePostDataChangedEvent()
		{
			OnTextChanged(EventArgs.Empty);
		}

		bool IPostBackDataHandler.LoadPostData(string postDataKey, System.Collections.Specialized.NameValueCollection postCollection)
		{
			if (postDataKey == this.UniqueID) 
			{
				string presentValue = Text;
				string postedValue = postCollection[this.ClientID];

				if (presentValue == null || !presentValue.Equals(postedValue)) 
				{
					Text = postedValue;
					return true;
				}
			}

			return false;
		}

		#endregion

		#region IPostBackEventHandler Members

		void IPostBackEventHandler.RaisePostBackEvent(string eventArgument)
		{
			if (eventArgument == null) return;
			if (eventArgument != "Save") return;

			this.OnSaveClick(EventArgs.Empty);
		}

		#endregion

		#region Tools

		private object IsNull( object valueToCheck, object replacementValue )
		{
			return valueToCheck == null ? replacementValue : valueToCheck ;
		}

		#endregion
	}
}
