using System;
using System.Web;
using System.Security.Principal;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Providers;

namespace OmniPortal.Components.Authentication.Windows
{
	public class WindowsAuthenticationActivator : ProviderActivator
	{
		protected override object CreateInstance(Type type)
		{
			// get the current http context
			HttpContext context = HttpContext.Current;
			
			// check to make sure user and identity exisit
			if (context.User == null || context.User.Identity == null) return null;

			WindowsUserIdentity identity = new WindowsUserIdentity(Guid.NewGuid(), (WindowsIdentity)context.User.Identity);

			// create arguments to pass into the provider type
			object[] args = new object[] {
											 identity
										 };

			// create provider with the arguments from above
			return Activator.CreateInstance(type, args);
		}
	}
}
