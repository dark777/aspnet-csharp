#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Security.Principal;
using System.Web;
using System.Web.Security;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Types;
using ManagedFusion.Security;
using ManagedFusion.Providers;

namespace OmniPortal.Components.Authentication.Windows
{
	[Provider("OmniPortalWindowsAuthentication", typeof(WindowsAuthenticationActivator))]
	public class WindowsAuthentication : SecurityProvider
	{
		public WindowsAuthentication(User user) : base(user)
		{
		}

		public new WindowsUserIdentity Identity 
		{
			get { return (WindowsUserIdentity)base.Identity; }
		}
	}
}