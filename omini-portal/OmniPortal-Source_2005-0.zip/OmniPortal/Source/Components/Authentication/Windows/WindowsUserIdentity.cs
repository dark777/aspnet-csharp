using System;
using System.Security.Principal;
using System.Web.Security;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;

namespace OmniPortal.Components.Authentication.Windows
{
	public class WindowsUserIdentity : User
	{
		private WindowsIdentity _identity;

		public WindowsUserIdentity(Guid id, WindowsIdentity identity) : base(id, identity.Name)
		{
			if (identity == null) throw new ArgumentNullException("identity");

			this._identity = identity;
		}

		public override bool IsAuthenticated
		{
			get { return _identity.IsAuthenticated; }
		}
	}
}
