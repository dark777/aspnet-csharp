using System;
using System.Security.Principal;
using System.Web.Security;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Security;

namespace OmniPortal.Components.Authentication.Form
{
	public class FormUserIdentity : User
	{
		private FormsIdentity _identity;

		public FormUserIdentity(Guid id, FormsIdentity identity) : base(id, identity.Name)
		{
			this._identity = identity;
		}

		public FormsAuthenticationTicket Ticket 
		{
			get { return _identity.Ticket; }
		}
	}
}
