#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Web;
using System.Web.Security;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Providers;

namespace OmniPortal.Components.Authentication.Form
{
	[RootProvider]
	public abstract class FormAuthenticationProvider
	{
		public const string AllRolesCacheKey = "FormAuthenticationProvider-AllRoles";

		public abstract bool ValidateUser (string name, string password) 
		{
		}

		public override string CookieName
		{
			get { return CommunityInfo.Current.UniversalIdentity.ToString(); }
		}

		public FormsAuthenticationTicket GetTicket (HttpContext context) 
		{
			FormsAuthenticationTicket ticket = null;

			if (context.Request.Cookies[CookieName] == null 
				|| context.Request.Cookies[CookieName].Value.Length > 0) 
			{
				string[] userRoles = GetUsersRolesFromDB(context.User.Identity.Name);

				// Format string array
				string formattedUserRoles = String.Join(Global.Delimiter.ToString(), userRoles);

				// Create authentication ticket
				ticket = new FormsAuthenticationTicket(
					1,								// version
					context.User.Identity.Name,		// user name
					DateTime.Now,					// issue time
					DateTime.Now.AddHours(1),		// expires every hour
					false,							// don't persist cookie
					formattedUserRoles				// roles
					);
			} 
			else 
			{
				// decrypt the current cookie into a ticket
				ticket = FormsAuthentication.Decrypt(context.Request.Cookies[CookieName].Value);
			}

			return ticket;
		}

		public string[] GetUsersRoles (HttpContext context) 
		{
			FormsAuthenticationTicket ticket = GetTicket(context);

			if (context.Request.Cookies[CookieName] == null
				|| context.Request.Cookies[CookieName].Value.Length > 0) 
			{
				// Encrypt the ticket
				string cookieValue = FormsAuthentication.Encrypt(ticket);

				// Send the cookie to the client
				HttpCookie cookie = new HttpCookie(CookieName);
				cookie.Value = cookieValue;
				cookie.Expires = DateTime.Now.AddMinutes(5);

				// add cookie to out going response
				context.Response.Cookies.Add(cookie);
			}

			return ticket.UserData.Split(Global.Delimiter);
		}
	}
}