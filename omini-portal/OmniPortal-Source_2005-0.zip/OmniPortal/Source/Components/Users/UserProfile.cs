using System;

using ManagedFusion.Security.Profile;

namespace OmniPortal.Components.Users
{
	/// <summary>
	/// Summary description for UserProfile.
	/// </summary>
	public class UserProfile
	{
		private ProfileCollection _collection;

		public UserProfile (ProfileCollection collection) 
		{
			this._collection = collection;
		}

		public string FullName 
		{
			get { return FirstName + " " + LastName; }
		}

		public string FirstName 
		{
			get { return this._collection["fname"]; }
		}

		public string LastName 
		{
			get { return this._collection["lname"]; }
		}

		public string Email 
		{
			get { return this._collection["email"]; }
		}
	}
}
