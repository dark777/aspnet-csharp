using System;
using System.Web;

using ManagedFusion;
using ManagedFusion.Security;

namespace OmniPortal.Components.Users
{
	public class UserInfo
	{
		private IUser _user;
		private UserProfile _profile;

		public static UserInfo Current 
		{
			get 
			{
				if (Global.Context.Items["OmniPortalUserInfo"] == null)
					Global.Context.Items["OmniPortalUserInfo"] = new UserInfo(Global.Security.Identity);

				return Global.Context.Items["OmniPortalUserInfo"] as UserInfo;
			}
		}

		public UserInfo (IUser user) 
		{
			this._user = user;
			this._profile = new UserProfile(user.Profile);
		}

		public string UserName 
		{
			get { return this._user.Name; }
		}

		public Guid ID 
		{
			get { return this._user.ID; }
		}

		public UserProfile Profile 
		{
			get { return this._profile; }
		}
	}
}
