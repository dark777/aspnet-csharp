#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Web.UI.WebControls;

namespace OmniPortal.Components.Common
{
	/// <summary>
	/// Delegate that defines the type of the <see cref="MasterDetailGrid.DataGridItemRender"/> event
	/// </summary>
	public delegate void DataGridItemRenderEventHandler(object sender, DataGridItemRenderEventArgs e);

	/// <summary>
	/// Event arguments used by the event <see cref="MasterDetailGrid.DataGridItemRender"/> in the <see cref="MasterDetailGrid"/>
	/// </summary>
	[System.Diagnostics.DebuggerStepThrough]
	public class DataGridItemRenderEventArgs : DataGridItemEventArgs 
	{
		private ArrayList _newRows;
		private bool _showItem;

		public DataGridItemRenderEventArgs(DataGridItem item) : base(item)
		{
			this._newRows = new ArrayList();
			this._showItem = true;
		}

		public ArrayList NewRows
		{
			get { return _newRows;  }
			set { _newRows = value; }
		}

		public bool ShowItem 
		{
			get { return this._showItem; }
			set { this._showItem = value; }
		}
	}
}