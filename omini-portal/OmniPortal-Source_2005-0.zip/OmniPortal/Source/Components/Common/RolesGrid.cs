#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

// ManagedFusion Classes
using ManagedFusion;
using MS = ManagedFusion.Security;

namespace OmniPortal.Components.Common
{
	/// <summary>
	/// Summary description for RolesGrid.
	/// </summary>
	[	ToolboxData("<{0}:RolesGrid runat=server></{0}:RolesGrid>")]
	public class RolesGrid : System.Web.UI.WebControls.WebControl
	{
		protected OmniPortal.Components.Common.PermissionsCheckBox permissionsList;
		protected OmniPortal.Components.Common.SelectionList selectionsList;

		#region Properties

		public string AvailableTitle
		{
			get { return (string)ViewState["AvailableName"]; }
			set { ViewState["AvailableName"] = value; }
		}

		public string SelectedTitle
		{
			get { return (string)ViewState["SelectedTitle"]; }
			set { ViewState["SelectedTitle"] = value; }
		}

		public Hashtable RolesInUse 
		{
			get 
			{
				if (ViewState["RolesInUse"] == null) ViewState["RolesInUse"] = new Hashtable();
				return (Hashtable)ViewState["RolesInUse"];
			}
		}

		public string SelectedRole 
		{
			get 
			{
				if (ViewState["SelectedRole"] == null) ViewState["SelectedRole"] = String.Empty;
				return (string)ViewState["SelectedRole"];
			}
			set { ViewState["SelectedRole"] = value; }
		}

		public ArrayList Roles 
		{
			get 
			{
				if (ViewState["Roles"] == null) ViewState["Roles"] = new ArrayList();
				return (ArrayList)ViewState["Roles"];
			}
		}

		public ArrayList Permissions 
		{
			get 
			{
				if (ViewState["Permissions"] == null) ViewState["Permissions"] = new ArrayList();
				return (ArrayList)ViewState["Permissions"];
			}
		}

		#endregion

		#region WebControl Events

		protected override void OnLoad(EventArgs e)
		{
			selectionsList.AddItemClick += new EventHandler(selectionsList_AddItemClick);
			selectionsList.RemoveItemClick += new EventHandler(selectionsList_RemoveItemClick);
			selectionsList.LeftListItemChanged += new EventHandler(selectionsList_LeftListItemChanged);

			base.OnLoad (e);
		}

		protected override void OnInit(EventArgs e) 
		{
			permissionsList = new PermissionsCheckBox();
			selectionsList = new SelectionList();
			
			// permissionsList
			//
			permissionsList.RepeatDirection = RepeatDirection.Horizontal;
			permissionsList.RepeatColumns = 5;
			permissionsList.RepeatLayout = RepeatLayout.Table;
			permissionsList.Width = this.Width;

			// selectionsList
			//
			selectionsList.Width = this.Width;
			selectionsList.RightListTitle = this.AvailableTitle;
			selectionsList.LeftListTitle = this.SelectedTitle;
			
			// Permissions
			//
			Permissions.AddRange(
				new string[] {
								 MS.Permissions.Read.ToString(),
								 MS.Permissions.Add.ToString(),
								 MS.Permissions.Edit.ToString(),
								 MS.Permissions.Delete.ToString(),
								 MS.Permissions.Administrate.ToString()
							 });

			this.Controls.Add(this.permissionsList);
			this.Controls.Add(this.selectionsList);

			base.OnInit (e);
		}

		protected override void OnPreRender(EventArgs e) 
		{
			// set selected values
			string flatPermissions = (string)this.RolesInUse[this.SelectedRole];

			if (flatPermissions != null) 
				this.permissionsList.SelectedPermissions = flatPermissions.Split(';');

			base.OnPreRender (e);
		}

		#endregion

		public override void DataBind() 
		{
			// gets the last selected item to make sure the selected permisstions
			// are not lost and it checks to see if a role is selected
			this.EnsureData();

			// gets a list of roles that are not in use
			ArrayList collection = new ArrayList(0);
			foreach (string role in this.Roles) 
				if (this.RolesInUse.ContainsKey(role) == false)
					collection.Add(role);

			if (this.RolesInUse.Count > 0) 
			{
				// roles in use
				this.selectionsList.LeftListDataSource = this.RolesInUse.Keys;
			}

			// roles not in use
			this.selectionsList.RightListDataSource = collection;

			// set permissions
			permissionsList.Permissions = this.Permissions;

			// select the permission for the current role
			string sPermissions = (string)this.RolesInUse[this.SelectedRole];
			permissionsList.SelectedPermissions = (sPermissions != null) ? sPermissions.Split(';') : new string[0];
			
			base.DataBind();
		}
		
		#region Render

		protected override void Render(HtmlTextWriter writer) 
		{
			// <table cellpadding=0 cellspacing=0 width=? height?>
			writer.WriteBeginTag("table");
			writer.WriteAttribute("cellpadding", "0");
			writer.WriteAttribute("cellspacing", "0");
			writer.WriteAttribute("width", Width.ToString());
			writer.WriteAttribute("height", Height.ToString());
			writer.Write(HtmlTextWriter.TagRightChar);
			writer.WriteLine();

			// render body
			this.RenderContents(writer);

			// </table>
			writer.WriteEndTag("table");
			writer.WriteLine();
		}

		protected override void RenderContents(HtmlTextWriter writer) 
		{
			#region <tr><td class=?>[selectionsList]</td></tr>
			// <tr><td class=? colspan=2>
			writer.Indent++;
			writer.WriteFullBeginTag("tr");
			writer.WriteBeginTag("td");
			writer.WriteAttribute("class", this.CssClass);
			writer.Write(HtmlTextWriter.TagRightChar);
			writer.WriteLine();

			// render roles list
			writer.Indent++;
			this.selectionsList.RenderControl(writer);

			// </td></tr>
			writer.Indent--;
			writer.WriteEndTag("td");
			writer.WriteEndTag("tr");
			writer.WriteLine();
			#endregion

			#region <tr><td class=?>[permissionsList]</td></tr>
			// <tr><td class=?>
			writer.WriteFullBeginTag("tr");
			writer.WriteBeginTag("td");
			writer.WriteAttribute("class", this.CssClass);
			writer.Write(HtmlTextWriter.TagRightChar);
			writer.WriteLine();

			// render permissions list
			writer.Indent++;
			this.permissionsList.RenderControl(writer);

			// </td></tr>
			writer.Indent--;
			writer.WriteEndTag("td");
			writer.WriteEndTag("tr");
			writer.WriteLine();
			#endregion
		}

		#endregion

		#region Events

		private void selectionsList_AddItemClick(object sender, EventArgs e)
		{
			// add this item to the roles list
			this.RolesInUse.Add(this.selectionsList.RightListSelectedItem.Text, String.Empty);

			// checks to see if a role is selected
			this.EnsureData();

			this.selectionsList.LeftListNameSelected = this.selectionsList.RightListSelectedItem.Text;
			this.SelectedRole = this.selectionsList.RightListSelectedItem.Text;
			
			// databind everything
			this.DataBind();
		}

		private void selectionsList_RemoveItemClick(object sender, EventArgs e)
		{
			// remove this item to the roles list
			this.RolesInUse.Remove(this.selectionsList.LeftListSelectedItem.Text);
			this.selectionsList.RightListNameSelected = this.selectionsList.LeftListSelectedItem.Text;
			
			// databind everything
			this.DataBind();
		}

		private void selectionsList_LeftListItemChanged(object sender, EventArgs e)
		{
			// checks to see if a role is selected
			this.EnsureData();
			
			// sets the selected role
			this.SelectedRole = this.selectionsList.LeftListSelectedItem.Text;

			// gets the permissions for the selected role
			string sPermissions = (string)this.RolesInUse[this.SelectedRole];
			permissionsList.SelectedPermissions = (sPermissions != null) ? sPermissions.Split(Global.Delimiter) : new string[0];

			// databind the permissions list
			permissionsList.DataBind();
		}

		#endregion

		public void EnsureData () 
		{
			// checks to see if a role is selected
			if (this.SelectedRole != String.Empty)
				this.RolesInUse[this.SelectedRole] = this.permissionsList.ToString();
		}

		public override bool Enabled
		{
			get { return base.Enabled; }
			set 
			{
				base.Enabled = value;
				this.permissionsList.Enabled = value;
				this.selectionsList.Enabled = value;
			}
		}
	}
}