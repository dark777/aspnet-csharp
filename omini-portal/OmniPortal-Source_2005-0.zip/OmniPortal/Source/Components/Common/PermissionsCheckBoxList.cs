#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

// ManagedFusion Classes
using ManagedFusion;

namespace OmniPortal.Components.Common
{
	[ToolboxData("<{0}:PermissionsCheckBox runat=server></{0}:RolesCheckBoxList>")]
	public class PermissionsCheckBox : CheckBoxList
	{
		[Browsable(false)]
		public string[] SelectedPermissions
		{
			get 
			{
				ArrayList list = new ArrayList(this.Items.Count);

				// get selected roles from item list
				foreach(ListItem i in this.Items) 
					if (i.Selected)
						list.Add(i.Text);

				return (string[])list.ToArray(typeof(string));
			}
			set { ViewState["SelectedPermissions"] = value; }
		}

		[Browsable(false)]
		public ArrayList Permissions 
		{
			get
			{
				object state = ViewState["Permissions"];
				if (state == null) ViewState["Permissions"] = new ArrayList();
				return (ArrayList)ViewState["Permissions"];
			}
			set { ViewState["Permissions"] = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		public override void DataBind()
		{
			if (Permissions.Count == 0)
				throw new ApplicationException("You must enter at least one role in the property Roles.");

			this.DataSource = this.Permissions;
			base.DataBind ();
			
			// add OmniPortal System Roles to role list
			// select roles set in view state
			ArrayList list = new ArrayList((string[])ViewState["SelectedPermissions"]);
			for(int i = 0; i < this.Items.Count; i++)
				this.Items[i].Selected = list.Contains(this.Items[i].Text);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			// combines all strings and returns them
			return String.Join(";", this.SelectedPermissions);
		}
	}
}