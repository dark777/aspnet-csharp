#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.IO;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

// ManagedFusion Classes
using ManagedFusion;
using ManagedFusion.Display;
using ManagedFusion.Types;

namespace OmniPortal.Components.Common
{
	/// <summary>
	/// This is the base class for all WebControls.  This classes primary use
	/// is to create a dynamic location for loading of controls in webpages
	/// without direct reference.
	/// </summary>
	public abstract class PagesWebControl : SkinnedWebControl, INamingContainer
	{
		/// <summary>Gets the control that is called from the module.</summary>
		/// <remarks>
		/// Gets the control that is called from the current module.  If the control cannot be found
		/// then it goes to the default theme and gets that version of the control.
		/// </remarks>
		/// <returns>The control that was loaded.</returns>
		protected override Control GetControl () 
		{
			Control skin = new Control();

			string moduleString = Global.Path.GetModulePath(ModuleName, ControlLocation);

			// build skin key
			skin = Global.Path.GetControlFromLocation(moduleString);

			// changes the ID names for compatibility
			skin.ID = this.ID;
			this.ID += "_WebControl";

			return skin;
		}
	}
}