#region Copyright © 2004, Nicholas Berardi
/*
 * OmniPortal (www.omniportal.net) Copyright © 2004, Nicholas Berardi
 * All rights reserved.
 * 
 * This code is protected under the Common Public License Version 1.0
 * The license in its entirety at <http://opensource.org/licenses/cpl.php>
 * 
 * OmniPortal is freely available from <http://www.omniportal.net/>
 */
#endregion

using System;
using System.Collections;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

// ManagedFusion Classes
using ManagedFusion;

namespace OmniPortal.Components.Common
{
	/// <summary>
	/// DataGrid that enables the creation of Master/Detail grids
	/// </summary>
	[ToolboxData("<{0}:MasterDataGrid runat=server></{0}:MasterDataGrid>")]
	public class MasterDataGrid : System.Web.UI.WebControls.DataGrid
	{
		/// <summary>
		/// Event fired for each item in the dataGrid, so you can customize the
		/// rendered table
		/// </summary>
		[Description("Event fired for each item in the MasterDataGrid, so you can customize the rendered table")]
		[Category("Render")]
		public event DataGridItemRenderEventHandler DataGridItemRender;

		/// <summary>
		/// Fires the <see cref="OmniPortal.Components.Modules.Common.MasterDataGrid.DataGridItemRender">DataGridItemRender</see> event.
		/// </summary>
		/// <param name="e">Event Arguments.</param>
		protected virtual void OnDataGridItemRender(DataGridItemRenderEventArgs e)
		{
			if (DataGridItemRender != null)
				DataGridItemRender(this, e);
		}

		/// <summary>
		/// Renders the contents of the control into the specified writer. This method is used primarily by 
		/// control developers.
		/// </summary>
		/// <param name="output"></param>
		protected override void RenderContents(HtmlTextWriter output)
		{		
			if (HasControls())
			{
				// get the table from the control list
				Table table = this.Controls[0] as Table;


				for (int i = 0; i < table.Rows.Count; i++)
				{
					// sets the row for the current data grid item
					DataGridItem item = (DataGridItem)table.Rows[i];

					// set event agruments for DataGridItem Render
					DataGridItemRenderEventArgs args = new DataGridItemRenderEventArgs(item);
						
					// raise DataGridItem Render
					OnDataGridItemRender(args);

					// sets the visibility of the item
					item.Visible = args.ShowItem;

					// add new rows to table if user has added any
					if (args.NewRows.Count != 0)
						foreach (TableRow row in args.NewRows)
							table.Rows.AddAt(i++, row);
				}
			}

			base.RenderContents(output);
		}
	}
}